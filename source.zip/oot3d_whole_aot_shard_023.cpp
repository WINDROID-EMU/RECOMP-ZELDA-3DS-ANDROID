#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_EnPeehat_Update_00167644(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnSt_Update_001BA22C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnSsh_Update_001DF0A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnVali_Update_001F8848(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnIceHono_Init_0022B190(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0029f8a0_0029F8A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgSpot06Objects_Init_002ACCC4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Play_CopyCamera_00338654(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnSsh_SetColliderScale_00347DD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnPeehat_SpawnDust_0034F3A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_LightContext_InsertLight_0034FAA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_SetJntSph_00350D48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_InitJntSph_00350EB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ProcessInitChain_003510B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyActor_Init_003532E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_SetCylinder_00353D24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_InitCylinder_00353DD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPoly_SetBgActor_00353EC8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyInfo_Alloc_00353FD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsEnFire_SpawnVec3f_003580EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMBByIndex_00358EF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Lights_PointNoGlowSetInfo_003591E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SpawnHitOrStoneEffect_00365560(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SpawnShieldParticlesGreen_003661A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FrameAdvance_IsEnabled_00366738(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgCheck_EntityLineTest1_00369F9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_Update_0036B4EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdatePos_0036B96C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_0036DF4C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetSwitch_0036E864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_S16Offset_003702c8_003702C8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_00370734_00370734(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_ChangeByInfo_003717AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_Init_00372D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMABByIndex_00372F0C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_LoadAll_00372F38(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetFocus_0037322C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_transform_mtx3x4_vec3_003735AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnRandomBrown_0037378C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_PlayOnce_00373D40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSs_SpawnSurfaceImpact_003741E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003742c4_003742C4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Kill_00374428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToPlayOnce_00374A58(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetPlayerKnockbackLargeNoDamage_00374BB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetScale_0037572C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToS_00375A18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSoundFlaggedTimer_00375B70(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_SetSwitch_00375C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ApplyDamage_00375EB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetColorFilter_00375ED8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetDropFlag_00375FD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAT_003761F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateBgCheckInfo_00376340(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_EnPeehat_Update_00167644(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00167644U:
        goto block_00167644;
    case 0x0016767CU:
        goto block_0016767C;
    case 0x00167688U:
        goto block_00167688;
    case 0x00167694U:
        goto block_00167694;
    case 0x001676BCU:
        goto block_001676BC;
    case 0x001676C8U:
        goto block_001676C8;
    case 0x001676E4U:
        goto block_001676E4;
    case 0x001676F0U:
        goto block_001676F0;
    case 0x001676F8U:
        goto block_001676F8;
    case 0x00167704U:
        goto block_00167704;
    case 0x00167710U:
        goto block_00167710;
    case 0x0016771CU:
        goto block_0016771C;
    case 0x00167764U:
        goto block_00167764;
    case 0x00167770U:
        goto block_00167770;
    case 0x0016777CU:
        goto block_0016777C;
    case 0x00167784U:
        goto block_00167784;
    case 0x001677A0U:
        goto block_001677A0;
    case 0x001677ACU:
        goto block_001677AC;
    case 0x001677B8U:
        goto block_001677B8;
    case 0x001677C0U:
        goto block_001677C0;
    case 0x001677C8U:
        goto block_001677C8;
    case 0x001677D8U:
        goto block_001677D8;
    case 0x001677ECU:
        goto block_001677EC;
    case 0x00167820U:
        goto block_00167820;
    case 0x0016782CU:
        goto block_0016782C;
    case 0x00167848U:
        goto block_00167848;
    case 0x00167854U:
        goto block_00167854;
    case 0x00167884U:
        goto block_00167884;
    case 0x001678A0U:
        goto block_001678A0;
    case 0x001678ACU:
        goto block_001678AC;
    case 0x001678C8U:
        goto block_001678C8;
    case 0x001678D0U:
        goto block_001678D0;
    case 0x001678ECU:
        goto block_001678EC;
    case 0x001678FCU:
        goto block_001678FC;
    case 0x0016790CU:
        goto block_0016790C;
    case 0x00167910U:
        goto block_00167910;
    case 0x00167924U:
        goto block_00167924;
    case 0x00167938U:
        goto block_00167938;
    case 0x00167948U:
        goto block_00167948;
    case 0x00167984U:
        goto block_00167984;
    case 0x00167990U:
        goto block_00167990;
    case 0x001679D8U:
        goto block_001679D8;
    case 0x001679E4U:
        goto block_001679E4;
    case 0x001679F0U:
        goto block_001679F0;
    case 0x00167A00U:
        goto block_00167A00;
    case 0x00167A14U:
        goto block_00167A14;
    case 0x00167A20U:
        goto block_00167A20;
    case 0x00167A2CU:
        goto block_00167A2C;
    case 0x00167A44U:
        goto block_00167A44;
    case 0x00167A5CU:
        goto block_00167A5C;
    case 0x00167A6CU:
        goto block_00167A6C;
    case 0x00167A78U:
        goto block_00167A78;
    case 0x00167A84U:
        goto block_00167A84;
    case 0x00167A94U:
        goto block_00167A94;
    case 0x00167AA0U:
        goto block_00167AA0;
    case 0x00167AACU:
        goto block_00167AAC;
    case 0x00167AC0U:
        goto block_00167AC0;
    case 0x00167AD0U:
        goto block_00167AD0;
    case 0x00167AF0U:
        goto block_00167AF0;
    case 0x00167B0CU:
        goto block_00167B0C;
    case 0x00167B18U:
        goto block_00167B18;
    case 0x00167B38U:
        goto block_00167B38;
    case 0x00167B48U:
        goto block_00167B48;
    case 0x00167B54U:
        goto block_00167B54;
    case 0x00167B60U:
        goto block_00167B60;
    case 0x00167B74U:
        goto block_00167B74;
    case 0x00167BBCU:
        goto block_00167BBC;
    case 0x00167BC8U:
        goto block_00167BC8;
    case 0x00167BECU:
        goto block_00167BEC;
    case 0x00167C0CU:
        goto block_00167C0C;
    case 0x00167C14U:
        goto block_00167C14;
    case 0x00167C18U:
        goto block_00167C18;
    case 0x00167C20U:
        goto block_00167C20;
    case 0x00167C30U:
        goto block_00167C30;
    case 0x00167C3CU:
        goto block_00167C3C;
    case 0x00167C50U:
        goto block_00167C50;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00167644:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167644U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167644U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00167644U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = r0;
        }
        {
            r5 = r1;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0016765CU + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167654U, address);
            }
            r0 = value;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00167658U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00167658U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00167658U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00167658U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167660U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167664U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x00167670U + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167668U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x00167674U + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016766CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x00167678U + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167670U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001678A0; }
        goto block_0016767C;
    }
block_0016767C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016767CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016767CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x69DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016767CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_00167694; }
        goto block_00167688;
    }
block_00167688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167688U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x765U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167688U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001676BC; }
        goto block_00167694;
    }
block_00167694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167694U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x765U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167694U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000080U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x765U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0016769CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x69DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001676A0U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000080U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x69DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001676A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6F5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001676ACU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6F5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001676B4U, address);
            }
        }
        goto block_001678A0;
    }
block_001676BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001676BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001676BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6F5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001676BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001678A0; }
        goto block_001676C8;
    }
block_001676C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001676C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001676C8U);
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6F5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001676CCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r4 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000002E4U;
            r1 = r1 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001676E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003742c4_003742C4(frame, context, state, 0x003742C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001676E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001676E4;
    }
block_001676E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001676E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001676E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001676E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001678AC; }
        goto block_001676F0;
    }
block_001676F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001676F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001676F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00167938; }
        goto block_001676F8;
    }
block_001676F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001676F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001676F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001676FCU, address);
            }
        }
        if (flags.Z()) { goto block_00167854; }
        goto block_00167704;
    }
block_00167704:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167704U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167704U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r4;
        }
        if (!(flags.Z())) { goto block_0016777C; }
        goto block_00167710;
    }
block_00167710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167710U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167710U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001678AC; }
        goto block_0016771C;
    }
block_0016771C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016771CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016771CU);
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x63CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167720U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167724U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167728U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00167734U + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016772CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000050U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00167734U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00167740U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167744U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167748U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0016774CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00167750U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r1 = r3;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167764;
    }
block_00167764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167764U);
        }
        {
            const uint32_t updatedAddress = 0x0016776CU + 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167764U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167770U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167770U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167770;
    }
block_00167770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167770U);
        }
        {
            const uint32_t updatedAddress = 0x00167778U + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167770U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x644U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00167774U, address);
            }
        }
        goto block_001678A0;
    }
block_0016777C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016777CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016777CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167784U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ApplyDamage_00375EB8(frame, context, state, 0x00375EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167784U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167784;
    }
block_00167784:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167784U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167784U);
        }
        {
            r3 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00167788U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001677A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001677A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001677A0;
    }
block_001677A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677A0U);
        }
        {
            const uint32_t updatedAddress = 0x001677A8U + 0x210U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001677A0U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001677ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001677ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001677AC;
    }
block_001677AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001677ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00167848; }
        goto block_001677B8;
    }
block_001677B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677B8U);
        }
        {
            r8 = 0x00000004U;
        }
        {
            const uint32_t address = 0x001677C4U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001677BCU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        goto block_001677C0;
    }
block_001677C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677C0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001677C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001677C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001677C8;
    }
block_001677C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677C8U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001677C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001677CCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001677D0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001677D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001677D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001677D8;
    }
block_001677D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677D8U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001677D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001677DCU, 0xEE400A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001677E4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001677ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001677ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001677EC;
    }
block_001677EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001677ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001677ECU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001677ECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001677F8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            r0 = r5;
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00167804U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167808U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0016780CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0016780CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0016780CU,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = 0x00000046U;
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167820U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsEnFire_SpawnVec3f_003580EC(frame, context, state, 0x003580ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167820U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167820;
    }
block_00167820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167820U);
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r8, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r8 = r8 - operand;
        }
        {
        }
        if (!(flags.N())) { goto block_001677C0; }
        goto block_0016782C;
    }
block_0016782C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016782CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016782CU);
        }
        {
            r3 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00167830U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167848U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167848U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167848;
    }
block_00167848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167848U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167848U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001678A0; }
        goto block_00167854;
    }
block_00167854:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167854U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167854U);
        }
        {
            const uint32_t updatedAddress = 0x0016785CU + 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167854U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00167858U, address);
            }
        }
        {
            r1 = 0x00000001U;
        }
        {
            r3 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00167864U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x640U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167868U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0016786CU, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167884U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167884U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167884;
    }
block_00167884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167884U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x63CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00167884U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167888U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167890U, address);
            }
        }
        {
            const uint32_t address = r0 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00167894U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001678A0U + 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167898U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x644U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0016789CU, address);
            }
        }
        goto block_001678A0;
    }
block_001678A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001678A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001678A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001678A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00167938; }
        goto block_001678AC;
    }
block_001678AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001678ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001678ACU);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001678ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001678B0U, 0xEEB40A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001678B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001678BCU, 0x0EB40A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (flags.Z()) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_001678EC; }
        goto block_001678C8;
    }
block_001678C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001678C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001678C8U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001678D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001678D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001678D0;
    }
block_001678D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001678D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001678D0U);
        }
        {
            const uint32_t address = 0x001678D8U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001678D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r2 = 0x00000005U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001678ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001678ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001678EC;
    }
block_001678EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001678ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001678ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x644U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001678ECU, address);
            }
            r2 = value;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001678FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001678FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001678FC;
    }
block_001678FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001678FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001678FCU);
        }
        {
            const uint32_t updatedAddress = 0x00167904U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001678FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167900U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000007FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00167924; }
        goto block_0016790C;
    }
block_0016790C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016790CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016790CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167910U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167910U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167910;
    }
block_00167910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167910U);
        }
        {
            const uint32_t address = 0x00167918U + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167910U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0016791CU + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167914U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0016791CU, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 628U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00167920U, address);
            }
        }
        goto block_00167924;
    }
block_00167924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167924U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167928U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016792CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00167930U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 624U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00167934U, address);
            }
        }
        goto block_00167938;
    }
block_00167938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167938U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167938U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r4;
        }
        if ((flags.N()) == (flags.V())) { goto block_001679F0; }
        goto block_00167948;
    }
block_00167948:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167948U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167948U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x700U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167948U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t address = r2 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167950U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00167954U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x700U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167958U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r2 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016795CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00167960U, address);
            }
        }
        {
            const uint32_t address = r2 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167964U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t address = r4 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0016796CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167970U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00167974U, address);
            }
        }
        {
            r3 = 0x0000012CU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001679D8; }
        goto block_00167984;
    }
block_00167984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167984U);
        }
        {
            const uint32_t updatedAddress = 0x0016798CU + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167984U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167990;
    }
block_00167990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167990U);
        }
        {
        }
        {
        }
        goto block_00167A00;
    }
block_001679D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001679D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001679D8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001679E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001679E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001679E4;
    }
block_001679E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001679E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001679E4U);
        }
        {
        }
        {
        }
        goto block_00167A00;
    }
block_001679F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001679F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001679F0U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001679F8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001679F8U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001679F8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001679FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001679FCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001679FCU,
                                           firstAddress + 8U);
            }
        }
        goto block_00167A00;
    }
block_00167A00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A00U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000028CU;
            r1 = r1 + operand;
        }
        {
            r10 = r1;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167A14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167A14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167A14;
    }
block_00167A14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00167AF0; }
        goto block_00167A20;
    }
block_00167A20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A20U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A20U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00167AA0; }
        goto block_00167A2C;
    }
block_00167A2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A2CU);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r2 = r10;
        }
        {
            r8 = r1;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167A44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167A44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167A44;
    }
block_00167A44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A44U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002E4U;
            r2 = r2 + operand;
        }
        {
            r9 = r2;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167A5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167A5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167A5C;
    }
block_00167A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A5CU);
        }
        {
            const uint32_t updatedAddress = 0x00167A64U + 0x214U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A5CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A60U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00167A78; }
        goto block_00167A6C;
    }
block_00167A6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00400000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00400000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00167A94; }
        goto block_00167A78;
    }
block_00167A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00167A94; }
        goto block_00167A84;
    }
block_00167A84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A84U);
        }
        {
            r2 = r9;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167A94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167A94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167A94;
    }
block_00167A94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167A94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167A94U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167A94U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_00167AF0; }
        goto block_00167AA0;
    }
block_00167AA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167AA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167AA0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x764U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167AA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00167AF0; }
        goto block_00167AAC;
    }
block_00167AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167AACU);
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x764U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167AB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x758U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167AB4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00167AF0; }
        goto block_00167AC0;
    }
block_00167AC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167AC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167AC0U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t address = 0x00167ACCU + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167AC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167AD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167AD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167AD0;
    }
block_00167AD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167AD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167AD0U);
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x63CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00167AD4U, address);
            }
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00167AD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167ADCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00167AE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00167AECU + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167AE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x644U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00167AE8U, address);
            }
        }
        goto block_00167C3C;
    }
block_00167AF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167AF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167AF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167AF0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00167C3C; }
        goto block_00167B0C;
    }
block_00167B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167B0CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00167C50; }
        goto block_00167B18;
    }
block_00167B18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B18U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000354U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r7 = r2;
        }
        {
            r8 = r1;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167B38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167B38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167B38;
    }
block_00167B38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B38U);
        }
        {
            r2 = r7;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167B48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167B48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167B48;
    }
block_00167B48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B48U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167B48U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00167C18; }
        goto block_00167B54;
    }
block_00167B54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167B54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00167C20; }
        goto block_00167B60;
    }
block_00167B60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B60U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r8 = r5 + operand;
        }
        {
            const uint32_t address = 0x00167B6CU + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167B64U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x00167B70U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167B68U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r7 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000298U;
            r8 = r8 + operand;
        }
        goto block_00167B74;
    }
block_00167B74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167B74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167B74U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r3 = r13 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00167B80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00167B84U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00167B88U, address);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00167B94U, address);
            }
        }
        {
            const uint32_t operand = 0x00000020U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00167BA0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000248U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167BBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityLineTest1_00369F9C(frame, context, state, 0x00369F9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167BBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167BBC;
    }
block_00167BBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167BBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167BBCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00167C0C; }
        goto block_00167BC8;
    }
block_00167BC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167BC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167BC8U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000096U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00167BD0U, faultAddress);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r3 = 0x0000012CU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167BECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnRandomBrown_0037378C(frame, context, state, 0x0037378CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167BECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167BEC;
    }
block_00167BEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167BECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167BECU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167C0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnPeehat_SpawnDust_0034F3A0(frame, context, state, 0x0034F3A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167C0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167C0C;
    }
block_00167C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C0CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r7, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r7 = r7 - operand;
        }
        if (!(flags.N())) { goto block_00167B74; }
        goto block_00167C14;
    }
block_00167C14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C14U);
        }
        goto block_00167C50;
    }
block_00167C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C18U);
        }
        {
        }
        if (flags.Z()) { goto block_00167C50; }
        goto block_00167C20;
    }
block_00167C20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C20U);
        }
        {
            r2 = r10;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167C30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167C30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167C30;
    }
block_00167C30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C30U);
        }
        {
        }
        {
        }
        goto block_00167C50;
    }
block_00167C3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C3CU);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r5 + operand;
        }
        {
            r2 = r10;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00167C50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00167C50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00167C50;
    }
block_00167C50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00167C50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00167C50U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000030U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00167C5CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00167C5CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00167C5CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00167C5CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t operand = 0x00000278U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 24U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00167C64U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
            r13 = r13 + 32U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00167C74U + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167C6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00167C78U + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00167C70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        return Oot3dAotBranch(0x0036E168U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnSt_Update_001BA22C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001BA22CU:
        goto block_001BA22C;
    case 0x001BA260U:
        goto block_001BA260;
    case 0x001BA294U:
        goto block_001BA294;
    case 0x001BA2A4U:
        goto block_001BA2A4;
    case 0x001BA2C0U:
        goto block_001BA2C0;
    case 0x001BA2D4U:
        goto block_001BA2D4;
    case 0x001BA2E8U:
        goto block_001BA2E8;
    case 0x001BA300U:
        goto block_001BA300;
    case 0x001BA350U:
        goto block_001BA350;
    case 0x001BA358U:
        goto block_001BA358;
    case 0x001BA384U:
        goto block_001BA384;
    case 0x001BA390U:
        goto block_001BA390;
    case 0x001BA39CU:
        goto block_001BA39C;
    case 0x001BA3E0U:
        goto block_001BA3E0;
    case 0x001BA3ECU:
        goto block_001BA3EC;
    case 0x001BA428U:
        goto block_001BA428;
    case 0x001BA454U:
        goto block_001BA454;
    case 0x001BA460U:
        goto block_001BA460;
    case 0x001BA46CU:
        goto block_001BA46C;
    case 0x001BA478U:
        goto block_001BA478;
    case 0x001BA48CU:
        goto block_001BA48C;
    case 0x001BA4A0U:
        goto block_001BA4A0;
    case 0x001BA4ACU:
        goto block_001BA4AC;
    case 0x001BA4B8U:
        goto block_001BA4B8;
    case 0x001BA4C4U:
        goto block_001BA4C4;
    case 0x001BA4D8U:
        goto block_001BA4D8;
    case 0x001BA4E0U:
        goto block_001BA4E0;
    case 0x001BA4F4U:
        goto block_001BA4F4;
    case 0x001BA500U:
        goto block_001BA500;
    case 0x001BA538U:
        goto block_001BA538;
    case 0x001BA548U:
        goto block_001BA548;
    case 0x001BA574U:
        goto block_001BA574;
    case 0x001BA580U:
        goto block_001BA580;
    case 0x001BA598U:
        goto block_001BA598;
    case 0x001BA5A4U:
        goto block_001BA5A4;
    case 0x001BA5B0U:
        goto block_001BA5B0;
    case 0x001BA5C4U:
        goto block_001BA5C4;
    case 0x001BA5CCU:
        goto block_001BA5CC;
    case 0x001BA5ECU:
        goto block_001BA5EC;
    case 0x001BA600U:
        goto block_001BA600;
    case 0x001BA60CU:
        goto block_001BA60C;
    case 0x001BA658U:
        goto block_001BA658;
    case 0x001BA664U:
        goto block_001BA664;
    case 0x001BA668U:
        goto block_001BA668;
    case 0x001BA674U:
        goto block_001BA674;
    case 0x001BA6C8U:
        goto block_001BA6C8;
    case 0x001BA6DCU:
        goto block_001BA6DC;
    case 0x001BA6ECU:
        goto block_001BA6EC;
    case 0x001BA6F8U:
        goto block_001BA6F8;
    case 0x001BA7A0U:
        goto block_001BA7A0;
    case 0x001BA7D8U:
        goto block_001BA7D8;
    case 0x001BA7E4U:
        goto block_001BA7E4;
    case 0x001BA7E8U:
        goto block_001BA7E8;
    case 0x001BA81CU:
        goto block_001BA81C;
    case 0x001BA82CU:
        goto block_001BA82C;
    case 0x001BA8B0U:
        goto block_001BA8B0;
    case 0x001BA8B8U:
        goto block_001BA8B8;
    case 0x001BA8C4U:
        goto block_001BA8C4;
    case 0x001BA924U:
        goto block_001BA924;
    case 0x001BA934U:
        goto block_001BA934;
    case 0x001BA950U:
        goto block_001BA950;
    case 0x001BA964U:
        goto block_001BA964;
    case 0x001BA998U:
        goto block_001BA998;
    case 0x001BA9ACU:
        goto block_001BA9AC;
    case 0x001BA9ECU:
        goto block_001BA9EC;
    case 0x001BAA08U:
        goto block_001BAA08;
    case 0x001BAA20U:
        goto block_001BAA20;
    case 0x001BAA34U:
        goto block_001BAA34;
    case 0x001BAA40U:
        goto block_001BAA40;
    case 0x001BAA6CU:
        goto block_001BAA6C;
    case 0x001BAA78U:
        goto block_001BAA78;
    case 0x001BAA8CU:
        goto block_001BAA8C;
    case 0x001BAA98U:
        goto block_001BAA98;
    case 0x001BAAC4U:
        goto block_001BAAC4;
    case 0x001BAAD0U:
        goto block_001BAAD0;
    case 0x001BAAE4U:
        goto block_001BAAE4;
    case 0x001BAAF0U:
        goto block_001BAAF0;
    case 0x001BAB18U:
        goto block_001BAB18;
    case 0x001BAB1CU:
        goto block_001BAB1C;
    case 0x001BAB64U:
        goto block_001BAB64;
    case 0x001BAB80U:
        goto block_001BAB80;
    case 0x001BABB4U:
        goto block_001BABB4;
    case 0x001BABC0U:
        goto block_001BABC0;
    case 0x001BABC4U:
        goto block_001BABC4;
    case 0x001BABCCU:
        goto block_001BABCC;
    case 0x001BABD8U:
        goto block_001BABD8;
    case 0x001BABF8U:
        goto block_001BABF8;
    case 0x001BAC04U:
        goto block_001BAC04;
    case 0x001BAC10U:
        goto block_001BAC10;
    case 0x001BAC54U:
        goto block_001BAC54;
    case 0x001BAC6CU:
        goto block_001BAC6C;
    case 0x001BAC84U:
        goto block_001BAC84;
    case 0x001BACA8U:
        goto block_001BACA8;
    case 0x001BACB8U:
        goto block_001BACB8;
    case 0x001BACC4U:
        goto block_001BACC4;
    case 0x001BACD8U:
        goto block_001BACD8;
    case 0x001BAD0CU:
        goto block_001BAD0C;
    case 0x001BADC4U:
        goto block_001BADC4;
    case 0x001BADCCU:
        goto block_001BADCC;
    case 0x001BADD8U:
        goto block_001BADD8;
    case 0x001BAE38U:
        goto block_001BAE38;
    case 0x001BAE48U:
        goto block_001BAE48;
    case 0x001BAE78U:
        goto block_001BAE78;
    case 0x001BAE84U:
        goto block_001BAE84;
    case 0x001BAEB8U:
        goto block_001BAEB8;
    case 0x001BAECCU:
        goto block_001BAECC;
    case 0x001BAEE4U:
        goto block_001BAEE4;
    case 0x001BAF10U:
        goto block_001BAF10;
    case 0x001BAF24U:
        goto block_001BAF24;
    case 0x001BAF34U:
        goto block_001BAF34;
    case 0x001BAF40U:
        goto block_001BAF40;
    case 0x001BAF54U:
        goto block_001BAF54;
    case 0x001BAF64U:
        goto block_001BAF64;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001BA22C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA22CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA22CU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001BA22CU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r7 = 0x00000000U;
        }
        {
            r11 = r1;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001BA23CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001BA23CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001BA23CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001BA23CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001BA23CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001BA23CU,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA244U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00008000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00008000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000074U;
            r13 = r13 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001BA254U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001BA254U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001BA254U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001BA254U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001BA254U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001BA254U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        if (!(flags.Z())) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001BA258U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        if (!(flags.Z())) { return Oot3dAotBranch(0x003731E0U); }
        goto block_001BA260;
    }
block_001BA260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA260U);
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000900U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001BA270U + 0x3B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA268U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x765U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA26CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x001BA278U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA270U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x001BA27CU + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA274U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA278U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x001BA284U + 920U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA27CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x001BA288U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA280U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001BA28CU + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA284U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t value = r1 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r2 + operand;
        }
        if (!(flags.Z())) { goto block_001BA300; }
        goto block_001BA294;
    }
block_001BA294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA294U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r9 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA298U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA6EC; }
        goto block_001BA2A4;
    }
block_001BA2A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA2A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA2A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6B5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA2A4U, address);
            }
            r3 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r4 + operand;
        }
        {
            const uint32_t value = r3 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x000002A4U;
            r2 = r2 + operand;
        }
        if (flags.Z()) { goto block_001BA2D4; }
        goto block_001BA2C0;
    }
block_001BA2C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA2C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA2C0U);
        }
        {
            r1 = r3 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA2C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA2C8U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA2D0U, address);
            }
            r6 = value;
        }
        goto block_001BA2D4;
    }
block_001BA2D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA2D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA2D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x70DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA2D4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002FCU;
            r2 = r2 + operand;
        }
        {
            const uint32_t value = r3 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BA350; }
        goto block_001BA2E8;
    }
block_001BA2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA2E8U);
        }
        {
            r1 = r3 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA2ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA2F0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA2F4U, address);
            }
            r1 = value;
        }
        {
            r6 = r6 | r1;
        }
        goto block_001BA358;
    }
block_001BA300:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA300U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA300U);
        }
        {
            r1 = r1 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x765U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA304U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA308U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA310U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA314U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA318U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA31CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA324U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x944U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BA328U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA32CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA334U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA338U, 0xEE890A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA33CU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA340U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA348U, address);
            }
        }
        goto block_001BA598;
    }
block_001BA350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA350U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BA478; }
        goto block_001BA358;
    }
block_001BA358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA358U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA358U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA360U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA364U, 0xEEC00A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA368U, 0xEE700AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA36CU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA374U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA378U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA3EC; }
        goto block_001BA384;
    }
block_001BA384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA384U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA384U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA478; }
        goto block_001BA390;
    }
block_001BA390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA390U);
        }
        {
            const uint32_t updatedAddress = 0x001BA398U + 0x294U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA390U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA39CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA39CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA39C;
    }
block_001BA39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA39CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA39CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA3A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA3B0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA3B4U, 0xEE8A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA3B8U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA3BCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001BA3C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001BA3CCU, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r1 = r3;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA3E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA3E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA3E0;
    }
block_001BA3E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA3E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA3E0U);
        }
        {
        }
        {
        }
        goto block_001BA478;
    }
block_001BA3EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA3ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA3ECU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BA3ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BA3F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001BA3F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA3F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001BA404U + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA3FCU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000003U;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA408U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA40CU, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA410U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA414U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA41CU, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA428U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_ChangeByInfo_003717AC(frame, context, state, 0x003717ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA428U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA428;
    }
block_001BA428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA428U);
        }
        {
            const uint32_t address = r4 + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA428U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            r1 = 0x00400000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA434U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001BA440U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001BA444U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA454;
    }
block_001BA454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA454U);
        }
        {
            r0 = r4;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA460U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ApplyDamage_00375EB8(frame, context, state, 0x00375EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA460U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA460;
    }
block_001BA460:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA460U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA460U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001BA668; }
        goto block_001BA46C;
    }
block_001BA46C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA46CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA46CU);
        }
        {
            const uint32_t updatedAddress = 0x001BA474U + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA46CU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA478U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA478U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA478;
    }
block_001BA478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA478U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA478U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA480U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_001BA598; }
        goto block_001BA48C;
    }
block_001BA48C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA48CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA48CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7BFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA48CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA490U, address);
            }
            r6 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001BA4AC; }
        goto block_001BA4A0;
    }
block_001BA4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4A0U);
        }
        {
            r0 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7BFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA4A4U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        goto block_001BA4AC;
    }
block_001BA4AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x817U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA4ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001BA4C4; }
        goto block_001BA4B8;
    }
block_001BA4B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4B8U);
        }
        {
            r0 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x817U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA4BCU, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        goto block_001BA4C4;
    }
block_001BA4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x86FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA4C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = r1 & ~(0x00000001U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x86FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA4D0U, address);
            }
        }
        if (!(flags.Z())) { goto block_001BA4E0; }
        goto block_001BA4D8;
    }
block_001BA4D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BA598; }
        goto block_001BA4E0;
    }
block_001BA4E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4E0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA4E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001BA4F0U + 0x148U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA4E8U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA4F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA4F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA4F4;
    }
block_001BA4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA4F4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA4F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001BA538; }
        goto block_001BA500;
    }
block_001BA500:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA500U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA500U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA500U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA508U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA510U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA514U, 0xEE890A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA518U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA51CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA524U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x980U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA528U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000096U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA534U, address);
            }
        }
        goto block_001BA538;
    }
block_001BA538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA538U);
        }
        {
            const uint32_t updatedAddress = 0x001BA540U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA538U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x52U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA53CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA574; }
        goto block_001BA548;
    }
block_001BA548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA548U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA548U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001BA554U + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA54CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA550U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            r1 = ~(0x00000007U);
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r0 + 0x488U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BA560U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001BA56CU + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA564U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r11;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA568U, address);
            }
            r2 = value;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001BA574U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA574U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA574;
    }
block_001BA574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA574U);
        }
        {
            const uint32_t updatedAddress = 0x001BA57CU + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA574U, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA580U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA580U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA580;
    }
block_001BA580:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA580U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA580U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA580U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001BA58CU + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA584U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001BA590U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA588U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA598U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetPlayerKnockbackLargeNoDamage_00374BB8(frame, context, state, 0x00374BB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA598;
    }
block_001BA598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA598U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA598U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA5B0; }
        goto block_001BA5A4;
    }
block_001BA5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA5A4U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA5B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_Update_0036B4EC(frame, context, state, 0x0036B4ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA5B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA5B0;
    }
block_001BA5B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA5B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA5B0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA5B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA5B8U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA5CC; }
        goto block_001BA5C4;
    }
block_001BA5C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA5C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA5C4U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA5CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdatePos_0036B96C(frame, context, state, 0x0036B96CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA5CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA5CC;
    }
block_001BA5CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA5CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA5CCU);
        }
        {
            const uint32_t address = 0x001BA5D4U + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA5CCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r4;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = r11;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA5ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA5ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA5EC;
    }
block_001BA5EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA5ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA5ECU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA5ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA5F8U, address);
            }
        }
        if (!(flags.Z())) { goto block_001BA950; }
        goto block_001BA600;
    }
block_001BA600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA600U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA600U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA6F8; }
        goto block_001BA60C;
    }
block_001BA60C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA60CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA60CU);
        }
        {
            r1 = r11;
        }
        goto block_001BA658;
    }
block_001BA658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA658U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA658U, address);
            }
            r2 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001BA664U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA664;
    }
block_001BA664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA664U);
        }
        goto block_001BA950;
    }
block_001BA668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA668U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA674U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSoundFlaggedTimer_00375B70(frame, context, state, 0x00375B70U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA674U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA674;
    }
block_001BA674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA674U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA674U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001BA680U + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA678U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001BA684U + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA67CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA684U, address);
            }
        }
        {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BA688U, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA690U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA694U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001BA6A0U + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA698U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA6A0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA6A8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA6ACU, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA6B0U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA6B4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA6BCU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA6C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA6C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA6C8;
    }
block_001BA6C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA6C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA6C8U);
        }
        {
            const uint32_t updatedAddress = 0x001BA6D0U + 0x2F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA6C8U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r6, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001BA6D8U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA6D0U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA6D4U, address);
            }
        }
        if (flags.Z()) { goto block_001BA6EC; }
        goto block_001BA6DC;
    }
block_001BA6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA6DCU);
        }
        {
            const uint32_t updatedAddress = 0x001BA6E4U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA6DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA6E0U, address);
            }
        }
        {
            r0 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA6E8U, address);
            }
        }
        goto block_001BA6EC;
    }
block_001BA6EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA6ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA6ECU);
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001BA6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA6F8U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA6F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001BA704U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA6FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x78U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA700U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = 0x001BA710U + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA708U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA70CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA714U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA718U, 0xEE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x001BA728U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA720U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA724U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA728U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA734U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA738U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA748U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BA74CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA750U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA75CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA760U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA764U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA768U, 0xEEC90AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[19], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA76CU, 0xEE211A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA770U, 0xEE700AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA774U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA778U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA784U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA788U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x78U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA790U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA794U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA798U, 0xEE609A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA7A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA7A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA7A0;
    }
block_001BA7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA7A0U);
        }
        {
            const uint32_t address = 0x001BA7A8U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA7A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA7A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA7A8U, 0xEE690AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA7ACU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA7B0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r6;
        }
        if ((flags.N()) == (flags.V())) {
            r0 = r6;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x944U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA7CCU, address);
            }
            r0 = value;
        }
        if ((flags.N()) == (flags.V())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BA7E8; }
        goto block_001BA7D8;
    }
block_001BA7D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA7D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA7D8U);
        }
        {
            const uint32_t updatedAddress = 0x001BA7E0U + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA7D8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA7E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA7E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA7E4;
    }
block_001BA7E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA7E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA7E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x944U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001BA7E4U, address);
            }
        }
        goto block_001BA7E8;
    }
block_001BA7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA7E8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA7E8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r6;
        }
        if ((flags.N()) == (flags.V())) {
            r0 = r6;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x944U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BA7FCU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r6;
        }
        if ((flags.N()) == (flags.V())) {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r5 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA80CU, address);
            }
        }
        {
            const uint32_t address = 0x001BA818U + 456U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA810U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA81CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA81CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA81C;
    }
block_001BA81C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA81CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA81CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA81CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            r0 = r6;
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BA824U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA82CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA82CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA82C;
    }
block_001BA82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA82CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA82CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x3F800000U;
        }
        {
            const uint32_t address = r13 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BA838U, address);
            }
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001BA83CU, address);
            }
        }
        {
            const uint32_t address = r0 + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA840U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA844U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 352U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA848U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BA84CU, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BA850U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001BA854U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA85CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA860U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA864U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BA868U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BA86CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA870U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001BA874U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA878U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA87CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BA880U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001BA884U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA888U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001BA894U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA88CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA890U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA894U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA89CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8A0U, 0xEE60AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8A4U, 0xEEF4AA48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_001BA924; }
        goto block_001BA8B0;
    }
block_001BA8B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA8B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA8B0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA8B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA8B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA8B8;
    }
block_001BA8B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA8B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA8B8U);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA8C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA8C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA8C4;
    }
block_001BA8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA8C4U);
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA8C4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA8C8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8CCU, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8D0U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8D4U, 0xEE411A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8D8U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001BA8DCU, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BA8E0U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA8E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA8E8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8ECU, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8F0U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8F4U, 0xEE411A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA8F8U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001BA8FCU, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BA900U, address);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA904U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA908U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA90CU, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA910U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA914U, 0xEE411A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA918U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001BA91CU, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BA920U, address);
            }
        }
        goto block_001BA924;
    }
block_001BA924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA924U);
        }
        {
            const uint32_t operand = 0x00000064U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000058U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BA934U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BA934U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BA934;
    }
block_001BA934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA934U);
        }
        {
            r0 = Oot3dAotLsl(r6, 1U);
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA93CU, address);
            }
        }
        {
            const uint32_t address = r13 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA940U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BA944U, address);
            }
        }
        {
            const uint32_t address = r13 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA948U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BA94CU, address);
            }
        }
        goto block_001BA950;
    }
block_001BA950:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA950U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA950U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA950U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001BA95CU + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA954U, address);
            }
            r9 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BA9EC; }
        goto block_001BA964;
    }
block_001BA964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA964U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA964U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA96CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA974U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA978U, 0xEE8A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA97CU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BA980U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            r2 = Oot3dAotAsr(r1, 31U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r2, 30U);
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, Oot3dAotAsr(r1, 2U), static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001BABF8; }
        goto block_001BA998;
    }
block_001BA998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA998U);
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA99CU, address);
            }
            r0 = value;
        }
        {
            r1 = r4;
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000800U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        goto block_001BA9AC;
    }
block_001BA9AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA9ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA9ACU);
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BA9ACU, address);
            }
        }
        goto block_001BABF8;
    }
block_001BA9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BA9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BA9ECU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA9ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA9F4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x3EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BA9FCU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001BABF8; }
        goto block_001BAA08;
    }
block_001BAA08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA08U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA08U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA10U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = r4;
        }
        if (flags.Z()) { goto block_001BAA34; }
        goto block_001BAA20;
    }
block_001BAA20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA20U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001500U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000055U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAA2CU, address);
            }
        }
        goto block_001BABF8;
    }
block_001BAA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA34U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA34U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BAA6C; }
        goto block_001BAA40;
    }
block_001BAA40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA40U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA40U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA48U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAA50U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAA54U, 0xEE890A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAA58U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAA5CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAA64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001BAA68U, address);
            }
        }
        goto block_001BAA6C;
    }
block_001BAA6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA6CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA6CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BAAC4; }
        goto block_001BAA78;
    }
block_001BAA78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA78U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAA84U, address);
            }
        }
        if (!(flags.Z())) { goto block_001BAB1C; }
        goto block_001BAA8C;
    }
block_001BAA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA8CU);
        }
        {
            const uint32_t updatedAddress = 0x001BAA94U - 0x45CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA8CU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAA98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAA98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAA98;
    }
block_001BAA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAA98U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAA98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAAA0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAAA8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAAACU, 0xEE890A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAAB0U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAAB4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAABCU, address);
            }
        }
        goto block_001BAB1C;
    }
block_001BAAC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAAC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAAC4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAAC4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BAB1C; }
        goto block_001BAAD0;
    }
block_001BAAD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAAD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAAD0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAADCU, address);
            }
        }
        if (!(flags.Z())) { goto block_001BAB18; }
        goto block_001BAAE4;
    }
block_001BAAE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAAE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAAE4U);
        }
        {
            const uint32_t updatedAddress = 0x001BAAECU - 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAAE4U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAAF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAAF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAAF0;
    }
block_001BAAF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAAF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAAF0U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAAF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAAF8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAB00U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAB04U, 0xEE890A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAB08U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAB0CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAB14U, address);
            }
        }
        goto block_001BAB18;
    }
block_001BAB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAB18U);
        }
        {
            r6 = 0x00008000U;
        }
        goto block_001BAB1C;
    }
block_001BAB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAB1CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB1CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB20U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BAB24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAB28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB30U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB38U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB3CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r0 ^ r6;
        }
        {
            const uint32_t operand = r0;
            r2 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t operand = 0x00004000U;
            r2 = r2 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00008000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t operand = 0x00001500U;
            r0 = r1 + operand;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t operand = 0x00000055U;
            r0 = r0 + operand;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAB5CU, address);
            }
        }
        if ((flags.C()) && !(flags.Z())) { goto block_001BAB80; }
        goto block_001BAB64;
    }
block_001BAB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAB64U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001BAB6CU, address);
            }
        }
        {
            r3 = 0x00002000U;
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x0000006AU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAB80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAB80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAB80;
    }
block_001BAB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAB80U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB80U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BAB88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB8CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAB90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAB94U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAB98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BAB9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BABA0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BABA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BABA8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BABACU, address);
            }
        }
        if (!(flags.Z())) { goto block_001BABC4; }
        goto block_001BABB4;
    }
block_001BABB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BABB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BABB4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BABB4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001BABF8; }
        goto block_001BABC0;
    }
block_001BABC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BABC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BABC0U);
        }
        goto block_001BABD8;
    }
block_001BABC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BABC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BABC4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00008000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001BABF8; }
        goto block_001BABCC;
    }
block_001BABCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BABCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BABCCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BABCCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001BABF8; }
        goto block_001BABD8;
    }
block_001BABD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BABD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BABD8U);
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BABDCU, address);
            }
            r0 = value;
        }
        {
            r1 = r4;
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000500U;
            r0 = r0 - operand;
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000055U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000500U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000055U;
            r0 = r0 + operand;
        }
        goto block_001BA9AC;
    }
block_001BABF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BABF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BABF8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BABF8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BAC10; }
        goto block_001BAC04;
    }
block_001BAC04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAC04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAC04U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            r7 = r7 | 0x000000FFU;
        }
        goto block_001BAC10;
    }
block_001BAC10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAC10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAC10U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x945U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC10U, address);
            }
            r2 = value;
        }
        {
            r0 = Oot3dAotLsl(r7, 16U);
        }
        {
            r1 = r7 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAC1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x946U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC20U, address);
            }
            r2 = value;
        }
        {
            r6 = Oot3dAotLsr(r0, 24U);
        }
        {
            r0 = Oot3dAotLsl(r7, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAC2CU, address);
            }
        }
        {
            r7 = Oot3dAotLsr(r0, 24U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x947U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC34U, address);
            }
            r0 = value;
        }
        {
            r8 = 0x0000003FU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001BAC3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAC40U, address);
            }
        }
        {
            r3 = r8;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAC54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAC54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAC54;
    }
block_001BAC54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAC54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAC54U);
        }
        {
            r3 = r8;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x00000068U;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001BAC64U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAC6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAC6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAC6C;
    }
block_001BAC6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAC6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAC6CU);
        }
        {
            r3 = r8;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001BAC7CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAC84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAC84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAC84;
    }
block_001BAC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAC84U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x945U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAC88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x946U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAC90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC94U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x947U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAC98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAC9CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001BACB8; }
        goto block_001BACA8;
    }
block_001BACA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BACA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BACA8U);
        }
        {
            const uint32_t updatedAddress = 0x001BACB0U + 0x2CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BACA8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BACACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BAF64; }
        goto block_001BACB8;
    }
block_001BACB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BACB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BACB8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BACB8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001BACD8; }
        goto block_001BACC4;
    }
block_001BACC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BACC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BACC4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BACD0U, address);
            }
        }
        if (!(flags.Z())) { goto block_001BAE84; }
        goto block_001BACD8;
    }
block_001BACD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BACD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BACD8U);
        }
        {
            const uint32_t updatedAddress = 0x001BACE0U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BACD8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x001BACE8U + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BACE0U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001BACECU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BACE4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 24U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001BACE8U,
                                           firstAddress + 32U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r12 = value12;
            r14 = value14;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001BACF0U,
                                           firstAddress + 32U);
            }
        }
        {
            const uint32_t operand = 0x00005C00U;
            r0 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r10 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r9 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r8 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAD08U, address);
            }
        }
        goto block_001BAD0C;
    }
block_001BAD0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAD0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAD0CU);
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001BAD0CU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001BAD0CU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001BAD0CU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001BAD10U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001BAD10U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001BAD10U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r7 = r1 + operand;
        }
        {
            const uint32_t address = r8 + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r1 = 0x3F800000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAD30U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BAD34U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAD40U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BAD44U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD48U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD4CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAD50U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BAD54U, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD58U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD5CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD60U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001BAD64U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BAD68U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001BAD6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAD70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD74U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAD78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001BAD7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001BAD80U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAD84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD88U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001BAD8CU, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAD90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAD94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAD98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001BAD9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BADA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BADA4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADACU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADB0U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADB4U, 0xEE609A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADB8U, 0xEEF49A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[19], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_001BAE38; }
        goto block_001BADC4;
    }
block_001BADC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BADC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BADC4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BADCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BADCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BADCC;
    }
block_001BADCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BADCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BADCCU);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BADD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BADD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BADD8;
    }
block_001BADD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BADD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BADD8U);
        }
        {
            const uint32_t address = r13 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BADD8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BADDCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADE0U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADE4U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADE8U, 0xEE411A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BADECU, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001BADF0U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BADF4U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BADF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BADFCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE00U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE04U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE08U, 0xEE411A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE0CU, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001BAE10U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BAE14U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAE18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAE1CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE20U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE24U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE28U, 0xEE411A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001BAE2CU, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001BAE30U, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001BAE34U, address);
            }
        }
        goto block_001BAE38;
    }
block_001BAE38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAE38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAE38U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            r2 = r7;
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAE48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAE48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAE48;
    }
block_001BAE48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAE48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAE48U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r9;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001BAE50U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001BAE50U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001BAE50U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000003F8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001BAE60U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001BAE60U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001BAE60U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAE68U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000003ACU;
            r2 = r2 + operand;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAE78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAE78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAE78;
    }
block_001BAE78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAE78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAE78U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001BAD0C; }
        goto block_001BAE84;
    }
block_001BAE84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAE84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAE84U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAE84U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAE90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAE94U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001BAEA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAEA4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAEACU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001BAF64; }
        goto block_001BAEB8;
    }
block_001BAEB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAEB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAEB8U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002A4U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAECCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAECCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAECC;
    }
block_001BAECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAECCU);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r11 + operand;
        }
        {
            r2 = r5;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAEE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAEE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAEE4;
    }
block_001BAEE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAEE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAEE4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAEE4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAEE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001BAEF8U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001BAEF0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r4;
        }
        if ((flags.N()) == (flags.V())) { goto block_001BAF40; }
        goto block_001BAF10;
    }
block_001BAF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAF10U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000354U;
            r1 = r1 + operand;
        }
        {
            r6 = r1;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAF24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAF24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAF24;
    }
block_001BAF24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAF24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAF24U);
        }
        {
            r2 = r6;
        }
        {
            r1 = r5;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAF34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAF34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAF34;
    }
block_001BAF34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAF34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAF34U);
        }
        {
        }
        {
        }
        goto block_001BAF64;
    }
block_001BAF40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAF40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAF40U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000002FCU;
            r1 = r1 + operand;
        }
        {
            r6 = r1;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAF54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAF54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAF54;
    }
block_001BAF54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAF54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAF54U);
        }
        {
            r2 = r6;
        }
        {
            r1 = r5;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001BAF64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001BAF64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001BAF64;
    }
block_001BAF64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001BAF64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001BAF64U);
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001BAF6CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001BAF6CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001BAF6CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001BAF6CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001BAF6CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001BAF6CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001BAF74U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x0037322CU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnSsh_Update_001DF0A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001DF0A4U:
        goto block_001DF0A4;
    case 0x001DF0DCU:
        goto block_001DF0DC;
    case 0x001DF0E4U:
        goto block_001DF0E4;
    case 0x001DF0F8U:
        goto block_001DF0F8;
    case 0x001DF100U:
        goto block_001DF100;
    case 0x001DF104U:
        goto block_001DF104;
    case 0x001DF110U:
        goto block_001DF110;
    case 0x001DF11CU:
        goto block_001DF11C;
    case 0x001DF124U:
        goto block_001DF124;
    case 0x001DF13CU:
        goto block_001DF13C;
    case 0x001DF148U:
        goto block_001DF148;
    case 0x001DF158U:
        goto block_001DF158;
    case 0x001DF16CU:
        goto block_001DF16C;
    case 0x001DF1ACU:
        goto block_001DF1AC;
    case 0x001DF1B4U:
        goto block_001DF1B4;
    case 0x001DF1D0U:
        goto block_001DF1D0;
    case 0x001DF1DCU:
        goto block_001DF1DC;
    case 0x001DF1F0U:
        goto block_001DF1F0;
    case 0x001DF208U:
        goto block_001DF208;
    case 0x001DF214U:
        goto block_001DF214;
    case 0x001DF228U:
        goto block_001DF228;
    case 0x001DF248U:
        goto block_001DF248;
    case 0x001DF258U:
        goto block_001DF258;
    case 0x001DF264U:
        goto block_001DF264;
    case 0x001DF270U:
        goto block_001DF270;
    case 0x001DF27CU:
        goto block_001DF27C;
    case 0x001DF294U:
        goto block_001DF294;
    case 0x001DF2C4U:
        goto block_001DF2C4;
    case 0x001DF2C8U:
        goto block_001DF2C8;
    case 0x001DF304U:
        goto block_001DF304;
    case 0x001DF30CU:
        goto block_001DF30C;
    case 0x001DF32CU:
        goto block_001DF32C;
    case 0x001DF338U:
        goto block_001DF338;
    case 0x001DF344U:
        goto block_001DF344;
    case 0x001DF350U:
        goto block_001DF350;
    case 0x001DF35CU:
        goto block_001DF35C;
    case 0x001DF370U:
        goto block_001DF370;
    case 0x001DF378U:
        goto block_001DF378;
    case 0x001DF384U:
        goto block_001DF384;
    case 0x001DF39CU:
        goto block_001DF39C;
    case 0x001DF3A8U:
        goto block_001DF3A8;
    case 0x001DF3C0U:
        goto block_001DF3C0;
    case 0x001DF3E0U:
        goto block_001DF3E0;
    case 0x001DF424U:
        goto block_001DF424;
    case 0x001DF44CU:
        goto block_001DF44C;
    case 0x001DF458U:
        goto block_001DF458;
    case 0x001DF464U:
        goto block_001DF464;
    case 0x001DF46CU:
        goto block_001DF46C;
    case 0x001DF478U:
        goto block_001DF478;
    case 0x001DF494U:
        goto block_001DF494;
    case 0x001DF4A4U:
        goto block_001DF4A4;
    case 0x001DF4B0U:
        goto block_001DF4B0;
    case 0x001DF4C4U:
        goto block_001DF4C4;
    case 0x001DF4D8U:
        goto block_001DF4D8;
    case 0x001DF4F4U:
        goto block_001DF4F4;
    case 0x001DF508U:
        goto block_001DF508;
    case 0x001DF53CU:
        goto block_001DF53C;
    case 0x001DF548U:
        goto block_001DF548;
    case 0x001DF564U:
        goto block_001DF564;
    case 0x001DF56CU:
        goto block_001DF56C;
    case 0x001DF578U:
        goto block_001DF578;
    case 0x001DF58CU:
        goto block_001DF58C;
    case 0x001DF598U:
        goto block_001DF598;
    case 0x001DF59CU:
        goto block_001DF59C;
    case 0x001DF5B8U:
        goto block_001DF5B8;
    case 0x001DF5D8U:
        goto block_001DF5D8;
    case 0x001DF5E8U:
        goto block_001DF5E8;
    case 0x001DF5F4U:
        goto block_001DF5F4;
    case 0x001DF600U:
        goto block_001DF600;
    case 0x001DF634U:
        goto block_001DF634;
    case 0x001DF684U:
        goto block_001DF684;
    case 0x001DF6F8U:
        goto block_001DF6F8;
    case 0x001DF700U:
        goto block_001DF700;
    case 0x001DF70CU:
        goto block_001DF70C;
    case 0x001DF76CU:
        goto block_001DF76C;
    case 0x001DF77CU:
        goto block_001DF77C;
    case 0x001DF7A8U:
        goto block_001DF7A8;
    case 0x001DF7B4U:
        goto block_001DF7B4;
    case 0x001DF7C0U:
        goto block_001DF7C0;
    case 0x001DF7D4U:
        goto block_001DF7D4;
    case 0x001DF7E8U:
        goto block_001DF7E8;
    case 0x001DF800U:
        goto block_001DF800;
    case 0x001DF828U:
        goto block_001DF828;
    case 0x001DF83CU:
        goto block_001DF83C;
    case 0x001DF84CU:
        goto block_001DF84C;
    case 0x001DF870U:
        goto block_001DF870;
    case 0x001DF884U:
        goto block_001DF884;
    case 0x001DF894U:
        goto block_001DF894;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001DF0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF0A4U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001DF0A4U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r11 = r1;
        }
        {
            const uint32_t address = 0x001DF0B4U + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001DF0B8U + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0B0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001DF0BCU + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001DF0B8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001DF0B8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001DF0B8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001DF0B8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001DF0B8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001DF0B8U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0C0U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x001DF0CCU + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0C4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r4 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0D0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF11C; }
        goto block_001DF0DC;
    }
block_001DF0DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF0DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF0DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001DF148; }
        goto block_001DF0E4;
    }
block_001DF0E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF0E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF0E4U);
        }
        {
            r0 = r0 & ~(0x00000010U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF0E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF0ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001DF104; }
        goto block_001DF0F8;
    }
block_001DF0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF0F8U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF100U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnSsh_SetColliderScale_00347DD4(frame, context, state, 0x00347DD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF100U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF100;
    }
block_001DF100:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF100U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF100U);
        }
        goto block_001DF148;
    }
block_001DF104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF104U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF110U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnSsh_SetColliderScale_00347DD4(frame, context, state, 0x00347DD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF110U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF110;
    }
block_001DF110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF110U);
        }
        {
        }
        {
        }
        goto block_001DF148;
    }
block_001DF11C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF11CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF11CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF148; }
        goto block_001DF124;
    }
block_001DF124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF124U);
        }
        {
            r0 = r0 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF128U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF12CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = 0x001DF13CU + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF134U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) { goto block_001DF104; }
        goto block_001DF13C;
    }
block_001DF13C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF13CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF13CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF148U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnSsh_SetColliderScale_00347DD4(frame, context, state, 0x00347DD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF148U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF148;
    }
block_001DF148:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF148U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF148U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF148U, address);
            }
            r0 = value;
        }
        {
            r7 = 0x0000001EU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_001DF214; }
        goto block_001DF158;
    }
block_001DF158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF158U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCA4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF158U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF160U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001DF214; }
        goto block_001DF16C;
    }
block_001DF16C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF16CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF16CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA97U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF16CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = r1 & ~(0x00000001U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xA97U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF17CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xAEFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF180U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = r1 & ~(0x00000001U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xAEFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF190U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB47U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF194U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = r1 & ~(0x00000001U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xB47U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF1A4U, address);
            }
        }
        if (!(flags.Z())) { goto block_001DF1B4; }
        goto block_001DF1AC;
    }
block_001DF1AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF1ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF1ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001DF214; }
        goto block_001DF1B4;
    }
block_001DF1B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF1B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF1B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001DF1B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001DF1C4U + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1BCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001DF1C8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF1D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF1D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF1D0;
    }
block_001DF1D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF1D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF1D0U);
        }
        {
            const uint32_t updatedAddress = 0x001DF1D8U + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1D0U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF1DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF1DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF1DC;
    }
block_001DF1DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF1DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF1DCU);
        }
        {
            const uint32_t updatedAddress = 0x001DF1E4U + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1DCU, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x00000007U);
        }
        {
            const uint32_t updatedAddress = r0 + r11;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1E4U, address);
            }
            r2 = value;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001DF1F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF1F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF1F0;
    }
block_001DF1F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF1F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF1F0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t updatedAddress = r5 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1F4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001DF200U + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF1F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = r5;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF208U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetPlayerKnockbackLargeNoDamage_00374BB8(frame, context, state, 0x00374BB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF208U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF208;
    }
block_001DF208:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF208U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF208U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCA4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF208U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xCA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF210U, address);
            }
        }
        goto block_001DF214;
    }
block_001DF214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF214U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA3DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF214U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000008U;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001DF294; }
        goto block_001DF228;
    }
block_001DF228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF228U);
        }
        {
            const uint32_t updatedAddress = 0x001DF230U + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF228U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001DF234U + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF22CU, address);
            }
            r3 = value;
        }
        {
            r9 = 0x00000078U;
        }
        {
            const uint32_t updatedAddress = r0 + r11;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF234U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF238U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000100U;
            r8 = r0 + operand;
        }
        if (flags.Z()) { goto block_001DF2C8; }
        goto block_001DF248;
    }
block_001DF248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF248U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001DF248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF24CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001DF350; }
        goto block_001DF258;
    }
block_001DF258:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF258U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF258U);
        }
        {
            r1 = r3;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF264U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF264U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF264;
    }
block_001DF264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF264U);
        }
        {
            const uint32_t updatedAddress = 0x001DF26CU + 0x1ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF264U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF270U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF270U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF270;
    }
block_001DF270:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF270U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF270U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF270U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001DF350; }
        goto block_001DF27C;
    }
block_001DF27C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF27CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF27CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF27CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF284U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001DF288U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001DF28CU, address);
            }
        }
        goto block_001DF350;
    }
block_001DF294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF294U);
        }
        {
            r0 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA3DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF298U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001DF29CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF2A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF2A8U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF2B0U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x0000003CU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF2BCU, address);
            }
        }
        if (flags.Z()) { goto block_001DF35C; }
        goto block_001DF2C4;
    }
block_001DF2C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF2C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF2C4U);
        }
        goto block_001DF35C;
    }
block_001DF2C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF2C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF2C8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x98DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF2C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r12 = r5 + operand;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t value = r1 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x0000017CU;
            r12 = r12 + operand;
        }
        if (!(flags.Z())) {
            r0 = r1 & ~(0x00000002U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r12 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF2E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x9E5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF2E4U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000800U;
            r12 = r5 + operand;
        }
        {
            const uint32_t value = r1 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x000001D4U;
            r12 = r12 + operand;
        }
        if (!(flags.Z())) {
            r0 = r1 & ~(0x00000002U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r12 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF2FCU, address);
            }
        }
        if (!(flags.Z())) { goto block_001DF30C; }
        goto block_001DF304;
    }
block_001DF304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF304U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF35C; }
        goto block_001DF30C;
    }
block_001DF30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF30CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001DF30CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xCA4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF310U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0xCA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF31CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF320U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001DF350; }
        goto block_001DF32C;
    }
block_001DF32C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF32CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF32CU);
        }
        {
            r1 = r3;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF338U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF338U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF338;
    }
block_001DF338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF338U);
        }
        {
            const uint32_t updatedAddress = 0x001DF340U + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF338U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF344U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF344U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF344;
    }
block_001DF344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF344U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF344U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF27C; }
        goto block_001DF350;
    }
block_001DF350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF350U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF350U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF358U, address);
            }
        }
        goto block_001DF35C;
    }
block_001DF35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF35CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF35CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001DF368U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF360U, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x001DF36CU + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF364U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001DF464; }
        goto block_001DF370;
    }
block_001DF370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF370U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000078U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_001DF3A8; }
        goto block_001DF378;
    }
block_001DF378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF378U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF378U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001DF3A8; }
        goto block_001DF384;
    }
block_001DF384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF384U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001DF384U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            r1 = r3;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF39CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF39CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF39C;
    }
block_001DF39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF39CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF39CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF424; }
        goto block_001DF3A8;
    }
block_001DF3A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF3A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF3A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF3A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF3B8U, address);
            }
        }
        if (flags.Z()) { goto block_001DF424; }
        goto block_001DF3C0;
    }
block_001DF3C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF3C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF3C0U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000B00U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001DF3C8U, address);
            }
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t operand = 0x000000FEU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF3E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF3E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF3E0;
    }
block_001DF3E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF3E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF3E0U);
        }
        {
        }
        {
        }
        goto block_001DF4A4;
    }
block_001DF424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF424U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF424U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001DF430U - 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF428U, address);
            }
            r1 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF430U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001DF434U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF438U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001DF444U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF44CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF44CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF44C;
    }
block_001DF44C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF44CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF44CU);
        }
        {
            const uint32_t updatedAddress = 0x001DF454U - 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF44CU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF458U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF458U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF458;
    }
block_001DF458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF458U);
        }
        {
        }
        {
        }
        goto block_001DF4A4;
    }
block_001DF464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF464U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF46CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_00370734_00370734(frame, context, state, 0x00370734U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF46CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF46C;
    }
block_001DF46C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF46CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF46CU);
        }
        {
            r0 = r5;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF478U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdatePos_0036B96C(frame, context, state, 0x0036B96CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF478U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF478;
    }
block_001DF478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF478U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r11;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF494U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF494U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF494;
    }
block_001DF494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF494U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x978U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF494U, address);
            }
            r2 = value;
        }
        {
            r1 = r11;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001DF4A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF4A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF4A4;
    }
block_001DF4A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF4A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF4A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF4A4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF4D8; }
        goto block_001DF4B0;
    }
block_001DF4B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF4B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF4B0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF4B0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF4B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF4B8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001DF56C; }
        goto block_001DF4C4;
    }
block_001DF4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF4C4U);
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t operand = 0x000007D0U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000007D0U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF4D0U, address);
            }
        }
        goto block_001DF56C;
    }
block_001DF4D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF4D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF4D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF4D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF4E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF4E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001DF53C; }
        goto block_001DF4F4;
    }
block_001DF4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF4F4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF500U, address);
            }
        }
        if (flags.Z()) { goto block_001DF53C; }
        goto block_001DF508;
    }
block_001DF508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF508U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF50CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001DF518U + 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF510U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF514U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF51CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF520U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001DF52CU + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF524U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF528U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF52CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF534U, address);
            }
        }
        goto block_001DF564;
    }
block_001DF53C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF53CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF53CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF53CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001DF564; }
        goto block_001DF548;
    }
block_001DF548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF548U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001DF54CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF550U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = r8;
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF564U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF564U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF564;
    }
block_001DF564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF564U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF564U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF568U, address);
            }
        }
        goto block_001DF56C;
    }
block_001DF56C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF56CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF56CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF56CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001DF58C; }
        goto block_001DF578;
    }
block_001DF578:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF578U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF578U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0xA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF584U, address);
            }
        }
        if (!(flags.Z())) { goto block_001DF59C; }
        goto block_001DF58C;
    }
block_001DF58C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF58CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF58CU);
        }
        {
            r1 = 0x0000003CU;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF598U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_S16Offset_003702c8_003702C8(frame, context, state, 0x003702C8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF598;
    }
block_001DF598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF598U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF598U, address);
            }
        }
        goto block_001DF59C;
    }
block_001DF59C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF59CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF59CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF59CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r4 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF5A4U, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r4 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001DF5A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF5ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001DF5F4; }
        goto block_001DF5B8;
    }
block_001DF5B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF5B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF5B8U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r11 + operand;
        }
        {
            const uint32_t operand = 0x0000038CU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r4 = r2;
        }
        {
            r6 = r1;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF5D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF5D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF5D8;
    }
block_001DF5D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF5D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF5D8U);
        }
        {
            r2 = r4;
        }
        {
            r1 = r6;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF5E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF5E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF5E8;
    }
block_001DF5E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF5E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF5E8U);
        }
        {
        }
        {
        }
        goto block_001DF894;
    }
block_001DF5F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF5F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF5F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF5F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001DF7B4; }
        goto block_001DF600;
    }
block_001DF600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF600U);
        }
        {
            const uint32_t updatedAddress = 0x001DF608U + 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF600U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x001DF610U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF608U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001DF614U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF60CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 24U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001DF610U,
                                           firstAddress + 32U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r12 = value12;
            r14 = value14;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001DF618U,
                                           firstAddress + 32U);
            }
        }
        {
            const uint32_t operand = 0x00005C00U;
            r0 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000B00U;
            r9 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r10 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r8 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF630U, address);
            }
        }
        goto block_001DF634;
    }
block_001DF634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF634U);
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001DF634U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001DF634U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001DF634U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001DF638U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001DF638U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001DF638U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r1 = r6 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r7 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF648U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF64CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000148U;
            r1 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF658U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001DF65CU, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF660U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF664U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF668U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001DF66CU, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF670U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF674U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF678U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001DF67CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF684U;
            const Oot3dWholeAotFlow callFlow = Oot3dAotCallExternal(context, 0x00372224U, frame, state, commitState, reloadState);
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF684U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF684;
    }
block_001DF684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF684U);
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF684U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF688U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF68CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001DF690U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001DF694U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001DF698U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            r1 = 0x3F800000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF6A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF6A8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF6ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001DF6B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001DF6B4U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001DF6B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF6BCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001DF6C0U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF6C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF6C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF6CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001DF6D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF6D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xFCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF6D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF6E0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF6E4U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF6E8U, 0xEE60AA09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF6ECU, 0xEEF4AA48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_001DF76C; }
        goto block_001DF6F8;
    }
block_001DF6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF6F8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF700;
    }
block_001DF700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF700U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF70CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF70CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF70C;
    }
block_001DF70C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF70CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF70CU);
        }
        {
            const uint32_t address = r13 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF70CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF710U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF714U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF718U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF71CU, 0xEE411A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF720U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001DF724U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001DF728U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF72CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF730U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF734U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF738U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF73CU, 0xEE411A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF740U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001DF744U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001DF748U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF74CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF750U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF754U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF758U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF75CU, 0xEE411A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001DF760U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001DF764U, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001DF768U, address);
            }
        }
        goto block_001DF76C;
    }
block_001DF76C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF76CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF76CU);
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            r2 = r7;
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF77CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF77CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF77C;
    }
block_001DF77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF77CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001DF784U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001DF784U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001DF784U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000AD0U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001DF790U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001DF790U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001DF790U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF798U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000284U;
            r2 = r2 + operand;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF7A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF7A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF7A8;
    }
block_001DF7A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF7A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF7A8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001DF634; }
        goto block_001DF7B4;
    }
block_001DF7B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF7B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF7B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF7B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001DF7D4; }
        goto block_001DF7C0;
    }
block_001DF7C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF7C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF7C0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001DF7CCU, address);
            }
        }
        if (!(flags.Z())) { goto block_001DF894; }
        goto block_001DF7D4;
    }
block_001DF7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF7D4U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000017CU;
            r1 = r1 + operand;
        }
        {
            r4 = r1;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF7E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF7E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF7E8;
    }
block_001DF7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF7E8U);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r11 + operand;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r4 = r1;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF800;
    }
block_001DF800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF800U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF800U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF804U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001DF814U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF80CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001DF870; }
        goto block_001DF828;
    }
block_001DF828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF828U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000022CU;
            r1 = r1 + operand;
        }
        {
            r6 = r1;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF83CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF83CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF83C;
    }
block_001DF83C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF83CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF83CU);
        }
        {
            r2 = r6;
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF84CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF84CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF84C;
    }
block_001DF84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF84CU);
        }
        {
        }
        {
        }
        goto block_001DF894;
    }
block_001DF870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF870U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r1 = r1 + operand;
        }
        {
            r6 = r1;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF884U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF884U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF884;
    }
block_001DF884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF884U);
        }
        {
            r2 = r6;
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001DF894U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001DF894U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001DF894;
    }
block_001DF894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001DF894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001DF894U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF894U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF8A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 + operand;
        }
        if (flags.Z()) {
            const uint32_t address = 0x001DF8B0U + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001DF8A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001DF8ACU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001DF8ACU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001DF8ACU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001DF8ACU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001DF8ACU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001DF8ACU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001DF8B4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x0037322CU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnVali_Update_001F8848(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001F8848U:
        goto block_001F8848;
    case 0x001F8878U:
        goto block_001F8878;
    case 0x001F8884U:
        goto block_001F8884;
    case 0x001F88C4U:
        goto block_001F88C4;
    case 0x001F88D8U:
        goto block_001F88D8;
    case 0x001F88F4U:
        goto block_001F88F4;
    case 0x001F8908U:
        goto block_001F8908;
    case 0x001F8910U:
        goto block_001F8910;
    case 0x001F8924U:
        goto block_001F8924;
    case 0x001F8930U:
        goto block_001F8930;
    case 0x001F893CU:
        goto block_001F893C;
    case 0x001F894CU:
        goto block_001F894C;
    case 0x001F8958U:
        goto block_001F8958;
    case 0x001F8960U:
        goto block_001F8960;
    case 0x001F896CU:
        goto block_001F896C;
    case 0x001F8978U:
        goto block_001F8978;
    case 0x001F8984U:
        goto block_001F8984;
    case 0x001F8994U:
        goto block_001F8994;
    case 0x001F89BCU:
        goto block_001F89BC;
    case 0x001F89CCU:
        goto block_001F89CC;
    case 0x001F89D8U:
        goto block_001F89D8;
    case 0x001F89E4U:
        goto block_001F89E4;
    case 0x001F89F0U:
        goto block_001F89F0;
    case 0x001F8A0CU:
        goto block_001F8A0C;
    case 0x001F8A38U:
        goto block_001F8A38;
    case 0x001F8A44U:
        goto block_001F8A44;
    case 0x001F8A60U:
        goto block_001F8A60;
    case 0x001F8A80U:
        goto block_001F8A80;
    case 0x001F8A88U:
        goto block_001F8A88;
    case 0x001F8AB8U:
        goto block_001F8AB8;
    case 0x001F8AC4U:
        goto block_001F8AC4;
    case 0x001F8ACCU:
        goto block_001F8ACC;
    case 0x001F8AECU:
        goto block_001F8AEC;
    case 0x001F8B0CU:
        goto block_001F8B0C;
    case 0x001F8B14U:
        goto block_001F8B14;
    case 0x001F8B24U:
        goto block_001F8B24;
    case 0x001F8B30U:
        goto block_001F8B30;
    case 0x001F8B4CU:
        goto block_001F8B4C;
    case 0x001F8B68U:
        goto block_001F8B68;
    case 0x001F8B78U:
        goto block_001F8B78;
    case 0x001F8B90U:
        goto block_001F8B90;
    case 0x001F8B9CU:
        goto block_001F8B9C;
    case 0x001F8BB4U:
        goto block_001F8BB4;
    case 0x001F8BC4U:
        goto block_001F8BC4;
    case 0x001F8BD4U:
        goto block_001F8BD4;
    case 0x001F8BE4U:
        goto block_001F8BE4;
    case 0x001F8BF0U:
        goto block_001F8BF0;
    case 0x001F8C00U:
        goto block_001F8C00;
    case 0x001F8C10U:
        goto block_001F8C10;
    case 0x001F8C1CU:
        goto block_001F8C1C;
    case 0x001F8C40U:
        goto block_001F8C40;
    case 0x001F8C7CU:
        goto block_001F8C7C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001F8848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8848U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001F8848U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r6 = r1;
        }
        {
            r4 = r0;
        }
        {
            r7 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = 0x001F8860U + 0x428U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8858U, address);
            }
            r9 = value;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001F885CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001F885CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7C0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8864U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6C0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8868U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r1 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_001F8884; }
        goto block_001F8878;
    }
block_001F8878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8878U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x740U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8878U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001F88C4; }
        goto block_001F8884;
    }
block_001F8884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8884U);
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8888U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x740U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F888CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x740U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8894U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8898U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F88A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001F88A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88A8U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F88B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88B4U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F88BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001F88C0U, address);
            }
        }
        goto block_001F88C4;
    }
block_001F88C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F88C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F88C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001F88D0U + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88C8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001F88D4U + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88CCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001F8B68; }
        goto block_001F88D8;
    }
block_001F88D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F88D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F88D8U);
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F88DCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r4 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000003C8U;
            r1 = r1 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F88F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetDropFlag_00375FD0(frame, context, state, 0x00375FD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F88F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F88F4;
    }
block_001F88F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F88F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F88F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F88FCU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001F8B68; }
        goto block_001F8908;
    }
block_001F8908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8908U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8910U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ApplyDamage_00375EB8(frame, context, state, 0x00375EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8910U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8910;
    }
block_001F8910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8910U);
        }
        {
            const uint32_t updatedAddress = 0x001F8918U + 0x37CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8910U, address);
            }
            r10 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r8 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000600U;
            r5 = r4 + operand;
        }
        if (!(flags.Z())) { goto block_001F894C; }
        goto block_001F8924;
    }
block_001F8924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8924U);
        }
        {
            const uint32_t updatedAddress = 0x001F892CU + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8924U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8930U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8930U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8930;
    }
block_001F8930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8930U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F893CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSoundFlaggedTimer_00375B70(frame, context, state, 0x00375B70U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F893CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F893C;
    }
block_001F893C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F893CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F893CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F893CU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8944U, address);
            }
        }
        goto block_001F896C;
    }
block_001F894C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F894CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F894CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F894CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001F8978; }
        goto block_001F8958;
    }
block_001F8958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8958U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001F8B14; }
        goto block_001F8960;
    }
block_001F8960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8960U);
        }
        {
            const uint32_t updatedAddress = 0x001F8968U + 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8960U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F896CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F896CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F896C;
    }
block_001F896C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F896CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F896CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F896CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001F89D8; }
        goto block_001F8978;
    }
block_001F8978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8978U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8978U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r10, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001F8B68; }
        goto block_001F8984;
    }
block_001F8984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8984U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t address = 0x001F8990U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8988U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8994U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8994U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8994;
    }
block_001F8994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8994U);
        }
        {
            r0 = 0x00000078U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001F8998U, address);
            }
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001F899CU, address);
            }
        }
        {
            r3 = 0x00000050U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001F89A4U, address);
            }
        }
        {
            r3 = 0x00200000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F89BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F89BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F89BC;
    }
block_001F89BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F89BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F89BCU);
        }
        {
            const uint32_t updatedAddress = 0x001F89C4U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F89BCU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7D4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001F89C4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F89CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F89CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F89CC;
    }
block_001F89CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F89CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F89CCU);
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001F89CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001F89D0U, address);
            }
        }
        goto block_001F8B68;
    }
block_001F89D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F89D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F89D8U);
        }
        {
            const uint32_t updatedAddress = 0x001F89E0U + 0x2C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F89D8U, address);
            }
            r11 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001F8A80; }
        goto block_001F89E4;
    }
block_001F89E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F89E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F89E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F89E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r10, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001F8A38; }
        goto block_001F89F0;
    }
block_001F89F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F89F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F89F0U);
        }
        {
            r3 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001F89F4U, address);
            }
        }
        {
            r3 = 0x00200000U;
        }
        {
            r2 = 0x00000096U;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8A0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8A0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8A0C;
    }
block_001F8A0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8A0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8A0CU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8A10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001F8A14U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8A18U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8A20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8A24U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8A2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001F8A30U, address);
            }
        }
        goto block_001F8B68;
    }
block_001F8A38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8A38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8A38U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8A44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_PlayOnce_00373D40(frame, context, state, 0x00373D40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8A44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8A44;
    }
block_001F8A44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8A44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8A44U);
        }
        {
            r3 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001F8A48U, address);
            }
        }
        {
            r3 = 0x00200000U;
        }
        {
            r2 = 0x00000096U;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8A60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8A60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8A60;
    }
block_001F8A60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8A60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8A60U);
        }
        {
            r1 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001F8A64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8B8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8A68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8A6CU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8A74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001F8A78U, address);
            }
        }
        goto block_001F8B68;
    }
block_001F8A80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8A80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8A80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001F8AC4; }
        goto block_001F8A88;
    }
block_001F8A88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8A88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8A88U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001F8A8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8A90U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000001EU;
        }
        {
            r2 = 0x00000096U;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8AA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001F8AA4U, address);
            }
        }
        {
            r3 = 0x00200000U;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8AB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8AB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8AB8;
    }
block_001F8AB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8AB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8AB8U);
        }
        {
            const uint32_t updatedAddress = 0x001F8AC0U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8AB8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8ABCU, address);
            }
        }
        goto block_001F8B68;
    }
block_001F8AC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8AC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8AC4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001F8B0C; }
        goto block_001F8ACC;
    }
block_001F8ACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8ACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8ACCU);
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001F8ACCU, address);
            }
        }
        {
            r3 = 0x00000024U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001F8AD4U, address);
            }
        }
        {
            r3 = 0x00200000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8AECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8AECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8AEC;
    }
block_001F8AEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8AECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8AECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8AECU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8AF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001F8B00U + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8AF8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001F8B00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8B04U, address);
            }
        }
        goto block_001F8B68;
    }
block_001F8B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B0CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001F8B24; }
        goto block_001F8B14;
    }
block_001F8B14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x6A5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001F8B1CU, address);
            }
        }
        goto block_001F8B68;
    }
block_001F8B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B24U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8B30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_PlayOnce_00373D40(frame, context, state, 0x00373D40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8B30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8B30;
    }
block_001F8B30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B30U);
        }
        {
            r3 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001F8B34U, address);
            }
        }
        {
            r3 = 0x00200000U;
        }
        {
            r2 = 0x00000096U;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8B4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8B4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8B4C;
    }
block_001F8B4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B4CU);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001F8B50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8B8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001F8B54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B58U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001F8B60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001F8B64U, address);
            }
        }
        goto block_001F8B68;
    }
block_001F8B68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B68U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B68U, address);
            }
            r2 = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001F8B78U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8B78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8B78;
    }
block_001F8B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B78U);
        }
        {
            const uint32_t updatedAddress = 0x001F8B80U + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B78U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B7CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x001F8B8CU + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B84U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001F8C7C; }
        goto block_001F8B90;
    }
block_001F8B90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B90U);
        }
        {
            const uint32_t operand = 0x000007B0U;
            r1 = r4 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8B9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8B9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8B9C;
    }
block_001F8B9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8B9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8B9CU);
        }
        {
            const uint32_t updatedAddress = 0x001F8BA4U + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8B9CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8BA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001F8BE4; }
        goto block_001F8BB4;
    }
block_001F8BB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8BB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8BB4U);
        }
        {
            const uint32_t operand = 0x000006B0U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8BC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8BC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8BC4;
    }
block_001F8BC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8BC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8BC4U);
        }
        {
            const uint32_t operand = 0x00000730U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8BD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8BD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8BD4;
    }
block_001F8BD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8BD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8BD4U);
        }
        {
            const uint32_t operand = 0x000007B0U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8BE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8BE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8BE4;
    }
block_001F8BE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8BE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8BE4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8BE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001F8C00; }
        goto block_001F8BF0;
    }
block_001F8BF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8BF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8BF0U);
        }
        {
            const uint32_t operand = 0x000007B0U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8C00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8C00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8C00;
    }
block_001F8C00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8C00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8C00U);
        }
        {
            const uint32_t operand = 0x000007B0U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8C10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8C10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8C10;
    }
block_001F8C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8C10U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001F8C1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetFocus_0037322C(frame, context, state, 0x0037322CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001F8C1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001F8C1C;
    }
block_001F8C1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8C1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8C1CU);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001F8C28U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001F8C2CU, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001F8C30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8C34U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001F8C7C; }
        goto block_001F8C40;
    }
block_001F8C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8C40U);
        }
        {
            const uint32_t operand = 0x0000000AU;
            r1 = operand - r1;
        }
        {
            const uint32_t updatedAddress = 0x001F8C4CU + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8C44U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r3 + operand;
        }
        {
            const uint32_t address = r12 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8C50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r3 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001F8C58U, address);
            }
        }
        {
            const uint32_t address = r12 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8C5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r3 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001F8C64U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8C68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001F8C6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001F8C70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8B8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001F8C78U, address);
            }
        }
        goto block_001F8C7C;
    }
block_001F8C7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001F8C7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001F8C7CU);
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001F8C80U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001F8C80U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001F8C84U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnIceHono_Init_0022B190(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0022B190U:
        goto block_0022B190;
    case 0x0022B1C0U:
        goto block_0022B1C0;
    case 0x0022B1DCU:
        goto block_0022B1DC;
    case 0x0022B1E8U:
        goto block_0022B1E8;
    case 0x0022B1F4U:
        goto block_0022B1F4;
    case 0x0022B25CU:
        goto block_0022B25C;
    case 0x0022B260U:
        goto block_0022B260;
    case 0x0022B270U:
        goto block_0022B270;
    case 0x0022B27CU:
        goto block_0022B27C;
    case 0x0022B28CU:
        goto block_0022B28C;
    case 0x0022B298U:
        goto block_0022B298;
    case 0x0022B2B0U:
        goto block_0022B2B0;
    case 0x0022B2BCU:
        goto block_0022B2BC;
    case 0x0022B2D0U:
        goto block_0022B2D0;
    case 0x0022B2DCU:
        goto block_0022B2DC;
    case 0x0022B2F8U:
        goto block_0022B2F8;
    case 0x0022B304U:
        goto block_0022B304;
    case 0x0022B348U:
        goto block_0022B348;
    case 0x0022B35CU:
        goto block_0022B35C;
    case 0x0022B368U:
        goto block_0022B368;
    case 0x0022B3F4U:
        goto block_0022B3F4;
    case 0x0022B3FCU:
        goto block_0022B3FC;
    case 0x0022B40CU:
        goto block_0022B40C;
    case 0x0022B410U:
        goto block_0022B410;
    case 0x0022B414U:
        goto block_0022B414;
    case 0x0022B424U:
        goto block_0022B424;
    case 0x0022B490U:
        goto block_0022B490;
    case 0x0022B4A0U:
        goto block_0022B4A0;
    case 0x0022B4ACU:
        goto block_0022B4AC;
    case 0x0022B4C4U:
        goto block_0022B4C4;
    case 0x0022B4D4U:
        goto block_0022B4D4;
    case 0x0022B4E8U:
        goto block_0022B4E8;
    case 0x0022B504U:
        goto block_0022B504;
    case 0x0022B508U:
        goto block_0022B508;
    case 0x0022B51CU:
        goto block_0022B51C;
    case 0x0022B524U:
        goto block_0022B524;
    case 0x0022B530U:
        goto block_0022B530;
    case 0x0022B538U:
        goto block_0022B538;
    case 0x0022B550U:
        goto block_0022B550;
    case 0x0022B5DCU:
        goto block_0022B5DC;
    case 0x0022B5F4U:
        goto block_0022B5F4;
    case 0x0022B60CU:
        goto block_0022B60C;
    case 0x0022B62CU:
        goto block_0022B62C;
    case 0x0022B640U:
        goto block_0022B640;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0022B190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B190U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0022B190U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = r0;
        }
        {
            r7 = r1;
        }
        {
            r8 = 0x000000FFU;
        }
        {
            r9 = 0x00000000U;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022B1A4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0022B1A4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0022B1A4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0022B1A4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0022B1A4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0022B1A4U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1B0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0022B1BCU + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1B4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022B27C; }
        goto block_0022B1C0;
    }
block_0022B1C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B1C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B1C0U);
        }
        {
            const uint32_t updatedAddress = 0x0022B1C8U + 0x3A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1C0U, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = 0x0022B1CCU + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1C4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0022B1D0U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1C8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0022B1D4U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1CCU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0022B1D8U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1D0U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022B2F8; }
        goto block_0022B1DC;
    }
block_0022B1DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B1DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B1DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022B414; }
        goto block_0022B1E8;
    }
block_0022B1E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B1E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B1E8U);
        }
        {
            const uint32_t updatedAddress = 0x0022B1F0U + 0x380U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1E8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B1F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B1F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B1F4;
    }
block_0022B1F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B1F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B1F4U);
        }
        {
            const uint32_t address = 0x0022B1FCU + 888U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022B200U + 0x378U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B1F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B1FCU, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B200U, address);
            }
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B204U, address);
            }
        }
        {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0022B208U, address);
            }
        }
        {
            const uint32_t address = r4 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0022B20CU, address);
            }
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0022B210U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B214U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B218U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0022B224U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B21CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0022B228U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B220U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r5 = r4;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B22CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B234U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B238U, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B23CU, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B240U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r6 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022B24CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B250U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022B3F4; }
        goto block_0022B25C;
    }
block_0022B25C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B25CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B25CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B260U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B260U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B260;
    }
block_0022B260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B260U);
        }
        {
            const uint32_t address = 0x0022B268U + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B260U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B264U, 0xEE400A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 432U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0022B268U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B270U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B270U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B270;
    }
block_0022B270:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B270U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B270U);
        }
        {
            const uint32_t address = 0x0022B278U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B270U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B274U, 0xEE00AA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_0022B410;
    }
block_0022B27C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B27CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B27CU);
        }
        {
            const uint32_t updatedAddress = 0x0022B284U + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B27CU, address);
            }
            r1 = value;
        }
        {
            r5 = r4;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B28CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B28CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B28C;
    }
block_0022B28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B28CU);
        }
        {
            const uint32_t address = 0x0022B294U + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B28CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B298U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B298U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B298;
    }
block_0022B298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B298U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B298U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0022B2A4U + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B29CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B2A4U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B2B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetFocus_0037322C(frame, context, state, 0x0037322CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B2B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B2B0;
    }
block_0022B2B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B2B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B2B0U);
        }
        {
            const uint32_t operand = 0x000001B4U;
            r1 = r5 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B2BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B2BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B2BC;
    }
block_0022B2BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B2BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B2BCU);
        }
        {
            const uint32_t updatedAddress = 0x0022B2C4U + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B2BCU, address);
            }
            r3 = value;
        }
        {
            r2 = r5;
        }
        {
            const uint32_t operand = 0x000001B4U;
            r1 = r5 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B2D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinder_00353D24(frame, context, state, 0x00353D24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B2D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B2D0;
    }
block_0022B2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B2D0U);
        }
        {
            const uint32_t operand = 0x000001B4U;
            r1 = r5 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B2DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B2DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B2DC;
    }
block_0022B2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B2DCU);
        }
        {
            const uint32_t updatedAddress = 0x0022B2E4U + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B2DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022B2E0U, address);
            }
        }
        {
            const uint32_t address = 0x0022B2ECU + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B2E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B2E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022B2ECU, address);
            }
        }
        {
            const uint32_t address = r5 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B2F0U, address);
            }
        }
        goto block_0022B414;
    }
block_0022B2F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B2F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B2F8U);
        }
        {
            const uint32_t updatedAddress = 0x0022B300U + 0x2A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B2F8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B304U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B304U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B304;
    }
block_0022B304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B304U);
        }
        {
            const uint32_t address = 0x0022B30CU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B304U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r5 = r4;
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B30CU, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B310U, address);
            }
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B314U, address);
            }
        }
        {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0022B318U, address);
            }
        }
        {
            const uint32_t address = r4 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0022B31CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B320U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B324U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B328U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B32CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B334U, address);
            }
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0022B338U, address);
            }
        }
        {
            const uint32_t operand = 0x000001B4U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B348U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B348U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B348;
    }
block_0022B348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B348U);
        }
        {
            const uint32_t updatedAddress = 0x0022B350U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B348U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000001B4U;
            r1 = r5 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B35CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinder_00353D24(frame, context, state, 0x00353D24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B35CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B35C;
    }
block_0022B35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B35CU);
        }
        {
            const uint32_t operand = 0x000001B4U;
            r1 = r5 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B368U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B368U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B368;
    }
block_0022B368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B368U);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B368U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0022B374U + 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B36CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B370U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0022B37CU + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B374U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B378U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B388U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 500U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B38CU, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B390U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B394U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0022B3A0U + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B398U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B39CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x000000FDU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B3B0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 504U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B3B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B3B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0022B3C4U + 0x1F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B3BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B3C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B3C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B3CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B3D4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B3D8U, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B3DCU, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B3E0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r6 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B3E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022B3ECU, address);
            }
        }
        goto block_0022B414;
    }
block_0022B3F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B3F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B3F4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B3FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B3FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B3FC;
    }
block_0022B3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B3FCU);
        }
        {
            const uint32_t address = 0x0022B404U + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B3FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B400U, 0xEE400A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 432U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0022B404U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B40C;
    }
block_0022B40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B40CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B40CU, 0xEE00AA08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        goto block_0022B410;
    }
block_0022B410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B410U);
        }
        {
            const uint32_t address = r5 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0022B410U, address);
            }
        }
        goto block_0022B414;
    }
block_0022B414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B414U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B414U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022B4D4; }
        goto block_0022B424;
    }
block_0022B424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B424U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0022B428U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0022B42CU, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B430U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x0000000AU;
        }
        {
            r3 = 0x000000FFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B43CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = 0x000000D2U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B450U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B454U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B458U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r1 = 0x0000009BU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B46CU, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B470U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B474U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000210U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B488U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B490U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Lights_PointNoGlowSetInfo_003591E4(frame, context, state, 0x003591E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B490U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B490;
    }
block_0022B490:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B490U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B490U);
        }
        {
            const uint32_t operand = 0x00000210U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000A70U;
            r1 = r7 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B4A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_LightContext_InsertLight_0034FAA8(frame, context, state, 0x0034FAA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B4A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B4A0;
    }
block_0022B4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B4A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x20CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B4A0U, address);
            }
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B4ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B4ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B4AC;
    }
block_0022B4AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B4ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B4ACU);
        }
        {
            const uint32_t address = 0x0022B4B4U + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B4ACU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B4B0U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B4B4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r6 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B4BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B4C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B4C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B4C4;
    }
block_0022B4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B4C4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B4C4U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B4C8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r6 + 0xAEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B4D0U, address);
            }
        }
        goto block_0022B4D4;
    }
block_0022B4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B4D4U);
        }
        {
            r6 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x19AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0022B4D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B4DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0x3U));
        }
        if (flags.C()) { goto block_0022B504; }
        goto block_0022B4E8;
    }
block_0022B4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B4E8U);
        }
        {
            const uint32_t updatedAddress = 0x0022B4F0U + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B4E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B4F0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_0022B508; }
        goto block_0022B504;
    }
block_0022B504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B504U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0022B508;
    }
block_0022B508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B508U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r7 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0022B514U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B50CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B510U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0022B550; }
        goto block_0022B51C;
    }
block_0022B51C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B51CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B51CU);
        }
        {
            const uint32_t updatedAddress = 0x0022B524U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B51CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B524U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B524U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B524;
    }
block_0022B524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B524U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0022B550; }
        goto block_0022B530;
    }
block_0022B530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B530U);
        }
        {
            const uint32_t updatedAddress = 0x0022B538U + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B530U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B538U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B538U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B538;
    }
block_0022B538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B538U);
        }
        {
            const uint32_t updatedAddress = 0x0022B540U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B538U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022B544U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B53CU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0022B54CU + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B544U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0022B550;
    }
block_0022B550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B550U);
        }
        {
            const uint32_t updatedAddress = 0x0022B558U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B550U, address);
            }
            r0 = value;
        }
        goto block_0022B5DC;
    }
block_0022B5DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B5DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B5DCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B5DCU, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B5E0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000065U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B5E8U, address);
            }
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B5F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMBByIndex_00358EF8(frame, context, state, 0x00358EF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B5F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B5F4;
    }
block_0022B5F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B5F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B5F4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B5F4U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B600U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0022B60CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r3, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B60CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B60C;
    }
block_0022B60C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B60CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B60CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B60CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B610U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B614U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0022B618U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0022B61CU, address);
            }
        }
        {
            r1 = 0x0000003AU;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B62CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B62CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B62C;
    }
block_0022B62C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B62CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B62CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B62CU, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B634U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B640U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B640U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B640;
    }
block_0022B640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B640U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B640U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B644U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0022B648U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B64CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B650U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022B654U, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022B65CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022B65CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022B65CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022B65CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022B65CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022B65CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0022B660U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0029f8a0_0029F8A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0029F8A0U:
        goto block_0029F8A0;
    case 0x0029F8C4U:
        goto block_0029F8C4;
    case 0x0029F8D8U:
        goto block_0029F8D8;
    case 0x0029F8ECU:
        goto block_0029F8EC;
    case 0x0029F958U:
        goto block_0029F958;
    case 0x0029F96CU:
        goto block_0029F96C;
    case 0x0029F978U:
        goto block_0029F978;
    case 0x0029F984U:
        goto block_0029F984;
    case 0x0029F990U:
        goto block_0029F990;
    case 0x0029F9A0U:
        goto block_0029F9A0;
    case 0x0029F9BCU:
        goto block_0029F9BC;
    case 0x0029F9D8U:
        goto block_0029F9D8;
    case 0x0029F9E4U:
        goto block_0029F9E4;
    case 0x0029FA44U:
        goto block_0029FA44;
    case 0x0029FA4CU:
        goto block_0029FA4C;
    case 0x0029FA58U:
        goto block_0029FA58;
    case 0x0029FA64U:
        goto block_0029FA64;
    case 0x0029FA80U:
        goto block_0029FA80;
    case 0x0029FAA0U:
        goto block_0029FAA0;
    case 0x0029FABCU:
        goto block_0029FABC;
    case 0x0029FAD8U:
        goto block_0029FAD8;
    case 0x0029FAF4U:
        goto block_0029FAF4;
    case 0x0029FB44U:
        goto block_0029FB44;
    case 0x0029FB70U:
        goto block_0029FB70;
    case 0x0029FB88U:
        goto block_0029FB88;
    case 0x0029FB98U:
        goto block_0029FB98;
    case 0x0029FBA8U:
        goto block_0029FBA8;
    case 0x0029FBB8U:
        goto block_0029FBB8;
    case 0x0029FBC8U:
        goto block_0029FBC8;
    case 0x0029FBE4U:
        goto block_0029FBE4;
    case 0x0029FBF0U:
        goto block_0029FBF0;
    case 0x0029FC00U:
        goto block_0029FC00;
    case 0x0029FC0CU:
        goto block_0029FC0C;
    case 0x0029FC24U:
        goto block_0029FC24;
    case 0x0029FC30U:
        goto block_0029FC30;
    case 0x0029FC48U:
        goto block_0029FC48;
    case 0x0029FC54U:
        goto block_0029FC54;
    case 0x0029FC6CU:
        goto block_0029FC6C;
    case 0x0029FC98U:
        goto block_0029FC98;
    case 0x0029FC9CU:
        goto block_0029FC9C;
    case 0x0029FCC4U:
        goto block_0029FCC4;
    case 0x0029FCF0U:
        goto block_0029FCF0;
    case 0x0029FD18U:
        goto block_0029FD18;
    case 0x0029FD70U:
        goto block_0029FD70;
    case 0x0029FD80U:
        goto block_0029FD80;
    case 0x0029FD8CU:
        goto block_0029FD8C;
    case 0x0029FDA4U:
        goto block_0029FDA4;
    case 0x0029FDECU:
        goto block_0029FDEC;
    case 0x0029FE10U:
        goto block_0029FE10;
    case 0x0029FE20U:
        goto block_0029FE20;
    case 0x0029FE24U:
        goto block_0029FE24;
    case 0x0029FE44U:
        goto block_0029FE44;
    case 0x0029FE74U:
        goto block_0029FE74;
    case 0x0029FE80U:
        goto block_0029FE80;
    case 0x0029FE84U:
        goto block_0029FE84;
    case 0x0029FE98U:
        goto block_0029FE98;
    case 0x0029FEA8U:
        goto block_0029FEA8;
    case 0x0029FEACU:
        goto block_0029FEAC;
    case 0x0029FECCU:
        goto block_0029FECC;
    case 0x0029FEFCU:
        goto block_0029FEFC;
    case 0x0029FF08U:
        goto block_0029FF08;
    case 0x0029FF28U:
        goto block_0029FF28;
    case 0x0029FF6CU:
        goto block_0029FF6C;
    case 0x0029FF84U:
        goto block_0029FF84;
    case 0x0029FFA4U:
        goto block_0029FFA4;
    case 0x0029FFE4U:
        goto block_0029FFE4;
    case 0x0029FFFCU:
        goto block_0029FFFC;
    case 0x002A001CU:
        goto block_002A001C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0029F8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F8A0U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0029F8A0U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r11 = r1;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0029F8ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0029F8ACU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0029F8B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xEFDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F8B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0029F990; }
        goto block_0029F8C4;
    }
block_0029F8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F8C4U);
        }
        {
            r0 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029F8C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF08U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F8CCU, address);
            }
            r2 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r1 = 0x00000016U;
        }
        goto block_0029F8D8;
    }
block_0029F8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F8D8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r3 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 4U);
            r3 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + r3;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F8E0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t value = r3 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0029F978; }
        goto block_0029F8EC;
    }
block_0029F8EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F8ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F8ECU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r0 + operand;
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 + operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F900U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F908U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F90CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029F918U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = 0x00000024U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r2 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029F928U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029F92CU, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029F930U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0029F934U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0029F938U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF08U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F93CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F940U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0029F944U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r3 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F94CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F950U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029F958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSs_SpawnSurfaceImpact_003741E4(frame, context, state, 0x003741E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029F958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029F958;
    }
block_0029F958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F958U);
        }
        {
            const uint32_t updatedAddress = 0x0029F960U + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F960U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F964U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029F96CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SpawnShieldParticlesGreen_003661A8(frame, context, state, 0x003661A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029F96CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029F96C;
    }
block_0029F96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F96CU);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0029F970U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0029F970U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0029F974U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0029F978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F978U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0029F8D8; }
        goto block_0029F984;
    }
block_0029F984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F984U);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0029F988U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0029F988U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0029F98CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0029F990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F990U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r10 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F994U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0029F96C; }
        goto block_0029F9A0;
    }
block_0029F9A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F9A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F9A0U);
        }
        {
            r0 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029F9A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9B0U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0029F9E4; }
        goto block_0029F9BC;
    }
block_0029F9BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F9BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F9BCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0029F9C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r3 = r4 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029F9D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSs_SpawnSurfaceImpact_003741E4(frame, context, state, 0x003741E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029F9D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029F9D8;
    }
block_0029F9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F9D8U);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0029F9DCU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0029F9DCU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0029F9E0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0029F9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029F9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029F9E4U);
        }
        {
            const uint32_t operand = 0x00001200U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000A2U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0029F9F4U + 0x33CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9ECU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9F0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0029F9FCU + 0x338U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9F4U, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x0029FA00U + 812U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029F9F8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA00U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA04U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r9 = 0x00000001U;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FA14U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x0029FA20U + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA18U, address);
            }
            r1 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FA20U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FA24U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FA28U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0029FA2CU, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0029FA30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA38U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0029FD70; }
        goto block_0029FA44;
    }
block_0029FA44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FA44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FA44U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FA4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ApplyDamage_00375EB8(frame, context, state, 0x00375EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FA4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FA4C;
    }
block_0029FA4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FA4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FA4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0029FBF0; }
        goto block_0029FA58;
    }
block_0029FA58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FA58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FA58U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FA64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSoundFlaggedTimer_00375B70(frame, context, state, 0x00375B70U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FA64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FA64;
    }
block_0029FA64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FA64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FA64U);
        }
        {
            const uint32_t updatedAddress = 0x0029FA6CU + 0x2CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA64U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t updatedAddress = r0 + r11;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FA74U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FA80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FA80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FA80;
    }
block_0029FA80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FA80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FA80U);
        }
        {
            const uint32_t updatedAddress = 0x0029FA88U + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA80U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FA8CU + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA84U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FA90U + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FA88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000EE0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0029FA90U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FAA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FAA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FAA0;
    }
block_0029FAA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FAA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FAA0U);
        }
        {
            r3 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0029FAA4U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FABCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FABCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FABC;
    }
block_0029FABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FABCU);
        }
        {
            r3 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0029FAC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FAC4U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FAD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FAD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FAD8;
    }
block_0029FAD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FAD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FAD8U);
        }
        {
            r3 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0029FADCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FAE0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FAF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FAF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FAF4;
    }
block_0029FAF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FAF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FAF4U);
        }
        {
            r1 = 0x00000234U;
        }
        {
            r0 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FAFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB00U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FB08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFEU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB0CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FB14U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEFEU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB1CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xEFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0029FB24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB28U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEFEU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB2CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xEFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0029FB34U, address);
            }
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FB44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FB44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FB44;
    }
block_0029FB44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FB44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FB44U);
        }
        {
            const uint32_t updatedAddress = 0x0029FB4CU + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000190U;
            r1 = r7 + operand;
        }
        {
            const uint32_t address = 0x0029FB54U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FB50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0029FB54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0029FB58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FB5CU, address);
            }
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FB60U, address);
            }
        }
        {
            const uint32_t address = r0 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FB64U, address);
            }
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FB70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FB70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FB70;
    }
block_0029FB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FB70U);
        }
        {
            const uint32_t operand = 0x0000008CU;
            r9 = r7 - operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FB78U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FB88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FB88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FB88;
    }
block_0029FB88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FB88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FB88U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB88U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FB98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FB98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FB98;
    }
block_0029FB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FB98U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FB98U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FBA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Play_CopyCamera_00338654(frame, context, state, 0x00338654U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FBA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FBA8;
    }
block_0029FBA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FBA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FBA8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBA8U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000008U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FBB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FBB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FBB8;
    }
block_0029FBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FBB8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FBC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FBC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FBC8;
    }
block_0029FBC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FBC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FBC8U);
        }
        {
            const uint32_t updatedAddress = 0x0029FBD0U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r11;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBCCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0029FBE4U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBDCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FBE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_0036DF4C(frame, context, state, 0x0036DF4CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FBE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FBE4;
    }
block_0029FBE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FBE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FBE4U);
        }
        {
            const uint32_t updatedAddress = 0x0029FBECU + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBE4U, address);
            }
            r0 = value;
        }
        {
        }
        goto block_0029FC9C;
    }
block_0029FBF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FBF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FBF0U);
        }
        {
            const uint32_t address = 0x0029FBF8U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FBF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC00;
    }
block_0029FC00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC00U);
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC0C;
    }
block_0029FC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC0CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FC0CU, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC24;
    }
block_0029FC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC24U);
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC30;
    }
block_0029FC30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC30U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FC30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC34U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC48;
    }
block_0029FC48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC48U);
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC54;
    }
block_0029FC54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC54U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FC54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC58U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC6C;
    }
block_0029FC6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC6CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FC78U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC70U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FC7CU + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC74U, address);
            }
            r2 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FC7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0029FC80U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0029FC90U + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000EE0U;
            r1 = r4 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FC98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FC98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FC98;
    }
block_0029FC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC98U);
        }
        {
            const uint32_t updatedAddress = 0x0029FCA0U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC98U, address);
            }
            r0 = value;
        }
        goto block_0029FC9C;
    }
block_0029FC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FC9CU);
        }
        {
            const uint32_t updatedAddress = 0x0029FCA4U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FC9CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0029FCA8U + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCA0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FCA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCA8U, address);
            }
            r4 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FCB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCB4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCB8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FCC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FCC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FCC4;
    }
block_0029FCC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FCC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FCC4U);
        }
        {
            r0 = 0x00000234U;
        }
        {
            r10 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0029FCCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0029FCD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCD4U, address);
            }
            r4 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FCDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCE0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FCE4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FCF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FCF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FCF0;
    }
block_0029FCF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FCF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FCF0U);
        }
        {
            r0 = 0x00000234U;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0029FCF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0029FCFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0029FD00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FD04U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FD08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FD18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSs_SpawnSurfaceImpact_003741E4(frame, context, state, 0x003741E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FD18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FD18;
    }
block_0029FD18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FD18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FD18U);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0029FD1CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0029FD1CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0029FD20U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0029FD70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FD70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FD70U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000012U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FD80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FD80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FD80;
    }
block_0029FD80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FD80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FD80U);
        }
        {
            r1 = 0x00000012U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FD8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FD8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FD8C;
    }
block_0029FD8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FD8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FD8CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FD90U, address);
            }
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = r3;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FDA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FDA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FDA4;
    }
block_0029FDA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FDA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FDA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDA4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FDB0U - 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDA8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FDB4U - 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDACU, address);
            }
            r2 = value;
        }
        {
            r0 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FDB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000EE0U;
            r1 = r4 + operand;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x28DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FDC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x230U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FDC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDCCU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000080U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FDD4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0029FDD8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0029FDE8U + 0x240U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDE0U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FDECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FDECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FDEC;
    }
block_0029FDEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FDECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FDECU);
        }
        {
            const uint32_t updatedAddress = 0x0029FDF4U + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FDF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDF4U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FE00U + 0x230U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDF8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FDFCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE00U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FE0CU + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE04U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0029FE84; }
        goto block_0029FE10;
    }
block_0029FE10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE10U);
        }
        {
            const uint32_t updatedAddress = 0x0029FE18U + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0029FE14U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FE20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FE20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FE20;
    }
block_0029FE20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE20U);
        }
        {
            r1 = 0x00000000U;
        }
        goto block_0029FE24;
    }
block_0029FE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE24U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000002D4U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE38U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0029FE74; }
        goto block_0029FE44;
    }
block_0029FE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE44U);
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE48U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FE4CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FE50U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE58U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FE5CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FE60U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FE6CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FE70U, address);
            }
        }
        goto block_0029FE74;
    }
block_0029FE74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE74U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000012U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0029FE24; }
        goto block_0029FE80;
    }
block_0029FE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE80U);
        }
        goto block_0029FF08;
    }
block_0029FE84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE84U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE84U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE88U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r2, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0029FF08; }
        goto block_0029FE98;
    }
block_0029FE98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FE98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FE98U);
        }
        {
            const uint32_t updatedAddress = 0x0029FEA0U + 0x198U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FE98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0029FE9CU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FEA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FEA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FEA8;
    }
block_0029FEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FEA8U);
        }
        {
            r1 = 0x00000000U;
        }
        goto block_0029FEAC;
    }
block_0029FEAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FEACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FEACU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000002D4U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FEC0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0029FEFC; }
        goto block_0029FECC;
    }
block_0029FECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FECCU);
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FECCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FED0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FED4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FED8U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FEDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FEE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FEE4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FEE8U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FEECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FEF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0029FEF4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0029FEF8U, address);
            }
        }
        goto block_0029FEFC;
    }
block_0029FEFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FEFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FEFCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000012U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0029FEAC; }
        goto block_0029FF08;
    }
block_0029FF08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FF08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FF08U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF08U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = 0x0029FF14U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF0CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0029FF18U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF10U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF14U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF1CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FF28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FF28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FF28;
    }
block_0029FF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FF28U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF28U, address);
            }
            r0 = value;
        }
        {
            r10 = 0x0000000CU;
        }
        {
            r1 = 0x00000012U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x231U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FF38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF3CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FF44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF00U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0029FF4CU, address);
            }
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            r0 = r0 & 0x000000FDU;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            r0 = r0 | 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FF60U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FF6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FF6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FF6C;
    }
block_0029FF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FF6CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FF70U, address);
            }
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = r3;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FF84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FF84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FF84;
    }
block_0029FF84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FF84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FF84U);
        }
        {
            const uint32_t updatedAddress = 0x0029FF8CU + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF84U, address);
            }
            r11 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0029FF8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF90U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF94U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FF98U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FFA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FFA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FFA4;
    }
block_0029FFA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FFA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FFA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FFA4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000012U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x231U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0029FFB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FFB4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FFBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0029FFC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF00U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0029FFC4U, address);
            }
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            r0 = r0 & 0x000000FDU;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            r0 = r0 | 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xEFDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FFD8U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FFE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FFE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FFE4;
    }
block_0029FFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FFE4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0029FFE8U, address);
            }
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = r3;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0029FFFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0029FFFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0029FFFC;
    }
block_0029FFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0029FFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0029FFFCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0029FFFCU, address);
            }
        }
        {
            r3 = 0x000004B0U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002A0004U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0008U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A000CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002A001CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SpawnHitOrStoneEffect_00365560(frame, context, state, 0x00365560U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002A001CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002A001C;
    }
block_002A001C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A001CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A001CU);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002A0020U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002A0020U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002A0024U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BgSpot06Objects_Init_002ACCC4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002ACCC4U:
        goto block_002ACCC4;
    case 0x002ACD2CU:
        goto block_002ACD2C;
    case 0x002ACD38U:
        goto block_002ACD38;
    case 0x002ACD40U:
        goto block_002ACD40;
    case 0x002ACD48U:
        goto block_002ACD48;
    case 0x002ACD64U:
        goto block_002ACD64;
    case 0x002ACD70U:
        goto block_002ACD70;
    case 0x002ACD7CU:
        goto block_002ACD7C;
    case 0x002ACD8CU:
        goto block_002ACD8C;
    case 0x002ACDA8U:
        goto block_002ACDA8;
    case 0x002ACDC0U:
        goto block_002ACDC0;
    case 0x002ACDCCU:
        goto block_002ACDCC;
    case 0x002ACDE8U:
        goto block_002ACDE8;
    case 0x002ACDF4U:
        goto block_002ACDF4;
    case 0x002ACE00U:
        goto block_002ACE00;
    case 0x002ACE10U:
        goto block_002ACE10;
    case 0x002ACE30U:
        goto block_002ACE30;
    case 0x002ACE40U:
        goto block_002ACE40;
    case 0x002ACE4CU:
        goto block_002ACE4C;
    case 0x002ACE58U:
        goto block_002ACE58;
    case 0x002ACE6CU:
        goto block_002ACE6C;
    case 0x002ACE80U:
        goto block_002ACE80;
    case 0x002ACE8CU:
        goto block_002ACE8C;
    case 0x002ACE9CU:
        goto block_002ACE9C;
    case 0x002ACEA8U:
        goto block_002ACEA8;
    case 0x002ACEBCU:
        goto block_002ACEBC;
    case 0x002ACED8U:
        goto block_002ACED8;
    case 0x002ACEE4U:
        goto block_002ACEE4;
    case 0x002ACEF8U:
        goto block_002ACEF8;
    case 0x002ACF14U:
        goto block_002ACF14;
    case 0x002ACF20U:
        goto block_002ACF20;
    case 0x002ACF3CU:
        goto block_002ACF3C;
    case 0x002ACF48U:
        goto block_002ACF48;
    case 0x002ACF54U:
        goto block_002ACF54;
    case 0x002ACF60U:
        goto block_002ACF60;
    case 0x002ACF6CU:
        goto block_002ACF6C;
    case 0x002ACF7CU:
        goto block_002ACF7C;
    case 0x002ACF84U:
        goto block_002ACF84;
    case 0x002ACFCCU:
        goto block_002ACFCC;
    case 0x002ACFE0U:
        goto block_002ACFE0;
    case 0x002ACFECU:
        goto block_002ACFEC;
    case 0x002ACFFCU:
        goto block_002ACFFC;
    case 0x002AD03CU:
        goto block_002AD03C;
    case 0x002AD058U:
        goto block_002AD058;
    case 0x002AD088U:
        goto block_002AD088;
    case 0x002AD0B0U:
        goto block_002AD0B0;
    case 0x002AD0BCU:
        goto block_002AD0BC;
    case 0x002AD0CCU:
        goto block_002AD0CC;
    case 0x002AD0E8U:
        goto block_002AD0E8;
    case 0x002AD0F8U:
        goto block_002AD0F8;
    case 0x002AD110U:
        goto block_002AD110;
    case 0x002AD138U:
        goto block_002AD138;
    case 0x002AD148U:
        goto block_002AD148;
    case 0x002AD18CU:
        goto block_002AD18C;
    case 0x002AD19CU:
        goto block_002AD19C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002ACCC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACCC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACCC4U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002ACCC4U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r4 + operand;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t updatedAddress = 0x002ACCE0U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACCD8U, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x002ACCE4U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACCDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x002ACCE8U + 0x324U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACCE0U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r1 + operand;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002ACCE8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002ACCE8U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x000002E8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACCF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACCF8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r8 = r9 + operand;
        }
        {
            r11 = 0x0000001FU;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r6 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACD08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACD0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000E00U;
            r7 = r9 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 16U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 1U, 24U, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACD1CU, address);
            }
        }
        {
            const uint32_t address = r4 + 252U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACD20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ACD24U, address);
            }
        }
        if (flags.Z()) { goto block_002ACDCC; }
        goto block_002ACD2C;
    }
block_002ACD2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD2CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x002ACD38U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACD30U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        if (flags.Z()) { goto block_002ACEBC; }
        goto block_002ACD38;
    }
block_002ACD38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD38U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002AD088; }
        goto block_002ACD40;
    }
block_002ACD40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD40U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002ACDC0; }
        goto block_002ACD48;
    }
block_002ACD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD48U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ACD4CU, address);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x00000238U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACD64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACD64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACD64;
    }
block_002ACD64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD64U);
        }
        {
            const uint32_t updatedAddress = 0x002ACD6CU + 0x2ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACD64U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACD70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACD70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACD70;
    }
block_002ACD70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD70U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACD7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyActor_Init_003532E8(frame, context, state, 0x003532E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACD7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACD7C;
    }
block_002ACD7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD7CU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACD8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACD8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACD8C;
    }
block_002ACD8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACD8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACD8CU);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACD90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACD94U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACD98U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACDA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACDA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACDA8;
    }
block_002ACDA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACDA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACDA8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACDA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ACDACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACDB0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = r4;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACDC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACDC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACDC0;
    }
block_002ACDC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACDC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACDC0U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002ACDC8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002ACDCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACDCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACDCCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ACDD0U, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000238U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACDE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACDE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACDE8;
    }
block_002ACDE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACDE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACDE8U);
        }
        {
            const uint32_t updatedAddress = 0x002ACDF0U + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACDE8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACDF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACDF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACDF4;
    }
block_002ACDF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACDF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACDF4U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACE00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyActor_Init_003532E8(frame, context, state, 0x003532E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACE00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACE00;
    }
block_002ACE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE00U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACE10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACE10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACE10;
    }
block_002ACE10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE10U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACE18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE1CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE20U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACE30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACE30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACE30;
    }
block_002ACE30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE30U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACE30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE34U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002ACEA8; }
        goto block_002ACE40;
    }
block_002ACE40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE40U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE40U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACE4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACE4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACE4C;
    }
block_002ACE4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002ACE6C; }
        goto block_002ACE58;
    }
block_002ACE58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE58U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x002ACE64U + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE5CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ACE60U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACE64U, address);
            }
        }
        goto block_002AD18C;
    }
block_002ACE6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE6CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE6CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE74U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002ACEA8; }
        goto block_002ACE80;
    }
block_002ACE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE80U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x4E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACE80U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002ACEA8; }
        goto block_002ACE8C;
    }
block_002ACE8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE8CU);
        }
        {
            r1 = r11;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r6 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002ACE94U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACE9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetSwitch_00375C10(frame, context, state, 0x00375C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACE9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACE9C;
    }
block_002ACE9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACE9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACE9CU);
        }
        {
        }
        {
        }
        goto block_002ACE58;
    }
block_002ACEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACEA8U);
        }
        {
            const uint32_t updatedAddress = 0x002ACEB0U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACEA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ACEACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002ACEB8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002ACEBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACEBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACEBCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ACEC0U, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000238U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACED8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACED8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACED8;
    }
block_002ACED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACED8U);
        }
        {
            r1 = 0x00000002U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACEE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACEE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACEE4;
    }
block_002ACEE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACEE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACEE4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACEE4U, address);
            }
            r1 = value;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACEECU, address);
            }
            r0 = value;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACEF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACEF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACEF8;
    }
block_002ACEF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACEF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACEF8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACEF8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ACF04U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002ACF10U + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF08U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACF14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACF14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACF14;
    }
block_002ACF14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF14U);
        }
        {
            const uint32_t operand = 0x000001C8U;
            r1 = r4 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACF20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitJntSph_00350EB8(frame, context, state, 0x00350EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACF20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACF20;
    }
block_002ACF20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF20U);
        }
        {
            const uint32_t operand = 0x000001E8U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ACF24U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002ACF30U + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF28U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000001C8U;
            r1 = r4 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACF3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetJntSph_00350D48(frame, context, state, 0x00350D48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACF3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACF3C;
    }
block_002ACF3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF3CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF3CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002AD03C; }
        goto block_002ACF48;
    }
block_002ACF48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF48U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF48U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACF54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACF54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACF54;
    }
block_002ACF54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF54U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        {
        }
        if (flags.Z()) { goto block_002ACFCC; }
        goto block_002ACF60;
    }
block_002ACF60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF60U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002ACF7C; }
        goto block_002ACF6C;
    }
block_002ACF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF6CU);
        }
        {
            const uint32_t address = 0x002ACF74U + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACF70U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACF74U, address);
            }
        }
        goto block_002ACF84;
    }
block_002ACF7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF7CU);
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002ACF7CU, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002ACF80U, address);
            }
        }
        goto block_002ACF84;
    }
block_002ACF84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACF84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACF84U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x002ACF90U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x002ACF94U + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF8CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ACF90U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x002ACF9CU + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACF94U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACF98U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ACF9CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACFA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ACFA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002ACFB4U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFB0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ACFB4U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ACFB8U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFC0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ACFC4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_002AD058;
    }
block_002ACFCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACFCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACFCCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFCCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFD4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002AD03C; }
        goto block_002ACFE0;
    }
block_002ACFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACFE0U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x4E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ACFE0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002AD03C; }
        goto block_002ACFEC;
    }
block_002ACFEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACFECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACFECU);
        }
        {
            r1 = r11;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r6 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002ACFF4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ACFFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetSwitch_00375C10(frame, context, state, 0x00375C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ACFFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ACFFC;
    }
block_002ACFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ACFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ACFFCU);
        }
        {
        }
        {
        }
        goto block_002ACF60;
    }
block_002AD03C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD03CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD03CU);
        }
        {
            const uint32_t updatedAddress = 0x002AD044U + 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD03CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002AD040U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD044U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD048U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD04CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD050U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD054U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_002AD058;
    }
block_002AD058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD058U);
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t address = r0 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD05CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD060U, address);
            }
            r3 = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD064U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r3 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD068U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD06CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD070U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD074U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002AD078U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002AD080U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002AD080U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002AD084U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002AD088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD088U);
        }
        {
            const uint32_t address = 0x002AD090U + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD088U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t address = r4 + 580U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD090U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000240U;
            r1 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002AD09CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002AD09CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002AD09CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000023CU;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AD0B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD0B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD0B0;
    }
block_002AD0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD0B0U);
        }
        {
            r11 = r0;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AD0BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD0BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD0BC;
    }
block_002AD0BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD0BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD0BCU);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0C4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AD0CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD0CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD0CC;
    }
block_002AD0CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD0CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD0CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0CCU, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000001U;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002AD0DCU, address);
            }
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AD0E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD0E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD0E8;
    }
block_002AD0E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD0E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD0E8U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x240U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0F0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AD0F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD0F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD0F8;
    }
block_002AD0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD0F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x240U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x002AD104U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD0FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD100U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002AD104U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AD110U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD110U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD110;
    }
block_002AD110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD110U);
        }
        {
            r1 = 0x00000030U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002AD114U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD118U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002AD124U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD11CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD124U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 452U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD12CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AD130U, address);
            }
        }
        if (!(flags.Z())) { goto block_002ACDC0; }
        goto block_002AD138;
    }
block_002AD138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD138U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x4E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD138U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002AD144U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD13CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_002AD19C; }
        goto block_002AD148;
    }
block_002AD148:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD148U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD148U);
        }
        {
            const uint32_t address = r4 + 452U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002AD148U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD14CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002AD158U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD150U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD154U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AD158U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD15CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD160U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD164U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000032U;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002AD16CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD170U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002AD17CU + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD174U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD178U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AD17CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD180U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD184U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AD188U, address);
            }
        }
        goto block_002AD18C;
    }
block_002AD18C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD18CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD18CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AD18CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002AD194U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002AD194U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002AD198U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002AD19C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD19CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD19CU);
        }
        {
            const uint32_t address = r4 + 452U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002AD19CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002AD1A8U + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD1A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002AD1ACU + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD1A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002AD1A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AD1ACU, address);
            }
        }
        {
            const uint32_t address = r4 + 580U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AD1B0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002AD1B8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002AD1B8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002AD1BCU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Actor_ProcessInitChain_003510B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003510B0U:
        goto block_003510B0;
    case 0x003510C4U:
        goto block_003510C4;
    case 0x003510DCU:
        goto block_003510DC;
    case 0x003510E8U:
        goto block_003510E8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003510B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003510B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003510B0U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003510B0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003510B0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003510B0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003510B0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003510B0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003510B0U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r4 = r1;
        }
        {
            r7 = r0;
        }
        {
            const uint32_t updatedAddress = 0x003510C4U + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003510BCU, address);
            }
            r6 = value;
        }
        {
            r5 = 0x0000003CU;
        }
        goto block_003510C4;
    }
block_003510C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003510C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003510C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003510C4U, address);
            }
            r0 = value;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5 & Oot3dAotLsl(r0, 1U);
        }
        {
            const uint32_t updatedAddress = r6 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003510D0U, address);
            }
            r2 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x003510DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003510DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003510DC;
    }
block_003510DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003510DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003510DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = r4;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003510DCU, address);
            }
            r0 = value;
            r4 = updatedAddress;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003510C4; }
        goto block_003510E8;
    }
block_003510E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003510E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003510E8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003510E8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003510E8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003510E8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003510E8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003510E8U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003510E8U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Actor_SetColorFilter_00375ED8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00375ED8U:
        goto block_00375ED8;
    case 0x00375F00U:
        goto block_00375F00;
    case 0x00375F20U:
        goto block_00375F20;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00375ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375ED8U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00375ED8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00375ED8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00375ED8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00375ED8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00375ED8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00375ED8U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375EE4U, address);
            }
            r4 = value;
        }
        {
            r7 = r2;
        }
        if (flags.Z()) {
            const uint32_t value = r7 & 0x00008000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00008000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            r5 = r0;
        }
        {
            r6 = r1;
        }
        {
            r8 = r3;
        }
        if (!(flags.Z())) { goto block_00375F20; }
        goto block_00375F00;
    }
block_00375F00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375F00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375F00U);
        }
        {
            const uint32_t updatedAddress = 0x00375F08U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375F00U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375F0CU + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375F04U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375F10U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375F08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00375F10U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00375F20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00375F20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00375F20;
    }
block_00375F20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375F20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375F20U);
        }
        {
            frame.Guest.vfp[3] = r4;
        }
        {
            const uint32_t address = 0x00375F2CU + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375F24U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00375F30U + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375F28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r5 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00375F38U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00375F3CU, 0xEE211A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00375F40U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00375F44U, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00375F48U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r1 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00375F50U, address);
            }
        }
        {
            r1 = r7 & 0x000000F8U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            r1 = r8 | Oot3dAotLsl(r1, 13U);
        }
        {
            r0 = r0 | r6;
        }
        {
            r0 = r0 | r1;
        }
        {
            const uint32_t updatedAddress = r5 + 0x11CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00375F68U, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00375F70U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00375F70U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00375F70U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00375F70U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00375F70U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00375F70U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00376168U:
        goto block_00376168;
    case 0x0037617CU:
        goto block_0037617C;
    case 0x00376184U:
        goto block_00376184;
    case 0x0037619CU:
        goto block_0037619C;
    case 0x003761A8U:
        goto block_003761A8;
    case 0x003761B4U:
        goto block_003761B4;
    case 0x003761C0U:
        goto block_003761C0;
    case 0x003761CCU:
        goto block_003761CC;
    case 0x003761D4U:
        goto block_003761D4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00376168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376168U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00376168U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00376168U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00376168U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00376168U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r6 = r0;
        }
        {
            r4 = r1;
        }
        {
            r5 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037617CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FrameAdvance_IsEnabled_00366738(frame, context, state, 0x00366738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037617CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037617C;
    }
block_0037617C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037617CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037617CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003761CC; }
        goto block_00376184;
    }
block_00376184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376184U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x15U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376184U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376190U + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376188U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037618CU, address);
            }
            r2 = value;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0037619CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037619CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037619C;
    }
block_0037619C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037619CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037619CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037619CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003761B4; }
        goto block_003761A8;
    }
block_003761A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003761A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003761A8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003761A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003761CC; }
        goto block_003761B4;
    }
block_003761B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003761B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003761B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003761B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003761CC; }
        goto block_003761C0;
    }
block_003761C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003761C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003761C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003761C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_003761D4; }
        goto block_003761CC;
    }
block_003761CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003761CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003761CCU);
        }
        {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003761D0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003761D0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003761D0U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003761D0U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_003761D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003761D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003761D4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003761D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003761DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003761E4U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003761E8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003761E8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003761E8U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003761E8U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r12 = state.R[12];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0037632CU:
        goto block_0037632C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0037632C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037632CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037632CU);
        }
        {
            const uint32_t operand = 0x00000028U;
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r2;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00376334U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00376334U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00376334U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00376338U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00376338U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00376338U,
                                           firstAddress + 8U);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
