#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_001008b4_001008B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGoma_Encounter_0019D11C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossVa_Init_001A8A5C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_0031800C_0031800C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00318010_00318010(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003239a4_003239A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_00326524_00326524(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00326528_00326528(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Lib_MemSet_0034322C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034325c_0034325C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_Memzero_00343280(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGoma_SetupEncounterState4_00345AEC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCSABByIndex_0034807C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034f248_0034F248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SystemArena_Malloc_0035010c_0035010C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Array_Construct_00350820(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_SetQuad_00350914(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_InitQuad_00350A98(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_SetJntSph_00350D48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_InitJntSph_00350EB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003524ec_003524EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_InitActor_00353C9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_SetCylinder_00353D24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_InitCylinder_00353DD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TitleCard_InitBossName_00354248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003542c4_003542C4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_NormalizeFrame_003586EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_InitAsset_00358EA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMBByIndex_00358EF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetRuntimeFlag200_0035AF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b0a0_0035B0A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b164_0035B164(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorContext_FindActorsById_00360084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGoma_UpdateCeilingMovement_00366D18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CameraSetAtEye_00367B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetClear_0036CF6C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToF_0036E168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_WorldYawTowardActor_0036E800(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_QueueSeqCmd_0036EC40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGoma_PlayEffectsAndSfx_0036FCFC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToSUpdateRate_00370084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_S16Offset_003702c8_003702C8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorModelCache_Acquire_00371478(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCTXBByIndex_00372C90(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_Init_00372D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMABByIndex_00372F0C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_LoadAll_00372F38(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachF_00373500(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_Update_00373BEC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Kill_00374428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetPlayerKnockbackLargeNoDamage_00374BB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00374be8_00374BE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_get_flag_22a0_0037571C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetScale_0037572C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_set_field_229c_clear_22ac_0037573C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_get_indexed_field_60_entry_00375750(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_InCsMode_0037577C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SpawnShieldParticles_003757A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Atan2S_003758B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToS_00375A18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSoundFlaggedTimer_00375B70(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_SetSwitch_00375C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundAtPosition_00375C44(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ChangeType_00375D3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BodyBreak_Alloc_00375E18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ApplyDamage_00375EB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetColorFilter_00375ED8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SpawnShieldParticlesMetal_00375F90(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetDropFlag_00375FD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAT_003761F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateBgCheckInfo_00376340(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_AnimationContext_SetMoveActor_003FD1B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_FUN_001008b4_001008B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001008B4U:
        goto block_001008B4;
    case 0x00100904U:
        goto block_00100904;
    case 0x00100910U:
        goto block_00100910;
    case 0x0010091CU:
        goto block_0010091C;
    case 0x00100958U:
        goto block_00100958;
    case 0x00100964U:
        goto block_00100964;
    case 0x00100994U:
        goto block_00100994;
    case 0x001009B4U:
        goto block_001009B4;
    case 0x001009C0U:
        goto block_001009C0;
    case 0x001009D0U:
        goto block_001009D0;
    case 0x001009E0U:
        goto block_001009E0;
    case 0x001009ECU:
        goto block_001009EC;
    case 0x00100A08U:
        goto block_00100A08;
    case 0x00100A14U:
        goto block_00100A14;
    case 0x00100A20U:
        goto block_00100A20;
    case 0x00100A28U:
        goto block_00100A28;
    case 0x00100A34U:
        goto block_00100A34;
    case 0x00100A48U:
        goto block_00100A48;
    case 0x00100A54U:
        goto block_00100A54;
    case 0x00100A68U:
        goto block_00100A68;
    case 0x00100A78U:
        goto block_00100A78;
    case 0x00100A8CU:
        goto block_00100A8C;
    case 0x00100A9CU:
        goto block_00100A9C;
    case 0x00100AA8U:
        goto block_00100AA8;
    case 0x00100AB0U:
        goto block_00100AB0;
    case 0x00100AC0U:
        goto block_00100AC0;
    case 0x00100AD0U:
        goto block_00100AD0;
    case 0x00100ADCU:
        goto block_00100ADC;
    case 0x00100B10U:
        goto block_00100B10;
    case 0x00100B24U:
        goto block_00100B24;
    case 0x00100B30U:
        goto block_00100B30;
    case 0x00100B44U:
        goto block_00100B44;
    case 0x00100B50U:
        goto block_00100B50;
    case 0x00100B6CU:
        goto block_00100B6C;
    case 0x00100B78U:
        goto block_00100B78;
    case 0x00100B7CU:
        goto block_00100B7C;
    case 0x00100B88U:
        goto block_00100B88;
    case 0x00100BA4U:
        goto block_00100BA4;
    case 0x00100BB0U:
        goto block_00100BB0;
    case 0x00100BE4U:
        goto block_00100BE4;
    case 0x00100BECU:
        goto block_00100BEC;
    case 0x00100BF8U:
        goto block_00100BF8;
    case 0x00100C04U:
        goto block_00100C04;
    case 0x00100C0CU:
        goto block_00100C0C;
    case 0x00100C18U:
        goto block_00100C18;
    case 0x00100C24U:
        goto block_00100C24;
    case 0x00100C68U:
        goto block_00100C68;
    case 0x00100C74U:
        goto block_00100C74;
    case 0x00100C80U:
        goto block_00100C80;
    case 0x00100CA4U:
        goto block_00100CA4;
    case 0x00100CC0U:
        goto block_00100CC0;
    case 0x00100CCCU:
        goto block_00100CCC;
    case 0x00100CF0U:
        goto block_00100CF0;
    case 0x00100CFCU:
        goto block_00100CFC;
    case 0x00100D08U:
        goto block_00100D08;
    case 0x00100D2CU:
        goto block_00100D2C;
    case 0x00100D34U:
        goto block_00100D34;
    case 0x00100D44U:
        goto block_00100D44;
    case 0x00100D50U:
        goto block_00100D50;
    case 0x00100D5CU:
        goto block_00100D5C;
    case 0x00100D6CU:
        goto block_00100D6C;
    case 0x00100D78U:
        goto block_00100D78;
    case 0x00100D84U:
        goto block_00100D84;
    case 0x00100D8CU:
        goto block_00100D8C;
    case 0x00100D98U:
        goto block_00100D98;
    case 0x00100DB4U:
        goto block_00100DB4;
    case 0x00100DC0U:
        goto block_00100DC0;
    case 0x00100DD4U:
        goto block_00100DD4;
    case 0x00100DF8U:
        goto block_00100DF8;
    case 0x00100E1CU:
        goto block_00100E1C;
    case 0x00100E3CU:
        goto block_00100E3C;
    case 0x00100E4CU:
        goto block_00100E4C;
    case 0x00100E88U:
        goto block_00100E88;
    case 0x00100EA8U:
        goto block_00100EA8;
    case 0x00100EB0U:
        goto block_00100EB0;
    case 0x00100EBCU:
        goto block_00100EBC;
    case 0x00100ECCU:
        goto block_00100ECC;
    case 0x00100ED8U:
        goto block_00100ED8;
    case 0x00100EECU:
        goto block_00100EEC;
    case 0x00100F04U:
        goto block_00100F04;
    case 0x00100F10U:
        goto block_00100F10;
    case 0x00100F1CU:
        goto block_00100F1C;
    case 0x00100F2CU:
        goto block_00100F2C;
    case 0x00100F40U:
        goto block_00100F40;
    case 0x00100F44U:
        goto block_00100F44;
    case 0x00100F5CU:
        goto block_00100F5C;
    case 0x00100F60U:
        goto block_00100F60;
    case 0x00100F68U:
        goto block_00100F68;
    case 0x00100F84U:
        goto block_00100F84;
    case 0x00100FB4U:
        goto block_00100FB4;
    case 0x00100FCCU:
        goto block_00100FCC;
    case 0x00100FD8U:
        goto block_00100FD8;
    case 0x00100FE8U:
        goto block_00100FE8;
    case 0x00100FF4U:
        goto block_00100FF4;
    case 0x00101004U:
        goto block_00101004;
    case 0x00101010U:
        goto block_00101010;
    case 0x00101024U:
        goto block_00101024;
    case 0x00101030U:
        goto block_00101030;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001008B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001008B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001008B4U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001008B4U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t operand = 0x00000028U;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000E00U;
            r9 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001008D0U + 0x360U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001008C8U, address);
            }
            r0 = value;
        }
        {
            r11 = 0x00000001U;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001008D0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001008D0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001008D0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001008D0U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001008DCU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001008E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001008ECU + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001008E4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001008F0U + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001008E8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001008ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001008F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001008F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_00100D6C; }
        goto block_00100904;
    }
block_00100904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100904U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF1DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100904U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00100958; }
        goto block_00100910;
    }
block_00100910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100910U);
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0010091CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0010091CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0010091C;
    }
block_0010091C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010091CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010091CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x00100928U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100920U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100924U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100928U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010092CU, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100930U, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            const uint32_t address = r4 + 480U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100938U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF1DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010093CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000080U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF1DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100944U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE45U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100948U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE45U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100950U, address);
            }
        }
        goto block_00100D6C;
    }
block_00100958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100958U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE45U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00100D6C; }
        goto block_00100964;
    }
block_00100964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100964U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00100964U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00100964U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00100964U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x00100974U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010096CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00100970U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00100970U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00100970U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000C00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = r13 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100978U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100984U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010098CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100994U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetDropFlag_00375FD0(frame, context, state, 0x00375FD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100994U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100994;
    }
block_00100994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100994U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100994U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100998U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE45U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010099CU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE45U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001009A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE11U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001009A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00100D6C; }
        goto block_001009B4;
    }
block_001009B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001009B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001009B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001009D0; }
        goto block_001009C0;
    }
block_001009C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001009C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001009C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001009C0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001009EC; }
        goto block_001009D0;
    }
block_001009D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001009D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001009D0U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001009E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SpawnShieldParticlesMetal_00375F90(frame, context, state, 0x00375F90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001009E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001009E0;
    }
block_001009E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001009E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001009E0U);
        }
        {
        }
        {
        }
        goto block_00100D6C;
    }
block_001009EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001009ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001009ECU);
        }
        {
            r3 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001009F0U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00400000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100A08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetColorFilter_00375ED8(frame, context, state, 0x00375ED8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100A08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100A08;
    }
block_00100A08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A08U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A08U, address);
            }
            r7 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100A14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ApplyDamage_00375EB8(frame, context, state, 0x00375EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100A14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100A14;
    }
block_00100A14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00100A54; }
        goto block_00100A20;
    }
block_00100A20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A20U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00100AC0; }
        goto block_00100A28;
    }
block_00100A28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A28U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A28U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00100AC0; }
        goto block_00100A34;
    }
block_00100A34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A34U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00100A34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A38U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000E20U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100A48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BodyBreak_Alloc_00375E18(frame, context, state, 0x00375E18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100A48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100A48;
    }
block_00100A48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A48U);
        }
        {
        }
        {
        }
        goto block_00100AC0;
    }
block_00100A54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00100AA8; }
        goto block_00100A68;
    }
block_00100A68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A68U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A68U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000009U;
        }
        {
            r2 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100A78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ChangeType_00375D3C(frame, context, state, 0x00375D3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100A78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100A78;
    }
block_00100A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A78U);
        }
        {
            const uint32_t updatedAddress = 0x00100A80U + 0x1C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A78U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A7CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000014U;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100A8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundAtPosition_00375C44(frame, context, state, 0x00375C44U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100A8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100A8C;
    }
block_00100A8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A8CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A8CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100A94U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x00100A9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetSwitch_00375C10(frame, context, state, 0x00375C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100A9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100A9C;
    }
block_00100A9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100A9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100A9CU);
        }
        {
        }
        {
        }
        goto block_00100D6C;
    }
block_00100AA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100AA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100AA8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00100AC0; }
        goto block_00100AB0;
    }
block_00100AB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100AB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100AB0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100AB0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000005U;
        }
        {
            r2 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100AC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ChangeType_00375D3C(frame, context, state, 0x00375D3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100AC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100AC0;
    }
block_00100AC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100AC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100AC0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100AC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00100ACCU + 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100AC4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00100B50; }
        goto block_00100AD0;
    }
block_00100AD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100AD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100AD0U);
        }
        {
            r1 = 0x00000007U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100ADCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100ADCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100ADC;
    }
block_00100ADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100ADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100ADCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00100AE8U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            r2 = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100AF4U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00100AF8U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100B00U, address);
            }
        }
        {
            r1 = 0x00000007U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100B10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100B10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100B10;
    }
block_00100B10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B10U);
        }
        {
            r1 = 0x00000024U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100B14U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00100B20U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B18U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100B24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100B24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100B24;
    }
block_00100B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B24U);
        }
        {
            const uint32_t updatedAddress = 0x00100B2CU + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B24U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100B30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100B30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100B30;
    }
block_00100B30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B30U);
        }
        {
            const uint32_t updatedAddress = 0x00100B38U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B30U, address);
            }
            r0 = value;
        }
        {
            r1 = r4;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100B38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B3CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100B44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSoundFlaggedTimer_00375B70(frame, context, state, 0x00375B70U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100B44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100B44;
    }
block_00100B44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B44U);
        }
        {
        }
        {
        }
        goto block_00100D6C;
    }
block_00100B50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B50U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00100B54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B58U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100B6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100B6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100B6C;
    }
block_00100B6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B6CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00100BF8; }
        goto block_00100B78;
    }
block_00100B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B78U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100B7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100B7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100B7C;
    }
block_00100B7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B7CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_00100BEC; }
        goto block_00100B88;
    }
block_00100B88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100B88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100B88U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100B8CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = 0x00004000U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00008000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00100BEC; }
        goto block_00100BA4;
    }
block_00100BA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100BA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100BA4U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100BB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100BB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100BB0;
    }
block_00100BB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100BB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100BB0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00100BB8U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00100BC0U, address);
            }
        }
        {
            r2 = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100BC8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE13U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100BD0U, address);
            }
        }
        {
            const uint32_t address = 0x00100BDCU + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100BD4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00100BE0U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100BD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100BE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100BE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100BE4;
    }
block_00100BE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100BE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100BE4U);
        }
        {
            const uint32_t updatedAddress = 0x00100BECU + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100BE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100BE8U, address);
            }
        }
        goto block_00100BEC;
    }
block_00100BEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100BECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100BECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100BECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00100D44; }
        goto block_00100BF8;
    }
block_00100BF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100BF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100BF8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100BF8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00100D44; }
        goto block_00100C04;
    }
block_00100C04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C04U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00100C68; }
        goto block_00100C0C;
    }
block_00100C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C0CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00100C68; }
        goto block_00100C18;
    }
block_00100C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C18U);
        }
        {
            const uint32_t updatedAddress = 0x00100C20U + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C18U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100C24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100C24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100C24;
    }
block_00100C24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C24U);
        }
        {
        }
        {
        }
        goto block_00100C80;
    }
block_00100C68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C68U);
        }
        {
            const uint32_t updatedAddress = 0x00100C70U + 0x3E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C68U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100C74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100C74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100C74;
    }
block_00100C74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C74U);
        }
        {
            const uint32_t updatedAddress = 0x00100C7CU - 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C74U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100C80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100C80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100C80;
    }
block_00100C80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100C80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100C80U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C84U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C88U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100C94U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100C98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100C9CU, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100CA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100CA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100CA4;
    }
block_00100CA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100CA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100CA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00100CA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100CA8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = 0x00004000U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00008000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00100CFC; }
        goto block_00100CC0;
    }
block_00100CC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100CC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100CC0U);
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100CCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100CCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100CCC;
    }
block_00100CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100CCCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100CE4U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100CF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100CF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100CF0;
    }
block_00100CF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100CF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100CF0U);
        }
        {
            const uint32_t address = 0x00100CF8U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100CF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100CF4U, address);
            }
        }
        goto block_00100D34;
    }
block_00100CFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100CFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100CFCU);
        }
        {
            r1 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100D08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100D08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100D08;
    }
block_00100D08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D08U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100D20U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100D2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100D2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100D2C;
    }
block_00100D2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D2CU);
        }
        {
            const uint32_t address = 0x00100D34U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100D30U, address);
            }
        }
        goto block_00100D34;
    }
block_00100D34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D34U);
        }
        {
            const uint32_t updatedAddress = 0x00100D3CU + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00100D38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100D3CU, address);
            }
        }
        goto block_00100D6C;
    }
block_00100D44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D44U);
        }
        {
            const uint32_t updatedAddress = 0x00100D4CU + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D44U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100D50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100D50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100D50;
    }
block_00100D50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D50U);
        }
        {
            const uint32_t updatedAddress = 0x00100D58U + 0x2F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D50U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100D5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100D5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100D5C;
    }
block_00100D5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D5CU);
        }
        {
            r2 = 0x00000008U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100D6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SpawnShieldParticles_003757A8(frame, context, state, 0x003757A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100D6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100D6C;
    }
block_00100D6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D6CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00100EBC; }
        goto block_00100D78;
    }
block_00100D78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00100EBC; }
        goto block_00100D84;
    }
block_00100D84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D84U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100D8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_InCsMode_0037577C(frame, context, state, 0x0037577CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100D8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100D8C;
    }
block_00100D8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00100EB0; }
        goto block_00100D98;
    }
block_00100D98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100D98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100D98U);
        }
        {
            const uint32_t updatedAddress = 0x00100DA0U + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100D98U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x13CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100DA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00100DACU + 0x2BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100DA4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100DA8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000118U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100DB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_indexed_field_60_entry_00375750(frame, context, state, 0x00375750U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100DB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100DB4;
    }
block_00100DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100DB4U);
        }
        {
            r1 = r0;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100DC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_field_229c_clear_22ac_0037573C(frame, context, state, 0x0037573CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100DC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100DC0;
    }
block_00100DC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100DC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100DC0U);
        }
        {
            const uint32_t updatedAddress = 0x00100DC8U + 0x2A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100DC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00100DCCU + 676U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100DC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x5A2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00100DC8U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100DD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100DD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100DD4;
    }
block_00100DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100DD4U);
        }
        {
            const uint32_t updatedAddress = 0x00100DDCU + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100DD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100DE0U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00001000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100DE8U, address);
            }
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100DF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100DF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100DF8;
    }
block_00100DF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100DF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100DF8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100E0CU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100E1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100E1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100E1C;
    }
block_00100E1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100E1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100E1CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100E20U, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100E28U, address);
            }
        }
        {
            r0 = r5;
        }
        {
            const uint32_t operand = 0x00002000U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r5 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100E3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100E3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100E3C;
    }
block_00100E3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100E3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100E3CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E40U, address);
            }
            r10 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r10, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00100E88; }
        goto block_00100E4C;
    }
block_00100E4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100E4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100E4CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E4CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100E54U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100E58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E5CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100E64U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100E68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E6CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100E74U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100E78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E7CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100E80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100E84U, address);
            }
        }
        goto block_00100E88;
    }
block_00100E88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100E88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100E88U);
        }
        {
            const uint32_t updatedAddress = 0x00100E90U + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E88U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00100E94U + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E8CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00100E98U - 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100E90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00100E98U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100EA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100EA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100EA8;
    }
block_00100EA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100EA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100EA8U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r6 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00100EACU, address);
            }
        }
        goto block_00100EB0;
    }
block_00100EB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100EB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100EB0U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00100EB4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00100EB4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00100EB4U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00100EB4U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00100EB8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_00100EBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100EBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100EBCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100EBCU, address);
            }
            r2 = value;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00100ECCU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100ECCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100ECC;
    }
block_00100ECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100ECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100ECCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100ECCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00100F60; }
        goto block_00100ED8;
    }
block_00100ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100ED8U);
        }
        {
            r1 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00100EDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100EE0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00100F60; }
        goto block_00100EEC;
    }
block_00100EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100EECU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r7 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00002400U;
            r6 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x488U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100EF4U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100EF8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00100F44; }
        goto block_00100F04;
    }
block_00100F04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F04U);
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100F10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100F10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100F10;
    }
block_00100F10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00100F44; }
        goto block_00100F1C;
    }
block_00100F1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F1CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F1CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t updatedAddress = r7 + 0x488U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00100F20U, address);
            }
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000028U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00100F44; }
        goto block_00100F2C;
    }
block_00100F2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F2CU);
        }
        {
            const uint32_t updatedAddress = 0x00100F34U + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F2CU, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x0000003FU);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F34U, address);
            }
            r2 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00100F40U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100F40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100F40;
    }
block_00100F40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F40U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00100F40U, address);
            }
        }
        goto block_00100F44;
    }
block_00100F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F44U);
        }
        {
            const uint32_t address = 0x00100F4CU + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F48U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r1 = r4;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100F5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetPlayerKnockbackLargeNoDamage_00374BB8(frame, context, state, 0x00374BB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100F5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100F5C;
    }
block_00100F5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F5CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x488U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00100F5CU, address);
            }
        }
        goto block_00100F60;
    }
block_00100F60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F60U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100F68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100F68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100F68;
    }
block_00100F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F68U);
        }
        {
            r2 = 0x0000001DU;
        }
        {
            const uint32_t address = 0x00100F74U + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00100F78U + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00100F7CU + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100F84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100F84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100F84;
    }
block_00100F84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100F84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100F84U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00100F84U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00100F84U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00100F84U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x00100F94U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F8CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00100F90U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00100F90U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00100F90U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000C00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100F98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000234U;
            r1 = r1 + operand;
        }
        {
            r6 = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00100FA4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00100FACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100FB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100FB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100FB4;
    }
block_00100FB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100FB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100FB4U);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r2 = r6;
        }
        {
            r7 = r1;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00100FCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00100FCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00100FCC;
    }
block_00100FCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100FCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100FCCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100FCCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00101004; }
        goto block_00100FD8;
    }
block_00100FD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100FD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100FD8U);
        }
        {
            const uint32_t updatedAddress = 0x00100FE0U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100FD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100FDCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00101004; }
        goto block_00100FE8;
    }
block_00100FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100FE8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00100FE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00101004; }
        goto block_00100FF4;
    }
block_00100FF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00100FF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00100FF4U);
        }
        {
            r2 = r6;
        }
        {
            r1 = r7;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00101004U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00101004U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00101004;
    }
block_00101004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00101004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00101004U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x12U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00101004U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00101024; }
        goto block_00101010;
    }
block_00101010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00101010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00101010U);
        }
        {
            const uint32_t operand = 0x00000C00U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000028CU;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00101024U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00101024U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00101024;
    }
block_00101024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00101024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00101024U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00101024U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00100EB0; }
        goto block_00101030;
    }
block_00101030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00101030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00101030U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r2 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00101038U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00101038U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00101038U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00101038U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00101044U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r2 = r2 + operand;
        }
        return Oot3dAotBranch(0x00376168U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossGoma_Encounter_0019D11C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0019D11CU:
        goto block_0019D11C;
    case 0x0019D150U:
        goto block_0019D150;
    case 0x0019D1ACU:
        goto block_0019D1AC;
    case 0x0019D1B4U:
        goto block_0019D1B4;
    case 0x0019D1E4U:
        goto block_0019D1E4;
    case 0x0019D1FCU:
        goto block_0019D1FC;
    case 0x0019D208U:
        goto block_0019D208;
    case 0x0019D210U:
        goto block_0019D210;
    case 0x0019D218U:
        goto block_0019D218;
    case 0x0019D220U:
        goto block_0019D220;
    case 0x0019D228U:
        goto block_0019D228;
    case 0x0019D250U:
        goto block_0019D250;
    case 0x0019D26CU:
        goto block_0019D26C;
    case 0x0019D28CU:
        goto block_0019D28C;
    case 0x0019D298U:
        goto block_0019D298;
    case 0x0019D2A4U:
        goto block_0019D2A4;
    case 0x0019D2DCU:
        goto block_0019D2DC;
    case 0x0019D2F0U:
        goto block_0019D2F0;
    case 0x0019D314U:
        goto block_0019D314;
    case 0x0019D330U:
        goto block_0019D330;
    case 0x0019D34CU:
        goto block_0019D34C;
    case 0x0019D35CU:
        goto block_0019D35C;
    case 0x0019D368U:
        goto block_0019D368;
    case 0x0019D384U:
        goto block_0019D384;
    case 0x0019D3A0U:
        goto block_0019D3A0;
    case 0x0019D3BCU:
        goto block_0019D3BC;
    case 0x0019D3C8U:
        goto block_0019D3C8;
    case 0x0019D3D4U:
        goto block_0019D3D4;
    case 0x0019D40CU:
        goto block_0019D40C;
    case 0x0019D48CU:
        goto block_0019D48C;
    case 0x0019D49CU:
        goto block_0019D49C;
    case 0x0019D4A4U:
        goto block_0019D4A4;
    case 0x0019D4B0U:
        goto block_0019D4B0;
    case 0x0019D4BCU:
        goto block_0019D4BC;
    case 0x0019D4C8U:
        goto block_0019D4C8;
    case 0x0019D4D4U:
        goto block_0019D4D4;
    case 0x0019D4E8U:
        goto block_0019D4E8;
    case 0x0019D4F8U:
        goto block_0019D4F8;
    case 0x0019D580U:
        goto block_0019D580;
    case 0x0019D5ACU:
        goto block_0019D5AC;
    case 0x0019D5D0U:
        goto block_0019D5D0;
    case 0x0019D5F0U:
        goto block_0019D5F0;
    case 0x0019D610U:
        goto block_0019D610;
    case 0x0019D624U:
        goto block_0019D624;
    case 0x0019D630U:
        goto block_0019D630;
    case 0x0019D650U:
        goto block_0019D650;
    case 0x0019D660U:
        goto block_0019D660;
    case 0x0019D674U:
        goto block_0019D674;
    case 0x0019D684U:
        goto block_0019D684;
    case 0x0019D6B4U:
        goto block_0019D6B4;
    case 0x0019D6C0U:
        goto block_0019D6C0;
    case 0x0019D6D4U:
        goto block_0019D6D4;
    case 0x0019D6E0U:
        goto block_0019D6E0;
    case 0x0019D6F0U:
        goto block_0019D6F0;
    case 0x0019D6FCU:
        goto block_0019D6FC;
    case 0x0019D708U:
        goto block_0019D708;
    case 0x0019D740U:
        goto block_0019D740;
    case 0x0019D754U:
        goto block_0019D754;
    case 0x0019D764U:
        goto block_0019D764;
    case 0x0019D770U:
        goto block_0019D770;
    case 0x0019D788U:
        goto block_0019D788;
    case 0x0019D7A0U:
        goto block_0019D7A0;
    case 0x0019D7B4U:
        goto block_0019D7B4;
    case 0x0019D7C0U:
        goto block_0019D7C0;
    case 0x0019D7DCU:
        goto block_0019D7DC;
    case 0x0019D7E8U:
        goto block_0019D7E8;
    case 0x0019D800U:
        goto block_0019D800;
    case 0x0019D85CU:
        goto block_0019D85C;
    case 0x0019D87CU:
        goto block_0019D87C;
    case 0x0019D890U:
        goto block_0019D890;
    case 0x0019D89CU:
        goto block_0019D89C;
    case 0x0019D8B8U:
        goto block_0019D8B8;
    case 0x0019D8C4U:
        goto block_0019D8C4;
    case 0x0019D8C8U:
        goto block_0019D8C8;
    case 0x0019D8D8U:
        goto block_0019D8D8;
    case 0x0019D8E4U:
        goto block_0019D8E4;
    case 0x0019D8FCU:
        goto block_0019D8FC;
    case 0x0019D90CU:
        goto block_0019D90C;
    case 0x0019D91CU:
        goto block_0019D91C;
    case 0x0019D928U:
        goto block_0019D928;
    case 0x0019D94CU:
        goto block_0019D94C;
    case 0x0019D964U:
        goto block_0019D964;
    case 0x0019D97CU:
        goto block_0019D97C;
    case 0x0019D990U:
        goto block_0019D990;
    case 0x0019D9ACU:
        goto block_0019D9AC;
    case 0x0019D9C0U:
        goto block_0019D9C0;
    case 0x0019D9E0U:
        goto block_0019D9E0;
    case 0x0019D9E8U:
        goto block_0019D9E8;
    case 0x0019DA04U:
        goto block_0019DA04;
    case 0x0019DA18U:
        goto block_0019DA18;
    case 0x0019DA28U:
        goto block_0019DA28;
    case 0x0019DA48U:
        goto block_0019DA48;
    case 0x0019DA54U:
        goto block_0019DA54;
    case 0x0019DA68U:
        goto block_0019DA68;
    case 0x0019DA8CU:
        goto block_0019DA8C;
    case 0x0019DAA8U:
        goto block_0019DAA8;
    case 0x0019DAC0U:
        goto block_0019DAC0;
    case 0x0019DAE0U:
        goto block_0019DAE0;
    case 0x0019DAF8U:
        goto block_0019DAF8;
    case 0x0019DB14U:
        goto block_0019DB14;
    case 0x0019DB28U:
        goto block_0019DB28;
    case 0x0019DB4CU:
        goto block_0019DB4C;
    case 0x0019DB54U:
        goto block_0019DB54;
    case 0x0019DB64U:
        goto block_0019DB64;
    case 0x0019DB70U:
        goto block_0019DB70;
    case 0x0019DB88U:
        goto block_0019DB88;
    case 0x0019DB94U:
        goto block_0019DB94;
    case 0x0019DBA0U:
        goto block_0019DBA0;
    case 0x0019DBC8U:
        goto block_0019DBC8;
    case 0x0019DBE0U:
        goto block_0019DBE0;
    case 0x0019DC04U:
        goto block_0019DC04;
    case 0x0019DC28U:
        goto block_0019DC28;
    case 0x0019DC84U:
        goto block_0019DC84;
    case 0x0019DC9CU:
        goto block_0019DC9C;
    case 0x0019DCBCU:
        goto block_0019DCBC;
    case 0x0019DCD8U:
        goto block_0019DCD8;
    case 0x0019DCF4U:
        goto block_0019DCF4;
    case 0x0019DD14U:
        goto block_0019DD14;
    case 0x0019DD28U:
        goto block_0019DD28;
    case 0x0019DD34U:
        goto block_0019DD34;
    case 0x0019DD48U:
        goto block_0019DD48;
    case 0x0019DD54U:
        goto block_0019DD54;
    case 0x0019DD6CU:
        goto block_0019DD6C;
    case 0x0019DD90U:
        goto block_0019DD90;
    case 0x0019DD9CU:
        goto block_0019DD9C;
    case 0x0019DDC4U:
        goto block_0019DDC4;
    case 0x0019DDD0U:
        goto block_0019DDD0;
    case 0x0019DDE8U:
        goto block_0019DDE8;
    case 0x0019DE08U:
        goto block_0019DE08;
    case 0x0019DE24U:
        goto block_0019DE24;
    case 0x0019DE40U:
        goto block_0019DE40;
    case 0x0019DE54U:
        goto block_0019DE54;
    case 0x0019DE60U:
        goto block_0019DE60;
    case 0x0019DE74U:
        goto block_0019DE74;
    case 0x0019DE80U:
        goto block_0019DE80;
    case 0x0019DEA0U:
        goto block_0019DEA0;
    case 0x0019DED8U:
        goto block_0019DED8;
    case 0x0019DF1CU:
        goto block_0019DF1C;
    case 0x0019DF30U:
        goto block_0019DF30;
    case 0x0019DF40U:
        goto block_0019DF40;
    case 0x0019DF4CU:
        goto block_0019DF4C;
    case 0x0019DF58U:
        goto block_0019DF58;
    case 0x0019DF64U:
        goto block_0019DF64;
    case 0x0019DF90U:
        goto block_0019DF90;
    case 0x0019DFA0U:
        goto block_0019DFA0;
    case 0x0019DFACU:
        goto block_0019DFAC;
    case 0x0019DFB8U:
        goto block_0019DFB8;
    case 0x0019DFBCU:
        goto block_0019DFBC;
    case 0x0019DFCCU:
        goto block_0019DFCC;
    case 0x0019DFD4U:
        goto block_0019DFD4;
    case 0x0019DFE0U:
        goto block_0019DFE0;
    case 0x0019DFE8U:
        goto block_0019DFE8;
    case 0x0019E000U:
        goto block_0019E000;
    case 0x0019E010U:
        goto block_0019E010;
    case 0x0019E01CU:
        goto block_0019E01C;
    case 0x0019E02CU:
        goto block_0019E02C;
    case 0x0019E038U:
        goto block_0019E038;
    case 0x0019E04CU:
        goto block_0019E04C;
    case 0x0019E070U:
        goto block_0019E070;
    case 0x0019E07CU:
        goto block_0019E07C;
    case 0x0019E084U:
        goto block_0019E084;
    case 0x0019E08CU:
        goto block_0019E08C;
    case 0x0019E0A0U:
        goto block_0019E0A0;
    case 0x0019E0ACU:
        goto block_0019E0AC;
    case 0x0019E0CCU:
        goto block_0019E0CC;
    case 0x0019E10CU:
        goto block_0019E10C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0019D11C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D11CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D11CU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0019D11CU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r0 + operand;
        }
        {
            r9 = r1;
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r1 + operand;
        }
        {
            r13 -= 56U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x0019D130U,
                                           firstAddress + 52U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 - operand;
        }
        {
            const uint32_t address = 0x0019D140U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D138U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0019D144U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D13CU, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D140U, address);
            }
            r6 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D150U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D150U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D150;
    }
block_0019D150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D150U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000338U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D158U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D15CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019D168U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D160U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r9 + operand;
        }
        {
            const uint32_t address = 0x0019D170U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D168U, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x0019D174U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D16CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0019D178U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D170U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0019D17CU + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D174U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t address = 0x0019D180U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D178U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = 0x0019D188U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D180U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x0019D18CU + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D184U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x0019D190U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D188U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x0019D194U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D18CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0019D198U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D190U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0019D19CU + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D194U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00001000U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000032CU;
            r10 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D1A4U, address);
            }
        }
        if (flags.Z()) { goto block_0019DAA8; }
        goto block_0019D1AC;
    }
block_0019D1AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D1ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D1ACU);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0019D1FC; }
        goto block_0019D1B4;
    }
block_0019D1B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D1B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D1B4U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D1BCU, address);
            }
        }
        {
            const uint32_t address = 0x0019D1C8U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1C0U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = 0x0019D1CCU + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1C4U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x0019D1D0U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1C8U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r1 = r9 + operand;
        }
        {
            const uint32_t address = 0x0019D1D8U + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1D0U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0019D1DCU + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1D4U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D1DCU, address);
            }
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0019D1E8U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1E0U, address);
            }
            switch (value) {
            case 0x0019D11CU:
                goto block_0019D11C;
            case 0x0019D150U:
                goto block_0019D150;
            case 0x0019D1ACU:
                goto block_0019D1AC;
            case 0x0019D1B4U:
                goto block_0019D1B4;
            case 0x0019D1E4U:
                goto block_0019D1E4;
            case 0x0019D1FCU:
                goto block_0019D1FC;
            case 0x0019D208U:
                goto block_0019D208;
            case 0x0019D210U:
                goto block_0019D210;
            case 0x0019D218U:
                goto block_0019D218;
            case 0x0019D220U:
                goto block_0019D220;
            case 0x0019D228U:
                goto block_0019D228;
            case 0x0019D250U:
                goto block_0019D250;
            case 0x0019D26CU:
                goto block_0019D26C;
            case 0x0019D28CU:
                goto block_0019D28C;
            case 0x0019D298U:
                goto block_0019D298;
            case 0x0019D2A4U:
                goto block_0019D2A4;
            case 0x0019D2DCU:
                goto block_0019D2DC;
            case 0x0019D2F0U:
                goto block_0019D2F0;
            case 0x0019D314U:
                goto block_0019D314;
            case 0x0019D330U:
                goto block_0019D330;
            case 0x0019D34CU:
                goto block_0019D34C;
            case 0x0019D35CU:
                goto block_0019D35C;
            case 0x0019D368U:
                goto block_0019D368;
            case 0x0019D384U:
                goto block_0019D384;
            case 0x0019D3A0U:
                goto block_0019D3A0;
            case 0x0019D3BCU:
                goto block_0019D3BC;
            case 0x0019D3C8U:
                goto block_0019D3C8;
            case 0x0019D3D4U:
                goto block_0019D3D4;
            case 0x0019D40CU:
                goto block_0019D40C;
            case 0x0019D48CU:
                goto block_0019D48C;
            case 0x0019D49CU:
                goto block_0019D49C;
            case 0x0019D4A4U:
                goto block_0019D4A4;
            case 0x0019D4B0U:
                goto block_0019D4B0;
            case 0x0019D4BCU:
                goto block_0019D4BC;
            case 0x0019D4C8U:
                goto block_0019D4C8;
            case 0x0019D4D4U:
                goto block_0019D4D4;
            case 0x0019D4E8U:
                goto block_0019D4E8;
            case 0x0019D4F8U:
                goto block_0019D4F8;
            case 0x0019D580U:
                goto block_0019D580;
            case 0x0019D5ACU:
                goto block_0019D5AC;
            case 0x0019D5D0U:
                goto block_0019D5D0;
            case 0x0019D5F0U:
                goto block_0019D5F0;
            case 0x0019D610U:
                goto block_0019D610;
            case 0x0019D624U:
                goto block_0019D624;
            case 0x0019D630U:
                goto block_0019D630;
            case 0x0019D650U:
                goto block_0019D650;
            case 0x0019D660U:
                goto block_0019D660;
            case 0x0019D674U:
                goto block_0019D674;
            case 0x0019D684U:
                goto block_0019D684;
            case 0x0019D6B4U:
                goto block_0019D6B4;
            case 0x0019D6C0U:
                goto block_0019D6C0;
            case 0x0019D6D4U:
                goto block_0019D6D4;
            case 0x0019D6E0U:
                goto block_0019D6E0;
            case 0x0019D6F0U:
                goto block_0019D6F0;
            case 0x0019D6FCU:
                goto block_0019D6FC;
            case 0x0019D708U:
                goto block_0019D708;
            case 0x0019D740U:
                goto block_0019D740;
            case 0x0019D754U:
                goto block_0019D754;
            case 0x0019D764U:
                goto block_0019D764;
            case 0x0019D770U:
                goto block_0019D770;
            case 0x0019D788U:
                goto block_0019D788;
            case 0x0019D7A0U:
                goto block_0019D7A0;
            case 0x0019D7B4U:
                goto block_0019D7B4;
            case 0x0019D7C0U:
                goto block_0019D7C0;
            case 0x0019D7DCU:
                goto block_0019D7DC;
            case 0x0019D7E8U:
                goto block_0019D7E8;
            case 0x0019D800U:
                goto block_0019D800;
            case 0x0019D85CU:
                goto block_0019D85C;
            case 0x0019D87CU:
                goto block_0019D87C;
            case 0x0019D890U:
                goto block_0019D890;
            case 0x0019D89CU:
                goto block_0019D89C;
            case 0x0019D8B8U:
                goto block_0019D8B8;
            case 0x0019D8C4U:
                goto block_0019D8C4;
            case 0x0019D8C8U:
                goto block_0019D8C8;
            case 0x0019D8D8U:
                goto block_0019D8D8;
            case 0x0019D8E4U:
                goto block_0019D8E4;
            case 0x0019D8FCU:
                goto block_0019D8FC;
            case 0x0019D90CU:
                goto block_0019D90C;
            case 0x0019D91CU:
                goto block_0019D91C;
            case 0x0019D928U:
                goto block_0019D928;
            case 0x0019D94CU:
                goto block_0019D94C;
            case 0x0019D964U:
                goto block_0019D964;
            case 0x0019D97CU:
                goto block_0019D97C;
            case 0x0019D990U:
                goto block_0019D990;
            case 0x0019D9ACU:
                goto block_0019D9AC;
            case 0x0019D9C0U:
                goto block_0019D9C0;
            case 0x0019D9E0U:
                goto block_0019D9E0;
            case 0x0019D9E8U:
                goto block_0019D9E8;
            case 0x0019DA04U:
                goto block_0019DA04;
            case 0x0019DA18U:
                goto block_0019DA18;
            case 0x0019DA28U:
                goto block_0019DA28;
            case 0x0019DA48U:
                goto block_0019DA48;
            case 0x0019DA54U:
                goto block_0019DA54;
            case 0x0019DA68U:
                goto block_0019DA68;
            case 0x0019DA8CU:
                goto block_0019DA8C;
            case 0x0019DAA8U:
                goto block_0019DAA8;
            case 0x0019DAC0U:
                goto block_0019DAC0;
            case 0x0019DAE0U:
                goto block_0019DAE0;
            case 0x0019DAF8U:
                goto block_0019DAF8;
            case 0x0019DB14U:
                goto block_0019DB14;
            case 0x0019DB28U:
                goto block_0019DB28;
            case 0x0019DB4CU:
                goto block_0019DB4C;
            case 0x0019DB54U:
                goto block_0019DB54;
            case 0x0019DB64U:
                goto block_0019DB64;
            case 0x0019DB70U:
                goto block_0019DB70;
            case 0x0019DB88U:
                goto block_0019DB88;
            case 0x0019DB94U:
                goto block_0019DB94;
            case 0x0019DBA0U:
                goto block_0019DBA0;
            case 0x0019DBC8U:
                goto block_0019DBC8;
            case 0x0019DBE0U:
                goto block_0019DBE0;
            case 0x0019DC04U:
                goto block_0019DC04;
            case 0x0019DC28U:
                goto block_0019DC28;
            case 0x0019DC84U:
                goto block_0019DC84;
            case 0x0019DC9CU:
                goto block_0019DC9C;
            case 0x0019DCBCU:
                goto block_0019DCBC;
            case 0x0019DCD8U:
                goto block_0019DCD8;
            case 0x0019DCF4U:
                goto block_0019DCF4;
            case 0x0019DD14U:
                goto block_0019DD14;
            case 0x0019DD28U:
                goto block_0019DD28;
            case 0x0019DD34U:
                goto block_0019DD34;
            case 0x0019DD48U:
                goto block_0019DD48;
            case 0x0019DD54U:
                goto block_0019DD54;
            case 0x0019DD6CU:
                goto block_0019DD6C;
            case 0x0019DD90U:
                goto block_0019DD90;
            case 0x0019DD9CU:
                goto block_0019DD9C;
            case 0x0019DDC4U:
                goto block_0019DDC4;
            case 0x0019DDD0U:
                goto block_0019DDD0;
            case 0x0019DDE8U:
                goto block_0019DDE8;
            case 0x0019DE08U:
                goto block_0019DE08;
            case 0x0019DE24U:
                goto block_0019DE24;
            case 0x0019DE40U:
                goto block_0019DE40;
            case 0x0019DE54U:
                goto block_0019DE54;
            case 0x0019DE60U:
                goto block_0019DE60;
            case 0x0019DE74U:
                goto block_0019DE74;
            case 0x0019DE80U:
                goto block_0019DE80;
            case 0x0019DEA0U:
                goto block_0019DEA0;
            case 0x0019DED8U:
                goto block_0019DED8;
            case 0x0019DF1CU:
                goto block_0019DF1C;
            case 0x0019DF30U:
                goto block_0019DF30;
            case 0x0019DF40U:
                goto block_0019DF40;
            case 0x0019DF4CU:
                goto block_0019DF4C;
            case 0x0019DF58U:
                goto block_0019DF58;
            case 0x0019DF64U:
                goto block_0019DF64;
            case 0x0019DF90U:
                goto block_0019DF90;
            case 0x0019DFA0U:
                goto block_0019DFA0;
            case 0x0019DFACU:
                goto block_0019DFAC;
            case 0x0019DFB8U:
                goto block_0019DFB8;
            case 0x0019DFBCU:
                goto block_0019DFBC;
            case 0x0019DFCCU:
                goto block_0019DFCC;
            case 0x0019DFD4U:
                goto block_0019DFD4;
            case 0x0019DFE0U:
                goto block_0019DFE0;
            case 0x0019DFE8U:
                goto block_0019DFE8;
            case 0x0019E000U:
                goto block_0019E000;
            case 0x0019E010U:
                goto block_0019E010;
            case 0x0019E01CU:
                goto block_0019E01C;
            case 0x0019E02CU:
                goto block_0019E02C;
            case 0x0019E038U:
                goto block_0019E038;
            case 0x0019E04CU:
                goto block_0019E04C;
            case 0x0019E070U:
                goto block_0019E070;
            case 0x0019E07CU:
                goto block_0019E07C;
            case 0x0019E084U:
                goto block_0019E084;
            case 0x0019E08CU:
                goto block_0019E08C;
            case 0x0019E0A0U:
                goto block_0019E0A0;
            case 0x0019E0ACU:
                goto block_0019E0AC;
            case 0x0019E0CCU:
                goto block_0019E0CC;
            case 0x0019E10CU:
                goto block_0019E10C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0019D1E4;
    }
block_0019D1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D1E4U);
        }
        goto block_0019D35C;
    }
block_0019D1FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D1FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D1FCU);
        }
        {
            const uint32_t address = 0x0019D204U + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D1FCU, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019DC84; }
        goto block_0019D208;
    }
block_0019D208:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D208U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D208U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000082U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019DDD0; }
        goto block_0019D210;
    }
block_0019D210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D210U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000008CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019E084; }
        goto block_0019D218;
    }
block_0019D218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D218U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D35C; }
        goto block_0019D220;
    }
block_0019D220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D220U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D228U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D228U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D228;
    }
block_0019D228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D228U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D228U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D234U + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D22CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0019D238U + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D230U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D234U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0019D240U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D238U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x0000032CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D250U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D250U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D250;
    }
block_0019D250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D250U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D250U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D25CU, 0xEE300A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000330U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D26CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D26CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D26C;
    }
block_0019D26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D26CU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D26CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D278U + 508U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D270U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D27CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000334U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D28CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D28CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D28C;
    }
block_0019D28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D28CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D28CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D35C; }
        goto block_0019D298;
    }
block_0019D298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D298U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D2A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D2A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D2A4;
    }
block_0019D2A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D2A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D2A4U);
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D2A4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D2A4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019D2A4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D2ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019D2ACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019D2ACU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D2B4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D2B4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019D2B4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D2BCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019D2BCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019D2BCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019D2C8U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D2D0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D2DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D2DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D2DC;
    }
block_0019D2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D2DCU);
        }
        {
            r6 = 0x00000000U;
        }
        {
            r1 = 0x00000012U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0019D2E8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D2F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D2F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D2F0;
    }
block_0019D2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D2F0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0019D300U + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D2F8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000012U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D308U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D314U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D314U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D314;
    }
block_0019D314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D314U);
        }
        {
            const uint32_t updatedAddress = 0x0019D31CU + 0x160U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D314U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r7 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0019D318U, address);
            }
        }
        {
            const uint32_t address = r7 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0019D31CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D320U, address);
            }
        }
        {
            r1 = 0x0000006EU;
        }
        {
            r0 = 0x00000046U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D330U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_S16Offset_003702c8_003702C8(frame, context, state, 0x003702C8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D330U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D330;
    }
block_0019D330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D330U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D330U, address);
            }
        }
        {
            r0 = 0x000000C8U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0019D338U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D33CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D340U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D34CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D34CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D34C;
    }
block_0019D34C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D34CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D34CU);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D35CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D35CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D35C;
    }
block_0019D35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D35CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D35CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019E10C; }
        goto block_0019D368;
    }
block_0019D368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D368U);
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000032CU;
            r3 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x0019D370U,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            r13 += 56U;
        }
        {
            const uint32_t operand = 0x00000338U;
            r2 = r4 + operand;
        }
        {
            r0 = r9;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0019D37CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x00367B14U);
    }
block_0019D384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D384U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D384U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019D390U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D388U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D38CU, 0xEE300A49U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D390U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019D35C; }
        goto block_0019D3A0;
    }
block_0019D3A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D3A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D3A0U);
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D3A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D3ACU + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D3A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D3A8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D3ACU, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019D35C; }
        goto block_0019D3BC;
    }
block_0019D3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D3BCU);
        }
        {
            const uint32_t updatedAddress = r8 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D3BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0019D48C; }
        goto block_0019D3C8;
    }
block_0019D3C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D3C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D3C8U);
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D3D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGoma_SetupEncounterState4_00345AEC(frame, context, state, 0x00345AECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D3D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D3D4;
    }
block_0019D3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D3D4U);
        }
        {
            const uint32_t updatedAddress = 0x0019D3DCU + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D3D4U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000180U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[27];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0019D3ECU, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D3F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0019D3F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D3F8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000002EU;
        }
        {
            r2 = r9;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D40C;
    }
block_0019D40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D40CU);
        }
        {
        }
        {
        }
        goto block_0019D4A4;
    }
block_0019D48C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D48CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D48CU);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D49CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D49CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D49C;
    }
block_0019D49C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D49CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D49CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D4A0U, address);
            }
        }
        goto block_0019D4A4;
    }
block_0019D4A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4A4U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D4B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D4B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D4B0;
    }
block_0019D4B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4B0U);
        }
        {
        }
        {
        }
        goto block_0019D35C;
    }
block_0019D4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4BCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D4BCU, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D4C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D4C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D4C8;
    }
block_0019D4C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4C8U);
        }
        {
            r0 = r9;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D4D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D4D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D4D4;
    }
block_0019D4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4D4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D4D4U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D4E8;
    }
block_0019D4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4E8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D4E8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D4F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D4F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D4F8;
    }
block_0019D4F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D4F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D4F8U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0019D504U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D4FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D500U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D504U, address);
            }
        }
        {
            const uint32_t address = 0x0019D510U + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D508U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D514U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D50CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D510U, address);
            }
        }
        {
            const uint32_t address = 0x0019D51CU + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D514U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000032U;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D51CU, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019D520U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0019D524U, address);
            }
        }
        {
            const uint32_t address = r6 + 264U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019D528U, address);
            }
        }
        {
            const uint32_t address = r6 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0019D52CU, address);
            }
        }
        {
            const uint32_t address = r4 + 812U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D530U, address);
            }
        }
        {
            const uint32_t address = r4 + 816U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0019D534U, address);
            }
        }
        {
            const uint32_t address = r4 + 820U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D538U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D53CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D548U + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D540U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 824U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D544U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D548U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D54CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D550U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 828U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D554U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D558U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 832U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D55CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D560U, address);
            }
        }
        {
            r0 = 0x00000050U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D568U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D570U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D574U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D57CU, address);
            }
        }
        goto block_0019D580;
    }
block_0019D580:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D580U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D580U);
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019D580U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019D58CU - 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D584U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0019D588U, address);
            }
        }
        {
            const uint32_t address = r6 + 264U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019D58CU, address);
            }
        }
        {
            const uint32_t address = r6 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0019D590U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0019D594U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0019D598U, address);
            }
        }
        {
            const uint32_t address = r6 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019D59CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D660; }
        goto block_0019D5AC;
    }
block_0019D5AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D5ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D5ACU);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019D5B8U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D5BCU + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5B4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0019D5C0U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5B8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D5BCU, 0xEE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000032CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D5D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D5D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D5D0;
    }
block_0019D5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D5D0U);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000330U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D5D8U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D5E8U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5E0U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D5E4U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D5F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D5F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D5F0;
    }
block_0019D5F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D5F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D5F0U);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D5FCU + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D5F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000334U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D5FCU, 0xEE201A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D600U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D604U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D610U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D610U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D610;
    }
block_0019D610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D610U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x0019D61CU + 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D614U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0019D620U + 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D618U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D624U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D624U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D624;
    }
block_0019D624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D624U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D624U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D650; }
        goto block_0019D630;
    }
block_0019D630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D630U);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D630U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D63CU + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D634U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000033CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D63CU, 0xEE201A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D640U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D644U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D650U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D650U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D650;
    }
block_0019D650:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D650U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D650U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D650U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 824U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D654U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D658U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 832U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019D65CU, address);
            }
        }
        goto block_0019D660;
    }
block_0019D660:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D660U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D660U);
        }
        {
            const uint32_t operand = 0x0000032CU;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000338U;
            r2 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D674U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D674U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D674;
    }
block_0019D674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D674U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D674U, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000003U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000B0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D6D4; }
        goto block_0019D684;
    }
block_0019D684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D684U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D688U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019D688U,
                                           firstAddress + 4U);
            }
        }
        {
            r3 = 0x00000180U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[27];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0019D69CU, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D6A0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000002EU;
        }
        {
            r2 = r9;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D6B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D6B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D6B4;
    }
block_0019D6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D6B4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D6B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000B0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0019D6D4; }
        goto block_0019D6C0;
    }
block_0019D6C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D6C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D6C0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D6C0U, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0019D6C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019D6D4U + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D6CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D6D0U, address);
            }
        }
        goto block_0019D6D4;
    }
block_0019D6D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D6D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D6D4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D6D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000BEU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D6F0; }
        goto block_0019D6E0;
    }
block_0019D6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D6E0U);
        }
        {
            r2 = 0x00000068U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D6F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D6F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D6F0;
    }
block_0019D6F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D6F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D6F0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D6F0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000E4U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0019D35C; }
        goto block_0019D6FC;
    }
block_0019D6FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D6FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D6FCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D708U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D708U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D708;
    }
block_0019D708:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D708U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D708U);
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D708U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D708U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019D708U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D710U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019D710U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019D710U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D718U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D718U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019D718U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D720U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019D720U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019D720U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D724U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019D728U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019D728U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019D728U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019D72CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019D72CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019D72CU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D734U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D740U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D740U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D740;
    }
block_0019D740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D740U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D744U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D748U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D754U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D754U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D754;
    }
block_0019D754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D754U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D764;
    }
block_0019D764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D764U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0019D764U, address);
            }
        }
        {
        }
        goto block_0019D35C;
    }
block_0019D770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D770U);
        }
        {
            const uint32_t address = r4 + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D770U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019D77CU + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D774U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D778U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019D85C; }
        goto block_0019D788;
    }
block_0019D788:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D788U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D788U);
        }
        {
            const uint32_t address = r4 + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D788U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00190000U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D790U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019D85C; }
        goto block_0019D7A0;
    }
block_0019D7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D7A0U);
        }
        {
            const uint32_t address = r4 + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D7A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019D7ACU + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D7A4U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019D85C; }
        goto block_0019D7B4;
    }
block_0019D7B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D7B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D7B4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D7B4U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0019D85C; }
        goto block_0019D7C0;
    }
block_0019D7C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D7C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D7C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D7C0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D7D0U, address);
            }
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D7DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D7DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D7DC;
    }
block_0019D7DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D7DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D7DCU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D7DCU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D7E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldYawTowardActor_0036E800(frame, context, state, 0x0036E800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D7E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D7E8;
    }
block_0019D7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D7E8U);
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0019D7F4U + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D7ECU, address);
            }
            r3 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D800;
    }
block_0019D800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D800U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D804U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x3AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D808U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D80CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D810U, address);
            }
        }
        goto block_0019D87C;
    }
block_0019D85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D85CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019D864U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0019D874U - 1020U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D86CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D87CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGoma_UpdateCeilingMovement_00366D18(frame, context, state, 0x00366D18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D87CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D87C;
    }
block_0019D87C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D87CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D87CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D87CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r1 = r9;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = r4;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D890U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGoma_SetupEncounterState4_00345AEC(frame, context, state, 0x00345AECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D890U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D890;
    }
block_0019D890:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D890U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D890U);
        }
        {
        }
        {
        }
        goto block_0019D35C;
    }
block_0019D89C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D89CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D89CU);
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0019D8A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D8A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = 0x00000016U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D8B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorContext_FindActorsById_00360084(frame, context, state, 0x00360084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D8B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D8B8;
    }
block_0019D8B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D8B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D8B8U);
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r8 = r0 - operand;
        }
        {
            r6 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0019D8E4; }
        goto block_0019D8C4;
    }
block_0019D8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D8C4U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r10 = r13 + operand;
        }
        goto block_0019D8C8;
    }
block_0019D8C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D8C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D8C8U);
        }
        {
            const uint32_t updatedAddress = r10 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D8C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D8CCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D8D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D8D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D8D8;
    }
block_0019D8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D8D8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0019D8C8; }
        goto block_0019D8E4;
    }
block_0019D8E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D8E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D8E4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0019D8F4U + 844U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D8ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D8FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003524ec_003524EC(frame, context, state, 0x003524ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D8FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D8FC;
    }
block_0019D8FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D8FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D8FCU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D90CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D90CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D90C;
    }
block_0019D90C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D90CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D90CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0019D918U + 0x32CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D910U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = r4;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D91CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D91CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D91C;
    }
block_0019D91C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D91CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D91CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D91CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000028U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0019D35C; }
        goto block_0019D928;
    }
block_0019D928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D928U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D928U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D934U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D92CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019D938U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D930U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0019D93CU + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D934U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D938U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x0000032CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D94CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D94CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D94C;
    }
block_0019D94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D94CU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D94CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D958U, 0xEE300A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000330U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D964U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D964U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D964;
    }
block_0019D964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D964U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D964U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D970U, 0xEE300A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000334U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D97CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D97CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D97C;
    }
block_0019D97C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D97CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D97CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D984U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000338U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D990;
    }
block_0019D990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D990U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D990U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019D99CU + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D994U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x0000033CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019D9A0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D9ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D9ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D9AC;
    }
block_0019D9AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D9ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D9ACU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D9B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000340U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D9C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D9C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D9C0;
    }
block_0019D9C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D9C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D9C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D9C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D9C8U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            r1 = 0x00000004U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019D9D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D9D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019D35C; }
        goto block_0019D9E0;
    }
block_0019D9E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D9E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D9E0U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019D9E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019D9E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019D9E8;
    }
block_0019D9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019D9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019D9E8U);
        }
        {
            const uint32_t address = 0x0019D9F0U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D9E8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0019D9F4U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019D9ECU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000294U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DA04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DA04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DA04;
    }
block_0019DA04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA04U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x000002C0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DA18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DA18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DA18;
    }
block_0019DA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA18U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x0019DA24U + 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DA1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DA28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DA28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DA28;
    }
block_0019DA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0019DA34U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DA2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 660U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DA34U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DA38U, address);
            }
        }
        {
            const uint32_t address = r4 + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DA3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DA48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DA48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DA48;
    }
block_0019DA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA48U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019D35C; }
        goto block_0019DA54;
    }
block_0019DA54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA54U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019DA58U, address);
            }
        }
        {
            r1 = 0x00000010U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DA68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DA68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DA68;
    }
block_0019DA68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA68U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0019DA78U + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DA70U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DA80U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DA8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DA8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DA8C;
    }
block_0019DA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DA8CU);
        }
        {
            const uint32_t address = 0x0019DA94U + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DA8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0019DA90U, address);
            }
        }
        {
            const uint32_t address = r7 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DA94U, address);
            }
        }
        {
            const uint32_t address = r4 + 700U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DA98U, address);
            }
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019DAA0U, address);
            }
        }
        goto block_0019D35C;
    }
block_0019DAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DAA8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0019DAB8U + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DAC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003524ec_003524EC(frame, context, state, 0x003524ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DAC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DAC0;
    }
block_0019DAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DAC0U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAC0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAC4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019DAD0U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAC8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DACCU, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DAD0U, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x0000032CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DAE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DAE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DAE0;
    }
block_0019DAE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DAE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DAE0U);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000330U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DAECU, 0xEE201A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DAF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DAF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DAF8;
    }
block_0019DAF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DAF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DAF8U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAF8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DAFCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000334U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DB04U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DB08U, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DB14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DB14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DB14;
    }
block_0019DB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB14U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x0019DB20U + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB18U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000002BCU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DB28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DB28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DB28;
    }
block_0019DB28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB28U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 824U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DB2CU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 828U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DB34U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 832U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DB3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB40U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019DB70; }
        goto block_0019DB4C;
    }
block_0019DB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB4CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DB54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DB54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DB54;
    }
block_0019DB54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB54U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DB64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DB64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DB64;
    }
block_0019DB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB64U);
        }
        {
        }
        {
        }
        goto block_0019DB88;
    }
block_0019DB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB70U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0019DB80U + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB78U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DB88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGoma_UpdateCeilingMovement_00366D18(frame, context, state, 0x00366D18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DB88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DB88;
    }
block_0019DB88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB88U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DB88U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D35C; }
        goto block_0019DB94;
    }
block_0019DB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DB94U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DBA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DBA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DBA0;
    }
block_0019DBA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DBA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DBA0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0019DBACU + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DBA4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000000U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x0000000FU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DBB8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DBC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DBC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DBC8;
    }
block_0019DBC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DBC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DBC8U);
        }
        {
            const uint32_t address = 0x0019DBD0U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DBC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0019DBCCU, address);
            }
        }
        {
            const uint32_t address = r7 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DBD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DBD4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D35C; }
        goto block_0019DBE0;
    }
block_0019DBE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DBE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DBE0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019DBE8U, address);
            }
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DBECU, address);
            }
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0019DBF4U, address);
            }
        }
        {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0019DBF8U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DC04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DC04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DC04;
    }
block_0019DC04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DC04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DC04U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DC1CU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DC28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DC28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DC28;
    }
block_0019DC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DC28U);
        }
        {
            const uint32_t address = r7 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DC28U, address);
            }
        }
        {
            const uint32_t address = r7 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DC2CU, address);
            }
        }
        {
            const uint32_t address = 0x0019DC38U + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DC30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DC34U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DC38U, address);
            }
        }
        goto block_0019D35C;
    }
block_0019DC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DC84U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DC9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003524ec_003524EC(frame, context, state, 0x003524ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DC9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DC9C;
    }
block_0019DC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DC9CU);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DC9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCA0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019DCACU - 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCA4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DCA8U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DCACU, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x0000032CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DCBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DCBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DCBC;
    }
block_0019DCBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DCBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DCBCU);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000330U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DCC8U, 0xEE201A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCCCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DCD0U, 0xEE300A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DCD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DCD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DCD8;
    }
block_0019DCD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DCD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DCD8U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCDCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000334U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DCE4U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DCE8U, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DCF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DCF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DCF4;
    }
block_0019DCF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DCF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DCF4U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DCF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r4 + 824U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DCFCU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DD00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 828U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DD04U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DD08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 832U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DD0CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD14;
    }
block_0019DD14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD14U);
        }
        {
            const uint32_t updatedAddress = 0x0019DD1CU - 0x4C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DD14U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD28;
    }
block_0019DD28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD28U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DD28U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldYawTowardActor_0036E800(frame, context, state, 0x0036E800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD34;
    }
block_0019DD34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD34U);
        }
        {
            r1 = r0;
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD48;
    }
block_0019DD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD48U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DD48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0019D35C; }
        goto block_0019DD54;
    }
block_0019DD54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD54U);
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DD54U, address);
            }
        }
        {
            r0 = 0x00000082U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019DD5CU, address);
            }
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD6C;
    }
block_0019DD6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD6CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DD84U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD90;
    }
block_0019DD90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD90U);
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DD9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DD9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DD9C;
    }
block_0019DD9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DD9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DD9CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r3 = 0x00000005U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DDB0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 696U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DDB4U, address);
            }
        }
        {
            const uint32_t address = r7 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DDB8U, address);
            }
        }
        {
            const uint32_t address = r7 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019DDBCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DDC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGoma_PlayEffectsAndSfx_0036FCFC(frame, context, state, 0x0036FCFCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DDC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DDC4;
    }
block_0019DDC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DDC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DDC4U);
        }
        {
            r0 = 0x00000017U;
        }
        {
        }
        goto block_0019E07C;
    }
block_0019DDD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DDD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DDD0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0019DDE0U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DDD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DDE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003524ec_003524EC(frame, context, state, 0x003524ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DDE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DDE8;
    }
block_0019DDE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DDE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DDE8U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DDE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DDECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019DDF8U - 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DDF0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DDF4U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DDF8U, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x0000032CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE08;
    }
block_0019DE08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE08U);
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000330U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DE14U, 0xEE201A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DE1CU, 0xEE300A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE24;
    }
block_0019DE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE24U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000334U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DE30U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DE34U, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE40;
    }
block_0019DE40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE40U);
        }
        {
            const uint32_t updatedAddress = 0x0019DE48U - 0x5F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE40U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE54;
    }
block_0019DE54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE54U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE54U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldYawTowardActor_0036E800(frame, context, state, 0x0036E800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE60;
    }
block_0019DE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE60U);
        }
        {
            r1 = r0;
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE74;
    }
block_0019DE74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE74U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DE80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DE80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DE80;
    }
block_0019DE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DE80U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019DE8CU + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE84U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = r4 + 824U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DE88U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 832U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DE90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DE94U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019DF1C; }
        goto block_0019DEA0;
    }
block_0019DEA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DEA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DEA0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEA4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEA8U, 0xEE600A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEB0U, 0xDE100A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEB4U, 0xCE000A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0019DEC0U + 544U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DEB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEBCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEC8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DECCU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DED0U, 0xEE200A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DED8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DED8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DED8;
    }
block_0019DED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DED8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DED8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0019DEE4U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DEDCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEE8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEECU, 0xEE600AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEF0U, 0xDE50BA8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[23], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEF4U, 0xCE40BA8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[23], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DEF8U, 0xEEFD0AEBU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DF04U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DF08U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DF0CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019DF10U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 828U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019DF14U, address);
            }
        }
        goto block_0019DF30;
    }
block_0019DF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF1CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DF24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000033CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DF30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DF30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DF30;
    }
block_0019DF30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF30U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[26];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DF40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DF40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DF40;
    }
block_0019DF40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF40U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019E01C; }
        goto block_0019DF4C;
    }
block_0019DF4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF4CU);
        }
        {
            const uint32_t updatedAddress = 0x0019DF54U + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DF4CU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DF58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DF58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DF58;
    }
block_0019DF58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF58U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DF58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0019DF90; }
        goto block_0019DF64;
    }
block_0019DF64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF64U);
        }
        {
            r3 = 0x00000040U;
        }
        {
            r2 = 0x00000100U;
        }
        {
            r1 = 0x000000B4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0019DF70U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019DF70U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019DF70U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DF7CU, address);
            }
            r2 = value;
        }
        {
            r3 = 0x000000C8U;
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DF90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TitleCard_InitBossName_00354248(frame, context, state, 0x00354248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DF90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DF90;
    }
block_0019DF90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DF90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DF90U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0019DF9CU + 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DF94U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DFA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DFA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DFA0;
    }
block_0019DFA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFA0U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DFACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DFACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DFAC;
    }
block_0019DFAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019E010; }
        goto block_0019DFB8;
    }
block_0019DFB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFB8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DFBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b0a0_0035B0A0(frame, context, state, 0x0035B0A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DFBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DFBC;
    }
block_0019DFBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFBCU);
        }
        {
            const uint32_t updatedAddress = 0x0019DFC4U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFBCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0019E000; }
        goto block_0019DFCC;
    }
block_0019DFCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFCCU);
        }
        {
            const uint32_t updatedAddress = 0x0019DFD4U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFCCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DFD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DFD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DFD4;
    }
block_0019DFD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFD4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019E000; }
        goto block_0019DFE0;
    }
block_0019DFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFE0U);
        }
        {
            const uint32_t updatedAddress = 0x0019DFE8U + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFE0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019DFE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019DFE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019DFE8;
    }
block_0019DFE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019DFE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019DFE8U);
        }
        {
            const uint32_t updatedAddress = 0x0019DFF0U + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFE8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0019DFF4U + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFECU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0019DFFCU + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019DFF4U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0019E000;
    }
block_0019E000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E000U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = 0x0019E00CU + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E004U, address);
            }
            r0 = value;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E010U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003542c4_003542C4(frame, context, state, 0x003542C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E010U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E010;
    }
block_0019E010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E010U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E010U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r8 + 0xFAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E018U, address);
            }
        }
        goto block_0019E01C;
    }
block_0019E01C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E01CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E01CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r4 + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E020U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E02CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E02CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E02C;
    }
block_0019E02C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E02CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E02CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019D35C; }
        goto block_0019E038;
    }
block_0019E038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E038U);
        }
        {
            r0 = 0x0000008CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E03CU, address);
            }
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E04CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E04CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E04C;
    }
block_0019E04C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E04CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E04CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0019E05CU + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E054U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E064U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E070;
    }
block_0019E070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E070U);
        }
        {
            const uint32_t address = r7 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0019E070U, address);
            }
        }
        {
            const uint32_t address = r7 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0019E074U, address);
            }
        }
        {
            r0 = 0x0000001EU;
        }
        goto block_0019E07C;
    }
block_0019E07C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E07CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E07CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E07CU, address);
            }
        }
        goto block_0019D35C;
    }
block_0019E084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E084U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E08CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E08CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E08C;
    }
block_0019E08C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E08CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E08CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E090U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019E09CU + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E094U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000033CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E0A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E0A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E0A0;
    }
block_0019E0A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E0A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E0A0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E0A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019D35C; }
        goto block_0019E0AC;
    }
block_0019E0AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E0ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E0ACU);
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E0B0U, address);
            }
        }
        {
            r0 = 0x00000096U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E0B8U, address);
            }
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E0CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E0CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E0CC;
    }
block_0019E0CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E0CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E0CCU);
        }
        {
        }
        {
        }
        goto block_0019D35C;
    }
block_0019E10C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E10CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E10CU);
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x0019E110U,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            r13 += 56U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0019E114U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossVa_Init_001A8A5C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001A8A5CU:
        goto block_001A8A5C;
    case 0x001A8A78U:
        goto block_001A8A78;
    case 0x001A8AACU:
        goto block_001A8AAC;
    case 0x001A8B04U:
        goto block_001A8B04;
    case 0x001A8B1CU:
        goto block_001A8B1C;
    case 0x001A8B3CU:
        goto block_001A8B3C;
    case 0x001A8B48U:
        goto block_001A8B48;
    case 0x001A8B54U:
        goto block_001A8B54;
    case 0x001A8B68U:
        goto block_001A8B68;
    case 0x001A8B70U:
        goto block_001A8B70;
    case 0x001A8B90U:
        goto block_001A8B90;
    case 0x001A8C40U:
        goto block_001A8C40;
    case 0x001A8C64U:
        goto block_001A8C64;
    case 0x001A8C70U:
        goto block_001A8C70;
    case 0x001A8C88U:
        goto block_001A8C88;
    case 0x001A8C8CU:
        goto block_001A8C8C;
    case 0x001A8C98U:
        goto block_001A8C98;
    case 0x001A8CB0U:
        goto block_001A8CB0;
    case 0x001A8CB4U:
        goto block_001A8CB4;
    case 0x001A8CC0U:
        goto block_001A8CC0;
    case 0x001A8CD8U:
        goto block_001A8CD8;
    case 0x001A8CFCU:
        goto block_001A8CFC;
    case 0x001A8D00U:
        goto block_001A8D00;
    case 0x001A8D20U:
        goto block_001A8D20;
    case 0x001A8D4CU:
        goto block_001A8D4C;
    case 0x001A8D60U:
        goto block_001A8D60;
    case 0x001A8D84U:
        goto block_001A8D84;
    case 0x001A8DA4U:
        goto block_001A8DA4;
    case 0x001A8DC8U:
        goto block_001A8DC8;
    case 0x001A8E20U:
        goto block_001A8E20;
    case 0x001A8E3CU:
        goto block_001A8E3C;
    case 0x001A8E70U:
        goto block_001A8E70;
    case 0x001A8E84U:
        goto block_001A8E84;
    case 0x001A8EA8U:
        goto block_001A8EA8;
    case 0x001A8ED4U:
        goto block_001A8ED4;
    case 0x001A8EDCU:
        goto block_001A8EDC;
    case 0x001A8EF4U:
        goto block_001A8EF4;
    case 0x001A8F14U:
        goto block_001A8F14;
    case 0x001A8F3CU:
        goto block_001A8F3C;
    case 0x001A8F48U:
        goto block_001A8F48;
    case 0x001A8F68U:
        goto block_001A8F68;
    case 0x001A8F98U:
        goto block_001A8F98;
    case 0x001A8FACU:
        goto block_001A8FAC;
    case 0x001A8FD0U:
        goto block_001A8FD0;
    case 0x001A8FE8U:
        goto block_001A8FE8;
    case 0x001A8FF0U:
        goto block_001A8FF0;
    case 0x001A900CU:
        goto block_001A900C;
    case 0x001A9014U:
        goto block_001A9014;
    case 0x001A9020U:
        goto block_001A9020;
    case 0x001A90ACU:
        goto block_001A90AC;
    case 0x001A90B8U:
        goto block_001A90B8;
    case 0x001A90E4U:
        goto block_001A90E4;
    case 0x001A90F0U:
        goto block_001A90F0;
    case 0x001A910CU:
        goto block_001A910C;
    case 0x001A9110U:
        goto block_001A9110;
    case 0x001A9120U:
        goto block_001A9120;
    case 0x001A9158U:
        goto block_001A9158;
    case 0x001A9160U:
        goto block_001A9160;
    case 0x001A916CU:
        goto block_001A916C;
    case 0x001A9180U:
        goto block_001A9180;
    case 0x001A9188U:
        goto block_001A9188;
    case 0x001A9194U:
        goto block_001A9194;
    case 0x001A919CU:
        goto block_001A919C;
    case 0x001A91B4U:
        goto block_001A91B4;
    case 0x001A91C4U:
        goto block_001A91C4;
    case 0x001A91FCU:
        goto block_001A91FC;
    case 0x001A9280U:
        goto block_001A9280;
    case 0x001A92C0U:
        goto block_001A92C0;
    case 0x001A92CCU:
        goto block_001A92CC;
    case 0x001A92D8U:
        goto block_001A92D8;
    case 0x001A92E8U:
        goto block_001A92E8;
    case 0x001A92F4U:
        goto block_001A92F4;
    case 0x001A933CU:
        goto block_001A933C;
    case 0x001A9378U:
        goto block_001A9378;
    case 0x001A938CU:
        goto block_001A938C;
    case 0x001A9398U:
        goto block_001A9398;
    case 0x001A93BCU:
        goto block_001A93BC;
    case 0x001A93DCU:
        goto block_001A93DC;
    case 0x001A940CU:
        goto block_001A940C;
    case 0x001A9418U:
        goto block_001A9418;
    case 0x001A942CU:
        goto block_001A942C;
    case 0x001A943CU:
        goto block_001A943C;
    case 0x001A94A8U:
        goto block_001A94A8;
    case 0x001A94BCU:
        goto block_001A94BC;
    case 0x001A9538U:
        goto block_001A9538;
    case 0x001A9544U:
        goto block_001A9544;
    case 0x001A9564U:
        goto block_001A9564;
    case 0x001A9574U:
        goto block_001A9574;
    case 0x001A9594U:
        goto block_001A9594;
    case 0x001A95A8U:
        goto block_001A95A8;
    case 0x001A95B4U:
        goto block_001A95B4;
    case 0x001A9630U:
        goto block_001A9630;
    case 0x001A963CU:
        goto block_001A963C;
    case 0x001A964CU:
        goto block_001A964C;
    case 0x001A9660U:
        goto block_001A9660;
    case 0x001A9664U:
        goto block_001A9664;
    case 0x001A96B8U:
        goto block_001A96B8;
    case 0x001A96D4U:
        goto block_001A96D4;
    case 0x001A96F4U:
        goto block_001A96F4;
    case 0x001A96FCU:
        goto block_001A96FC;
    case 0x001A9720U:
        goto block_001A9720;
    case 0x001A9750U:
        goto block_001A9750;
    case 0x001A9764U:
        goto block_001A9764;
    case 0x001A9784U:
        goto block_001A9784;
    case 0x001A979CU:
        goto block_001A979C;
    case 0x001A97A0U:
        goto block_001A97A0;
    case 0x001A97C4U:
        goto block_001A97C4;
    case 0x001A97D8U:
        goto block_001A97D8;
    case 0x001A97E0U:
        goto block_001A97E0;
    case 0x001A9804U:
        goto block_001A9804;
    case 0x001A9848U:
        goto block_001A9848;
    case 0x001A9858U:
        goto block_001A9858;
    case 0x001A986CU:
        goto block_001A986C;
    case 0x001A9880U:
        goto block_001A9880;
    case 0x001A9898U:
        goto block_001A9898;
    case 0x001A989CU:
        goto block_001A989C;
    case 0x001A98C0U:
        goto block_001A98C0;
    case 0x001A98D8U:
        goto block_001A98D8;
    case 0x001A98E0U:
        goto block_001A98E0;
    case 0x001A9904U:
        goto block_001A9904;
    case 0x001A991CU:
        goto block_001A991C;
    case 0x001A9928U:
        goto block_001A9928;
    case 0x001A994CU:
        goto block_001A994C;
    case 0x001A9964U:
        goto block_001A9964;
    case 0x001A9990U:
        goto block_001A9990;
    case 0x001A99A4U:
        goto block_001A99A4;
    case 0x001A99C4U:
        goto block_001A99C4;
    case 0x001A99D8U:
        goto block_001A99D8;
    case 0x001A99ECU:
        goto block_001A99EC;
    case 0x001A9A10U:
        goto block_001A9A10;
    case 0x001A9A1CU:
        goto block_001A9A1C;
    case 0x001A9A44U:
        goto block_001A9A44;
    case 0x001A9A50U:
        goto block_001A9A50;
    case 0x001A9AFCU:
        goto block_001A9AFC;
    case 0x001A9B24U:
        goto block_001A9B24;
    case 0x001A9B38U:
        goto block_001A9B38;
    case 0x001A9B3CU:
        goto block_001A9B3C;
    case 0x001A9B64U:
        goto block_001A9B64;
    case 0x001A9B9CU:
        goto block_001A9B9C;
    case 0x001A9BA4U:
        goto block_001A9BA4;
    case 0x001A9BCCU:
        goto block_001A9BCC;
    case 0x001A9C0CU:
        goto block_001A9C0C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001A8A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8A5CU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001A8A5CU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r7 = r1;
        }
        {
            const uint32_t address = 0x001A8A70U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8A68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001A8A6CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001A8A6CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8A78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8A78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8A78;
    }
block_001A8A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8A78U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8A7CU, address);
            }
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00001000U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8A88U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8A90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x205U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8A94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x206U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8A98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8A9CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000015U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x001A8AB0U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8AA8U, address);
            }
            switch (value) {
            case 0x001A8A5CU:
                goto block_001A8A5C;
            case 0x001A8A78U:
                goto block_001A8A78;
            case 0x001A8AACU:
                goto block_001A8AAC;
            case 0x001A8B04U:
                goto block_001A8B04;
            case 0x001A8B1CU:
                goto block_001A8B1C;
            case 0x001A8B3CU:
                goto block_001A8B3C;
            case 0x001A8B48U:
                goto block_001A8B48;
            case 0x001A8B54U:
                goto block_001A8B54;
            case 0x001A8B68U:
                goto block_001A8B68;
            case 0x001A8B70U:
                goto block_001A8B70;
            case 0x001A8B90U:
                goto block_001A8B90;
            case 0x001A8C40U:
                goto block_001A8C40;
            case 0x001A8C64U:
                goto block_001A8C64;
            case 0x001A8C70U:
                goto block_001A8C70;
            case 0x001A8C88U:
                goto block_001A8C88;
            case 0x001A8C8CU:
                goto block_001A8C8C;
            case 0x001A8C98U:
                goto block_001A8C98;
            case 0x001A8CB0U:
                goto block_001A8CB0;
            case 0x001A8CB4U:
                goto block_001A8CB4;
            case 0x001A8CC0U:
                goto block_001A8CC0;
            case 0x001A8CD8U:
                goto block_001A8CD8;
            case 0x001A8CFCU:
                goto block_001A8CFC;
            case 0x001A8D00U:
                goto block_001A8D00;
            case 0x001A8D20U:
                goto block_001A8D20;
            case 0x001A8D4CU:
                goto block_001A8D4C;
            case 0x001A8D60U:
                goto block_001A8D60;
            case 0x001A8D84U:
                goto block_001A8D84;
            case 0x001A8DA4U:
                goto block_001A8DA4;
            case 0x001A8DC8U:
                goto block_001A8DC8;
            case 0x001A8E20U:
                goto block_001A8E20;
            case 0x001A8E3CU:
                goto block_001A8E3C;
            case 0x001A8E70U:
                goto block_001A8E70;
            case 0x001A8E84U:
                goto block_001A8E84;
            case 0x001A8EA8U:
                goto block_001A8EA8;
            case 0x001A8ED4U:
                goto block_001A8ED4;
            case 0x001A8EDCU:
                goto block_001A8EDC;
            case 0x001A8EF4U:
                goto block_001A8EF4;
            case 0x001A8F14U:
                goto block_001A8F14;
            case 0x001A8F3CU:
                goto block_001A8F3C;
            case 0x001A8F48U:
                goto block_001A8F48;
            case 0x001A8F68U:
                goto block_001A8F68;
            case 0x001A8F98U:
                goto block_001A8F98;
            case 0x001A8FACU:
                goto block_001A8FAC;
            case 0x001A8FD0U:
                goto block_001A8FD0;
            case 0x001A8FE8U:
                goto block_001A8FE8;
            case 0x001A8FF0U:
                goto block_001A8FF0;
            case 0x001A900CU:
                goto block_001A900C;
            case 0x001A9014U:
                goto block_001A9014;
            case 0x001A9020U:
                goto block_001A9020;
            case 0x001A90ACU:
                goto block_001A90AC;
            case 0x001A90B8U:
                goto block_001A90B8;
            case 0x001A90E4U:
                goto block_001A90E4;
            case 0x001A90F0U:
                goto block_001A90F0;
            case 0x001A910CU:
                goto block_001A910C;
            case 0x001A9110U:
                goto block_001A9110;
            case 0x001A9120U:
                goto block_001A9120;
            case 0x001A9158U:
                goto block_001A9158;
            case 0x001A9160U:
                goto block_001A9160;
            case 0x001A916CU:
                goto block_001A916C;
            case 0x001A9180U:
                goto block_001A9180;
            case 0x001A9188U:
                goto block_001A9188;
            case 0x001A9194U:
                goto block_001A9194;
            case 0x001A919CU:
                goto block_001A919C;
            case 0x001A91B4U:
                goto block_001A91B4;
            case 0x001A91C4U:
                goto block_001A91C4;
            case 0x001A91FCU:
                goto block_001A91FC;
            case 0x001A9280U:
                goto block_001A9280;
            case 0x001A92C0U:
                goto block_001A92C0;
            case 0x001A92CCU:
                goto block_001A92CC;
            case 0x001A92D8U:
                goto block_001A92D8;
            case 0x001A92E8U:
                goto block_001A92E8;
            case 0x001A92F4U:
                goto block_001A92F4;
            case 0x001A933CU:
                goto block_001A933C;
            case 0x001A9378U:
                goto block_001A9378;
            case 0x001A938CU:
                goto block_001A938C;
            case 0x001A9398U:
                goto block_001A9398;
            case 0x001A93BCU:
                goto block_001A93BC;
            case 0x001A93DCU:
                goto block_001A93DC;
            case 0x001A940CU:
                goto block_001A940C;
            case 0x001A9418U:
                goto block_001A9418;
            case 0x001A942CU:
                goto block_001A942C;
            case 0x001A943CU:
                goto block_001A943C;
            case 0x001A94A8U:
                goto block_001A94A8;
            case 0x001A94BCU:
                goto block_001A94BC;
            case 0x001A9538U:
                goto block_001A9538;
            case 0x001A9544U:
                goto block_001A9544;
            case 0x001A9564U:
                goto block_001A9564;
            case 0x001A9574U:
                goto block_001A9574;
            case 0x001A9594U:
                goto block_001A9594;
            case 0x001A95A8U:
                goto block_001A95A8;
            case 0x001A95B4U:
                goto block_001A95B4;
            case 0x001A9630U:
                goto block_001A9630;
            case 0x001A963CU:
                goto block_001A963C;
            case 0x001A964CU:
                goto block_001A964C;
            case 0x001A9660U:
                goto block_001A9660;
            case 0x001A9664U:
                goto block_001A9664;
            case 0x001A96B8U:
                goto block_001A96B8;
            case 0x001A96D4U:
                goto block_001A96D4;
            case 0x001A96F4U:
                goto block_001A96F4;
            case 0x001A96FCU:
                goto block_001A96FC;
            case 0x001A9720U:
                goto block_001A9720;
            case 0x001A9750U:
                goto block_001A9750;
            case 0x001A9764U:
                goto block_001A9764;
            case 0x001A9784U:
                goto block_001A9784;
            case 0x001A979CU:
                goto block_001A979C;
            case 0x001A97A0U:
                goto block_001A97A0;
            case 0x001A97C4U:
                goto block_001A97C4;
            case 0x001A97D8U:
                goto block_001A97D8;
            case 0x001A97E0U:
                goto block_001A97E0;
            case 0x001A9804U:
                goto block_001A9804;
            case 0x001A9848U:
                goto block_001A9848;
            case 0x001A9858U:
                goto block_001A9858;
            case 0x001A986CU:
                goto block_001A986C;
            case 0x001A9880U:
                goto block_001A9880;
            case 0x001A9898U:
                goto block_001A9898;
            case 0x001A989CU:
                goto block_001A989C;
            case 0x001A98C0U:
                goto block_001A98C0;
            case 0x001A98D8U:
                goto block_001A98D8;
            case 0x001A98E0U:
                goto block_001A98E0;
            case 0x001A9904U:
                goto block_001A9904;
            case 0x001A991CU:
                goto block_001A991C;
            case 0x001A9928U:
                goto block_001A9928;
            case 0x001A994CU:
                goto block_001A994C;
            case 0x001A9964U:
                goto block_001A9964;
            case 0x001A9990U:
                goto block_001A9990;
            case 0x001A99A4U:
                goto block_001A99A4;
            case 0x001A99C4U:
                goto block_001A99C4;
            case 0x001A99D8U:
                goto block_001A99D8;
            case 0x001A99ECU:
                goto block_001A99EC;
            case 0x001A9A10U:
                goto block_001A9A10;
            case 0x001A9A1CU:
                goto block_001A9A1C;
            case 0x001A9A44U:
                goto block_001A9A44;
            case 0x001A9A50U:
                goto block_001A9A50;
            case 0x001A9AFCU:
                goto block_001A9AFC;
            case 0x001A9B24U:
                goto block_001A9B24;
            case 0x001A9B38U:
                goto block_001A9B38;
            case 0x001A9B3CU:
                goto block_001A9B3C;
            case 0x001A9B64U:
                goto block_001A9B64;
            case 0x001A9B9CU:
                goto block_001A9B9C;
            case 0x001A9BA4U:
                goto block_001A9BA4;
            case 0x001A9BCCU:
                goto block_001A9BCC;
            case 0x001A9C0CU:
                goto block_001A9C0C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_001A8AAC;
    }
block_001A8AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8AACU);
        }
        goto block_001A90B8;
    }
block_001A8B04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B04U);
        }
        {
            const uint32_t updatedAddress = 0x001A8B0CU + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B04U, address);
            }
            r5 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x001A8B14U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B14U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8B1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034325c_0034325C(frame, context, state, 0x0034325CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8B1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8B1C;
    }
block_001A8B1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B1CU);
        }
        {
            const uint32_t updatedAddress = 0x001A8B24U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B20U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A8B2CU + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B24U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B30U, address);
            }
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8B3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8B3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8B3C;
    }
block_001A8B3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B3CU);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r9 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r9, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8B40U, address);
            }
        }
        if (flags.Z()) { goto block_001A8B68; }
        goto block_001A8B48;
    }
block_001A8B48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B48U);
        }
        {
            r1 = r8;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8B54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memzero_00343280(frame, context, state, 0x00343280U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8B54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8B54;
    }
block_001A8B54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B54U);
        }
        {
            const uint32_t updatedAddress = 0x001A8B5CU + 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B54U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x000000C8U;
        }
        {
            r2 = 0x000000A0U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r9 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8B68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Array_Construct_00350820(frame, context, state, 0x00350820U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8B68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8B68;
    }
block_001A8B68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B68U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B68U, address);
            }
            r2 = value;
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001A8B70;
    }
block_001A8B70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B70U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 5U);
            r1 = r2 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B88U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_001A8B70; }
        goto block_001A8B90;
    }
block_001A8B90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8B90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8B90U);
        }
        {
            const uint32_t updatedAddress = 0x001A8B98U + 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8B90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8B94U, address);
            }
        }
        {
            const uint32_t operand = 0x00001200U;
            r1 = r4 + operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r2;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8BA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A8BACU + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8BA4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8BACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001A8BB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8BB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A8BB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A8BBCU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001F8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8BC8U, address);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001FCU;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A8BD4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A8BD8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001F0U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8BE4U, address);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001F4U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A8BF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A8BF4U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001E8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8C00U, address);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001ECU;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A8C0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A8C10U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x000001E0U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A8C24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A8C24U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A8C24U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001DCU;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8C40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8C40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8C40;
    }
block_001A8C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8C40U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8C40U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = 0x001A8C4CU + 0x1C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8C44U, address);
            }
            r1 = value;
        }
        {
            r9 = r0;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8C50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8C54U, address);
            }
            r0 = value;
        }
        {
            r6 = r5;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r8 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r10;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8C60U, address);
            }
        }
        goto block_001A8C64;
    }
block_001A8C64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8C64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8C64U);
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8C70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorModelCache_Acquire_00371478(frame, context, state, 0x00371478U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8C70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8C70;
    }
block_001A8C70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8C70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8C70U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8C74U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001A8C64; }
        goto block_001A8C88;
    }
block_001A8C88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8C88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8C88U);
        }
        {
            r6 = 0x00000000U;
        }
        goto block_001A8C8C;
    }
block_001A8C8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8C8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8C8CU);
        }
        {
            r1 = 0x0000000AU;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8C98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorModelCache_Acquire_00371478(frame, context, state, 0x00371478U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8C98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8C98;
    }
block_001A8C98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8C98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8C98U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8C9CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001A8C8C; }
        goto block_001A8CB0;
    }
block_001A8CB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8CB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8CB0U);
        }
        {
            r6 = 0x00000000U;
        }
        goto block_001A8CB4;
    }
block_001A8CB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8CB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8CB4U);
        }
        {
            r1 = 0x0000000BU;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8CC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorModelCache_Acquire_00371478(frame, context, state, 0x00371478U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8CC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8CC0;
    }
block_001A8CC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8CC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8CC0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8CC4U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001A8CB4; }
        goto block_001A8CD8;
    }
block_001A8CD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8CD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8CD8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = r5 & 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8CE8U, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            r1 = 0x00000002U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8CF0U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r5, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001A8D20; }
        goto block_001A8CFC;
    }
block_001A8CFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8CFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8CFCU);
        }
        {
            r1 = 0x00000002U;
        }
        goto block_001A8D00;
    }
block_001A8D00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8D00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8D00U);
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D00U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8D04U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D10U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r5, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8D18U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_001A8D00; }
        goto block_001A8D20;
    }
block_001A8D20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8D20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8D20U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000021U;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000228U;
            r1 = r4 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001A8D34U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A8D34U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A8D34U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A8D34U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000003U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8D4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActor_00353C9C(frame, context, state, 0x00353C9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8D4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8D4C;
    }
block_001A8D4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8D4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8D4CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D4CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D54U, address);
            }
            r8 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8D60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8D60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8D60;
    }
block_001A8D60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8D60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8D60U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D64U, address);
            }
            r0 = value;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D6CU, address);
            }
            r5 = value;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8D74U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8D84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8D84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8D84;
    }
block_001A8D84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8D84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8D84U);
        }
        {
            const uint32_t address = 0x001A8D8CU + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8D84U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r6 = 0x00000001U;
        }
        {
            r1 = 0x00000004U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = r9;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A8D98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8D9CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8DA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8DA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8DA4;
    }
block_001A8DA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8DA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8DA4U);
        }
        {
            r9 = r0;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            r1 = r8;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8DB8U, address);
            }
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8DC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8DC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8DC8;
    }
block_001A8DC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8DC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8DC8U);
        }
        {
            const uint32_t updatedAddress = 0x001A8DD0U + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8DC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001A8DCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8DD0U, address);
            }
        }
        {
            const uint32_t address = 0x001A8DDCU + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8DD4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001A8DD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8DDCU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 | 0x01000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8DE4U, address);
            }
        }
        {
            const uint32_t address = r4 + 416U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A8DE8U, address);
            }
        }
        goto block_001A9160;
    }
block_001A8E20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8E20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8E20U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001D8U;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A8E34U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8E3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8E3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8E3C;
    }
block_001A8E3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8E3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8E3CU);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000228U;
            r1 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A8E48U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A8E48U,
                                           firstAddress + 4U);
            }
        }
        {
            r3 = 0x00000006U;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A8E54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A8E58U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8E70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActor_00353C9C(frame, context, state, 0x00353C9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8E70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8E70;
    }
block_001A8E70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8E70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8E70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8E70U, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8E78U, address);
            }
            r9 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8E84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8E84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8E84;
    }
block_001A8E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8E84U);
        }
        {
            r8 = r0;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            r1 = r9;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8E98U, address);
            }
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8EA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8EA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8EA8;
    }
block_001A8EA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8EA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8EA8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8EA8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001A8EB4U + 0x3A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8EACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x001A8EB8U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8EB0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = r6 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001A8EB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8EBCU, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A8EC8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A8ECCU, address);
            }
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8ED4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_NormalizeFrame_003586EC(frame, context, state, 0x003586ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8ED4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8ED4;
    }
block_001A8ED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8ED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8ED4U);
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8EDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Update_00373BEC(frame, context, state, 0x00373BECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8EDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8EDC;
    }
block_001A8EDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8EDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8EDCU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A8EE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8EE4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001A8EF0U - 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8EE8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001A8EECU, address);
            }
        }
        goto block_001A9160;
    }
block_001A8EF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8EF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8EF4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A8EFCU, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001D8U;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8F14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8F14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8F14;
    }
block_001A8F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8F14U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000228U;
            r1 = r4 + operand;
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001A8F28U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A8F28U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A8F28U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A8F28U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8F3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActor_00353C9C(frame, context, state, 0x00353C9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8F3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8F3C;
    }
block_001A8F3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8F3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8F3CU);
        }
        {
        }
        {
        }
        goto block_001A9160;
    }
block_001A8F48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8F48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8F48U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A8F50U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001D8U;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8F68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8F68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8F68;
    }
block_001A8F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8F68U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000228U;
            r1 = r4 + operand;
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001A8F80U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A8F80U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A8F80U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A8F80U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8F98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActor_00353C9C(frame, context, state, 0x00353C9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8F98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8F98;
    }
block_001A8F98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8F98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8F98U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8F98U, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FA0U, address);
            }
            r8 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8FACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8FACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8FAC;
    }
block_001A8FAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8FACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8FACU);
        }
        {
            r9 = r0;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            r1 = r8;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A8FC0U, address);
            }
        }
        {
            r1 = r9;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A8FD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A8FD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A8FD0;
    }
block_001A8FD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8FD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8FD0U);
        }
        {
            const uint32_t address = 0x001A8FD8U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FD0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FD4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t address = 0x001A8FE8U - 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) { goto block_001A8FF0; }
        goto block_001A8FE8;
    }
block_001A8FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8FE8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000012U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t address = 0x001A8FF4U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_001A8FF0;
    }
block_001A8FF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A8FF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A8FF0U);
        }
        {
            const uint32_t updatedAddress = 0x001A8FF8U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FF0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r6 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001A8FF4U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A8FFCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9004U, address);
            }
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001A900CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_NormalizeFrame_003586EC(frame, context, state, 0x003586ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A900CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A900C;
    }
block_001A900C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A900CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A900CU);
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9014U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Update_00373BEC(frame, context, state, 0x00373BECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9014U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9014;
    }
block_001A9014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9014U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9018U, address);
            }
        }
        goto block_001A9160;
    }
block_001A9020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9020U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001F8U;
            r1 = r1 + operand;
        }
        {
            r0 = 0x00000015U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A902CU, faultAddress);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000016U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9038U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001F0U;
            r1 = r1 + operand;
        }
        {
            r0 = 0x00000013U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9048U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001F4U;
            r3 = r3 + operand;
        }
        {
            r2 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9058U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001E8U;
            r1 = r1 + operand;
        }
        {
            r0 = 0x00000011U;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9068U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001ECU;
            r3 = r3 + operand;
        }
        {
            r2 = 0x00000012U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9078U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r3 = r3 + operand;
        }
        {
            r2 = 0x00000010U;
        }
        {
            const uint32_t operand = 0x000001E0U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A9090U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A9090U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A9090U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x0000000FU;
        }
        {
            const uint32_t operand = 0x000001DCU;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A90ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A90ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A90AC;
    }
block_001A90AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A90ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A90ACU);
        }
        {
        }
        {
        }
        goto block_001A9160;
    }
block_001A90B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A90B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A90B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A90B8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            r1 = r0 | 0x01000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A90C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A90CCU, address);
            }
        }
        {
            r3 = 0x00000007U;
        }
        {
            const uint32_t operand = 0x000001D8U;
            r2 = r2 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A90E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A90E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A90E4;
    }
block_001A90E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A90E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A90E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A90E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_001A910C; }
        goto block_001A90F0;
    }
block_001A90F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A90F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A90F0U);
        }
        {
            const uint32_t updatedAddress = 0x001A90F8U + 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A90F0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A90F8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_001A9110; }
        goto block_001A910C;
    }
block_001A910C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A910CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A910CU);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001A9110;
    }
block_001A9110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9110U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r5 = r0 + operand;
        }
        {
            r1 = 0x00000007U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9120U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMBByIndex_00358EF8(frame, context, state, 0x00358EF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9120U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9120;
    }
block_001A9120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9120U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x19AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9128U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A912CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A9130U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A9134U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A9138U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A913CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A9148U, address);
            }
        }
        {
            r3 = r0;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9158U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitAsset_00358EA8(frame, context, state, 0x00358EA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9158U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9158;
    }
block_001A9158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9158U);
        }
        {
            const uint32_t address = 0x001A9160U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9158U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A915CU, address);
            }
        }
        goto block_001A9160;
    }
block_001A9160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9160U);
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A916CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034f248_0034F248(frame, context, state, 0x0034F248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A916CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A916C;
    }
block_001A916C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A916CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A916CU);
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = 0x001A9178U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9170U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9174U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001A91B4; }
        goto block_001A9180;
    }
block_001A9180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9180U);
        }
        {
            const uint32_t updatedAddress = 0x001A9188U + 0xE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9180U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9188U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9188U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9188;
    }
block_001A9188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9188U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001A91B4; }
        goto block_001A9194;
    }
block_001A9194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9194U);
        }
        {
            const uint32_t updatedAddress = 0x001A919CU + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9194U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A919CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A919CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A919C;
    }
block_001A919C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A919CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A919CU);
        }
        {
            const uint32_t updatedAddress = 0x001A91A4U + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A919CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001A91A8U + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91A0U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x001A91B0U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91A8U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_001A91B4;
    }
block_001A91B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A91B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A91B4U);
        }
        {
            const uint32_t updatedAddress = 0x001A91BCU + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91B4U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91BCU, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A91C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCTXBByIndex_00372C90(frame, context, state, 0x00372C90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A91C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A91C4;
    }
block_001A91C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A91C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A91C4U);
        }
        {
            const uint32_t updatedAddress = 0x001A91CCU + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A91C8U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A91D0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001A91DCU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001A91DCU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001A91DCU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            r1 = 0x00000014U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A91E4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A91E4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001A91E4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x123U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A91E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000015U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x001A9200U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A91F8U, address);
            }
            switch (value) {
            case 0x001A8A5CU:
                goto block_001A8A5C;
            case 0x001A8A78U:
                goto block_001A8A78;
            case 0x001A8AACU:
                goto block_001A8AAC;
            case 0x001A8B04U:
                goto block_001A8B04;
            case 0x001A8B1CU:
                goto block_001A8B1C;
            case 0x001A8B3CU:
                goto block_001A8B3C;
            case 0x001A8B48U:
                goto block_001A8B48;
            case 0x001A8B54U:
                goto block_001A8B54;
            case 0x001A8B68U:
                goto block_001A8B68;
            case 0x001A8B70U:
                goto block_001A8B70;
            case 0x001A8B90U:
                goto block_001A8B90;
            case 0x001A8C40U:
                goto block_001A8C40;
            case 0x001A8C64U:
                goto block_001A8C64;
            case 0x001A8C70U:
                goto block_001A8C70;
            case 0x001A8C88U:
                goto block_001A8C88;
            case 0x001A8C8CU:
                goto block_001A8C8C;
            case 0x001A8C98U:
                goto block_001A8C98;
            case 0x001A8CB0U:
                goto block_001A8CB0;
            case 0x001A8CB4U:
                goto block_001A8CB4;
            case 0x001A8CC0U:
                goto block_001A8CC0;
            case 0x001A8CD8U:
                goto block_001A8CD8;
            case 0x001A8CFCU:
                goto block_001A8CFC;
            case 0x001A8D00U:
                goto block_001A8D00;
            case 0x001A8D20U:
                goto block_001A8D20;
            case 0x001A8D4CU:
                goto block_001A8D4C;
            case 0x001A8D60U:
                goto block_001A8D60;
            case 0x001A8D84U:
                goto block_001A8D84;
            case 0x001A8DA4U:
                goto block_001A8DA4;
            case 0x001A8DC8U:
                goto block_001A8DC8;
            case 0x001A8E20U:
                goto block_001A8E20;
            case 0x001A8E3CU:
                goto block_001A8E3C;
            case 0x001A8E70U:
                goto block_001A8E70;
            case 0x001A8E84U:
                goto block_001A8E84;
            case 0x001A8EA8U:
                goto block_001A8EA8;
            case 0x001A8ED4U:
                goto block_001A8ED4;
            case 0x001A8EDCU:
                goto block_001A8EDC;
            case 0x001A8EF4U:
                goto block_001A8EF4;
            case 0x001A8F14U:
                goto block_001A8F14;
            case 0x001A8F3CU:
                goto block_001A8F3C;
            case 0x001A8F48U:
                goto block_001A8F48;
            case 0x001A8F68U:
                goto block_001A8F68;
            case 0x001A8F98U:
                goto block_001A8F98;
            case 0x001A8FACU:
                goto block_001A8FAC;
            case 0x001A8FD0U:
                goto block_001A8FD0;
            case 0x001A8FE8U:
                goto block_001A8FE8;
            case 0x001A8FF0U:
                goto block_001A8FF0;
            case 0x001A900CU:
                goto block_001A900C;
            case 0x001A9014U:
                goto block_001A9014;
            case 0x001A9020U:
                goto block_001A9020;
            case 0x001A90ACU:
                goto block_001A90AC;
            case 0x001A90B8U:
                goto block_001A90B8;
            case 0x001A90E4U:
                goto block_001A90E4;
            case 0x001A90F0U:
                goto block_001A90F0;
            case 0x001A910CU:
                goto block_001A910C;
            case 0x001A9110U:
                goto block_001A9110;
            case 0x001A9120U:
                goto block_001A9120;
            case 0x001A9158U:
                goto block_001A9158;
            case 0x001A9160U:
                goto block_001A9160;
            case 0x001A916CU:
                goto block_001A916C;
            case 0x001A9180U:
                goto block_001A9180;
            case 0x001A9188U:
                goto block_001A9188;
            case 0x001A9194U:
                goto block_001A9194;
            case 0x001A919CU:
                goto block_001A919C;
            case 0x001A91B4U:
                goto block_001A91B4;
            case 0x001A91C4U:
                goto block_001A91C4;
            case 0x001A91FCU:
                goto block_001A91FC;
            case 0x001A9280U:
                goto block_001A9280;
            case 0x001A92C0U:
                goto block_001A92C0;
            case 0x001A92CCU:
                goto block_001A92CC;
            case 0x001A92D8U:
                goto block_001A92D8;
            case 0x001A92E8U:
                goto block_001A92E8;
            case 0x001A92F4U:
                goto block_001A92F4;
            case 0x001A933CU:
                goto block_001A933C;
            case 0x001A9378U:
                goto block_001A9378;
            case 0x001A938CU:
                goto block_001A938C;
            case 0x001A9398U:
                goto block_001A9398;
            case 0x001A93BCU:
                goto block_001A93BC;
            case 0x001A93DCU:
                goto block_001A93DC;
            case 0x001A940CU:
                goto block_001A940C;
            case 0x001A9418U:
                goto block_001A9418;
            case 0x001A942CU:
                goto block_001A942C;
            case 0x001A943CU:
                goto block_001A943C;
            case 0x001A94A8U:
                goto block_001A94A8;
            case 0x001A94BCU:
                goto block_001A94BC;
            case 0x001A9538U:
                goto block_001A9538;
            case 0x001A9544U:
                goto block_001A9544;
            case 0x001A9564U:
                goto block_001A9564;
            case 0x001A9574U:
                goto block_001A9574;
            case 0x001A9594U:
                goto block_001A9594;
            case 0x001A95A8U:
                goto block_001A95A8;
            case 0x001A95B4U:
                goto block_001A95B4;
            case 0x001A9630U:
                goto block_001A9630;
            case 0x001A963CU:
                goto block_001A963C;
            case 0x001A964CU:
                goto block_001A964C;
            case 0x001A9660U:
                goto block_001A9660;
            case 0x001A9664U:
                goto block_001A9664;
            case 0x001A96B8U:
                goto block_001A96B8;
            case 0x001A96D4U:
                goto block_001A96D4;
            case 0x001A96F4U:
                goto block_001A96F4;
            case 0x001A96FCU:
                goto block_001A96FC;
            case 0x001A9720U:
                goto block_001A9720;
            case 0x001A9750U:
                goto block_001A9750;
            case 0x001A9764U:
                goto block_001A9764;
            case 0x001A9784U:
                goto block_001A9784;
            case 0x001A979CU:
                goto block_001A979C;
            case 0x001A97A0U:
                goto block_001A97A0;
            case 0x001A97C4U:
                goto block_001A97C4;
            case 0x001A97D8U:
                goto block_001A97D8;
            case 0x001A97E0U:
                goto block_001A97E0;
            case 0x001A9804U:
                goto block_001A9804;
            case 0x001A9848U:
                goto block_001A9848;
            case 0x001A9858U:
                goto block_001A9858;
            case 0x001A986CU:
                goto block_001A986C;
            case 0x001A9880U:
                goto block_001A9880;
            case 0x001A9898U:
                goto block_001A9898;
            case 0x001A989CU:
                goto block_001A989C;
            case 0x001A98C0U:
                goto block_001A98C0;
            case 0x001A98D8U:
                goto block_001A98D8;
            case 0x001A98E0U:
                goto block_001A98E0;
            case 0x001A9904U:
                goto block_001A9904;
            case 0x001A991CU:
                goto block_001A991C;
            case 0x001A9928U:
                goto block_001A9928;
            case 0x001A994CU:
                goto block_001A994C;
            case 0x001A9964U:
                goto block_001A9964;
            case 0x001A9990U:
                goto block_001A9990;
            case 0x001A99A4U:
                goto block_001A99A4;
            case 0x001A99C4U:
                goto block_001A99C4;
            case 0x001A99D8U:
                goto block_001A99D8;
            case 0x001A99ECU:
                goto block_001A99EC;
            case 0x001A9A10U:
                goto block_001A9A10;
            case 0x001A9A1CU:
                goto block_001A9A1C;
            case 0x001A9A44U:
                goto block_001A9A44;
            case 0x001A9A50U:
                goto block_001A9A50;
            case 0x001A9AFCU:
                goto block_001A9AFC;
            case 0x001A9B24U:
                goto block_001A9B24;
            case 0x001A9B38U:
                goto block_001A9B38;
            case 0x001A9B3CU:
                goto block_001A9B3C;
            case 0x001A9B64U:
                goto block_001A9B64;
            case 0x001A9B9CU:
                goto block_001A9B9C;
            case 0x001A9BA4U:
                goto block_001A9BA4;
            case 0x001A9BCCU:
                goto block_001A9BCC;
            case 0x001A9C0CU:
                goto block_001A9C0C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_001A91FC;
    }
block_001A91FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A91FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A91FCU);
        }
        goto block_001A9990;
    }
block_001A9280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9280U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x001A928CU - 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9284U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r3 = 0x00000013U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A928CU, faultAddress);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A929CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A92A0U, address);
            }
        }
        {
            const uint32_t address = 0x001A92ACU - 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A92A4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001A92B0U + 960U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A92A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x000000BAU;
        }
        {
            r2 = r7;
        }
        {
            r1 = r4;
        }
        {
            r11 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A92C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A92C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A92C0;
    }
block_001A92C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A92C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A92C0U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A92CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A92CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A92CC;
    }
block_001A92CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A92CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A92CCU);
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_001A9398; }
        goto block_001A92D8;
    }
block_001A92D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A92D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A92D8U);
        }
        {
            const uint32_t updatedAddress = 0x001A92E0U + 0x394U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A92D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A92DCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A92E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetClear_0036CF6C(frame, context, state, 0x0036CF6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A92E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A92E8;
    }
block_001A92E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A92E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A92E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
        }
        if (flags.Z()) { goto block_001A9398; }
        goto block_001A92F4;
    }
block_001A92F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A92F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A92F4U);
        }
        {
            const uint32_t updatedAddress = 0x001A92FCU + 0x37CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A92F4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r12 = 0x000000A1U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9304U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9308U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A930CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A9310U, address);
            }
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            r12 = 0x0000005DU;
        }
        {
            r3 = r2;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9320U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9324U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9328U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = r12;
        }
        {
            r1 = r7;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A933CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A933CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A933C;
    }
block_001A933C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A933CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A933CU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001A9344U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A9348U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001A934CU, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9350U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001A935CU + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9354U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r3 = r2;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A935CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9360U, 0xEE300A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9364U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x0000005FU;
        }
        {
            r1 = r7;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9378U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9378U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9378;
    }
block_001A9378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9378U);
        }
        {
            const uint32_t updatedAddress = 0x001A9380U - 0x58CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9378U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9380U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A938CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A938CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A938C;
    }
block_001A938C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A938CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A938CU);
        }
        {
        }
        {
        }
        goto block_001A9C0C;
    }
block_001A9398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9398U);
        }
        {
            const uint32_t updatedAddress = 0x001A93A0U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9398U, address);
            }
            r1 = value;
        }
        {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t operand = 0x00000298U;
            r9 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A93A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A93A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A93B4U + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A93ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A93B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001A9564; }
        goto block_001A93BC;
    }
block_001A93BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A93BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A93BCU);
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A93C0U, address);
            }
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A93C8U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A93DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A93DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A93DC;
    }
block_001A93DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A93DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A93DCU);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            r1 = 0x000000DCU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A93E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A93E8U, address);
            }
        }
        {
            r1 = 0x000000BEU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A93F0U, address);
            }
        }
        {
            r1 = 0x000000D2U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A93F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A940CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A940CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A940C;
    }
block_001A940C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A940CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A940CU);
        }
        {
            r0 = r7;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9418;
    }
block_001A9418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9418U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9418U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A942CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A942CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A942C;
    }
block_001A942C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A942CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A942CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A942CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A943CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A943CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A943C;
    }
block_001A943C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A943CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A943CU);
        }
        {
            const uint32_t updatedAddress = 0x001A9444U + 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A943CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001A9448U + 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9440U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9448U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A944CU, address);
            }
        }
        {
            const uint32_t address = 0x001A9458U + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9450U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9454U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9458U, address);
            }
        }
        {
            const uint32_t address = 0x001A9464U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A945CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9460U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9464U, address);
            }
        }
        {
            const uint32_t address = 0x001A9470U + 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9468U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9474U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9478U, address);
            }
        }
        {
            const uint32_t address = 0x001A9484U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A947CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r1 - operand;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9484U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9488U, address);
            }
        }
        {
            const uint32_t address = 0x001A9494U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A948CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9494U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9498U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A949CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A94A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A94A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A94A8;
    }
block_001A94A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A94A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A94A8U);
        }
        {
            r1 = 0x00000014U;
        }
        {
            r5 = 0x0000000FU;
        }
        {
            const uint32_t operand = 0x00000214U;
            r6 = r9 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r8 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A94B8U, address);
            }
        }
        goto block_001A94BC;
    }
block_001A94BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A94BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A94BCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r12 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A94C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r5, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A94CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A94D0U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A94D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A94E0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r10;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A94E8U, address);
            }
            r10 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t operand = r10;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001A94F8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A94F8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A94F8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A94F8U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9500U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9504U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9508U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r3 = 0x000000BAU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9510U, 0xEE301A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9514U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9518U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = r7;
        }
        {
            r1 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9524U, 0xEE700A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9528U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9530U, 0xEE300A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9538U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9538U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9538;
    }
block_001A9538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9538U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001A94BC; }
        goto block_001A9544;
    }
block_001A9544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9544U);
        }
        {
            const uint32_t updatedAddress = 0x001A954CU + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9544U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001A954CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001A954CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001A954CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x00000048U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A9554U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A9554U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001A9554U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001A9558U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001A9558U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001A9558U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A955CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A955CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001A955CU,
                                           firstAddress + 8U);
            }
        }
        goto block_001A9574;
    }
block_001A9564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9564U);
        }
        {
            r0 = 0x000000FCU;
        }
        {
            const uint32_t updatedAddress = r9 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9568U, address);
            }
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9570U, address);
            }
        }
        goto block_001A9574;
    }
block_001A9574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9574U);
        }
        {
            const uint32_t address = 0x001A957CU + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9574U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 976U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001A9580U, address);
            }
        }
        {
            const uint32_t operand = 0x00000090U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9594U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9594U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9594;
    }
block_001A9594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9594U);
        }
        {
            const uint32_t updatedAddress = 0x001A959CU + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9594U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A95A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinder_00353D24(frame, context, state, 0x00353D24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A95A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A95A8;
    }
block_001A95A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A95A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A95A8U);
        }
        {
            const uint32_t updatedAddress = 0x001A95B0U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95A8U, address);
            }
            r6 = value;
        }
        {
            r5 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x00000138U;
            r8 = r6 - operand;
        }
        goto block_001A95B4;
    }
block_001A95B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A95B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A95B4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r12 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r5, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95C4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95C8U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95D8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r10;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95E0U, address);
            }
            r10 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t operand = r10;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001A95F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001A95F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001A95F0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001A95F0U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A95FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9600U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r3 = 0x000000BAU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9608U, 0xEE301A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A960CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9610U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = r7;
        }
        {
            r1 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A961CU, 0xEE700A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9620U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9628U, 0xEE300A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9630U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9630U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9630;
    }
block_001A9630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9630U);
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r5, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r5 = r5 - operand;
        }
        {
        }
        if (!(flags.N())) { goto block_001A95B4; }
        goto block_001A963C;
    }
block_001A963C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A963CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A963CU);
        }
        {
            const uint32_t updatedAddress = 0x001A9644U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A963CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001A9648U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9640U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A964CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Lib_MemSet_0034322C(frame, context, state, 0x0034322CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A964CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A964C;
    }
block_001A964C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A964CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A964CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A964CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r1 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_001A96F4; }
        goto block_001A9660;
    }
block_001A9660:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9660U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9660U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9664;
    }
block_001A9664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9664U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9668U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_001A96B8;
    }
block_001A96B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A96B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A96B8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A96D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A96D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A96D4;
    }
block_001A96D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A96D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A96D4U);
        }
        {
            const uint32_t address = 0x001A96DCU + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A96D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A96D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A96DCU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A96ECU + 0x3C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A96E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A96E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A96ECU, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A96F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A96F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A96F4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A96FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A96FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A96FC;
    }
block_001A96FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A96FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A96FCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9710U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9720;
    }
block_001A9720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9720U);
        }
        {
            const uint32_t address = 0x001A9728U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9720U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9724U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9728U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9730U, address);
            }
        }
        {
            r1 = 0x00000026U;
        }
        {
            r0 = 0x00000080U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A973CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9740U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A974CU + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9744U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9748U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9750:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9750U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9750U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000E8U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitJntSph_00350EB8(frame, context, state, 0x00350EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9764;
    }
block_001A9764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9764U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000108U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A976CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A9778U + 0x344U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9770U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9784U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetJntSph_00350D48(frame, context, state, 0x00350D48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9784U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9784;
    }
block_001A9784:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9784U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9784U);
        }
        {
            const uint32_t updatedAddress = 0x001A978CU - 0x998U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9784U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A978CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_001A97D8; }
        goto block_001A979C;
    }
block_001A979C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A979CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A979CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A97A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A97A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A97A0;
    }
block_001A97A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A97A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A97A0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A97B0U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001A97BCU + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A97B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A97C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A97C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A97C4;
    }
block_001A97C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A97C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A97C4U);
        }
        {
            const uint32_t updatedAddress = 0x001A97CCU + 0x2F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A97C4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A97CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A97D0U, address);
            }
        }
        goto block_001A9848;
    }
block_001A97D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A97D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A97D8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A97E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A97E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A97E0;
    }
block_001A97E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A97E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A97E0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A97ECU + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A97E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000006U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A97F8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001A9804U - 352U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A97FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9804U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9804U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9804;
    }
block_001A9804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9804U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9804U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001A9810U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9808U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A981CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9820U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001A982CU + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9824U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A982CU, 0xDE110A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9830U, 0xCE010A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9834U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A983CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A9848U + 0x288U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9840U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9844U, address);
            }
        }
        goto block_001A9848;
    }
block_001A9848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9848U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF94U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9848U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9850U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9858U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000158U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A986CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitQuad_00350A98(frame, context, state, 0x00350A98U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A986CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A986C;
    }
block_001A986C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A986CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A986CU);
        }
        {
            const uint32_t updatedAddress = 0x001A9874U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A986CU, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9880U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetQuad_00350914(frame, context, state, 0x00350914U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9880U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9880;
    }
block_001A9880:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9880U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9880U);
        }
        {
            const uint32_t updatedAddress = 0x001A9888U - 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9880U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9888U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_001A98D8; }
        goto block_001A9898;
    }
block_001A9898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9898U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A989CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A989CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A989C;
    }
block_001A989C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A989CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A989CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A98A8U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A98A0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A98B0U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001A98BCU - 536U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A98B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A98B8U, 0xEE710A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A98C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A98C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A98C0;
    }
block_001A98C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A98C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A98C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A98C0U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A98D0U + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A98C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A98CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A98D0U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A98D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A98D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A98D8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A98E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A98E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A98E0;
    }
block_001A98E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A98E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A98E0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A98ECU + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A98E4U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A98F4U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001A9900U - 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A98F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A98FCU, 0xEE710A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9904U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9904U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9904;
    }
block_001A9904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9904U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9904U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A9914U + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A990CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9910U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9914U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A991C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A991CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A991CU);
        }
        {
            r1 = 0x00000009U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9928U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9928U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9928;
    }
block_001A9928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9928U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A9934U + 396U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A992CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000009U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9940U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001A994CU - 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9944U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A994CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A994CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A994C;
    }
block_001A994C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A994CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A994CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A994CU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A995CU + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9954U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9958U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A995CU, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9964U);
        }
        {
            const uint32_t updatedAddress = 0x001A996CU - 0xB78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9964U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9968U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r1 = 0x00000064U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9974U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9978U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A9988U + 0x160U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9980U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9984U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9988U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9990U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000E8U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A99A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitJntSph_00350EB8(frame, context, state, 0x00350EB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A99A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A99A4;
    }
block_001A99A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A99A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A99A4U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000108U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001A99ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001A99B8U + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A99B0U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A99C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetJntSph_00350D48(frame, context, state, 0x00350D48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A99C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A99C4;
    }
block_001A99C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A99C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A99C4U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000158U;
            r1 = r1 + operand;
        }
        {
            r5 = r1;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A99D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitQuad_00350A98(frame, context, state, 0x00350A98U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A99D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A99D8;
    }
block_001A99D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A99D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A99D8U);
        }
        {
            const uint32_t updatedAddress = 0x001A99E0U + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A99D8U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A99ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetQuad_00350914(frame, context, state, 0x00350914U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A99ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A99EC;
    }
block_001A99EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A99ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A99ECU);
        }
        {
            const uint32_t address = 0x001A99F4U - 848U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A99ECU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = 0x001A99F8U - 0xC04U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A99F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r5 = r4 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r5 + 988U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A99FCU, address);
            }
        }
        {
            const uint32_t address = r5 + 992U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9A00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A04U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001A9B24; }
        goto block_001A9A10;
    }
block_001A9A10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9A10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9A10U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9A1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9A1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9A1C;
    }
block_001A9A1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9A1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9A1CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A9A28U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A20U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9A34U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9A44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9A44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9A44;
    }
block_001A9A44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9A44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9A44U);
        }
        {
            const uint32_t address = 0x001A9A4CU + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 932U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9A48U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9A50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9A50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9A50;
    }
block_001A9A50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9A50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9A50U);
        }
        {
            const uint32_t address = 0x001A9A58U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x00000040U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9A5CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 936U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9A60U, address);
            }
        }
        {
            const uint32_t address = r5 + 940U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001A9A64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9A68U, address);
            }
        }
        {
            r1 = 0x00000078U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9A70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A74U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001A9A80U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A78U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9A8CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9A90U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9A98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9A9CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9AA0U, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9AA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9AA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        goto block_001A9AFC;
    }
block_001A9AFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9AFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9AFCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9AFCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = 0x0000002DU;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9B04U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9B08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B0CU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A9B1CU + 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9B18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9B1CU, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9B24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B24U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001A9B9C; }
        goto block_001A9B38;
    }
block_001A9B38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9B38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9B38U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9B3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9B3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9B3C;
    }
block_001A9B3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9B3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9B3CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A9B48U - 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B40U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9B54U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9B64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9B64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9B64;
    }
block_001A9B64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9B64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9B64U);
        }
        {
            const uint32_t address = 0x001A9B6CU - 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 932U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9B6CU, address);
            }
        }
        {
            const uint32_t address = r5 + 940U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001A9B70U, address);
            }
        }
        {
            r1 = 0x000000C0U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9B78U, address);
            }
        }
        {
            r1 = 0x00000078U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9B80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B84U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A9B94U + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9B8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9B90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9B94U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9B9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9B9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9B9CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9BA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9BA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9BA4;
    }
block_001A9BA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9BA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9BA4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001A9BB0U - 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9BA8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001A9BBCU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001A9BCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001A9BCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001A9BCC;
    }
block_001A9BCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9BCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9BCCU);
        }
        {
            const uint32_t address = 0x001A9BD4U - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9BCCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 932U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001A9BD4U, address);
            }
        }
        {
            const uint32_t address = r5 + 940U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001A9BD8U, address);
            }
        }
        {
            r1 = 0x00000060U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9BE0U, address);
            }
        }
        {
            r1 = 0x00000078U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9BE8U, address);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9BF0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x207U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9BF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9BF8U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = 0x001A9C08U + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001A9C00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9C04U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001A9C08U, address);
            }
        }
        goto block_001A9C0C;
    }
block_001A9C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001A9C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001A9C0CU);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x19BU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001A9C10U, address);
            }
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001A9C18U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001A9C18U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001A9C1CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_0031800C_0031800C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0031800CU:
        goto block_0031800C;
    case 0x00318010U:
        goto block_00318010;
    case 0x00318034U:
        goto block_00318034;
    case 0x00318050U:
        goto block_00318050;
    case 0x00318064U:
        goto block_00318064;
    case 0x00318078U:
        goto block_00318078;
    case 0x00318080U:
        goto block_00318080;
    case 0x00318088U:
        goto block_00318088;
    case 0x00318090U:
        goto block_00318090;
    case 0x00318098U:
        goto block_00318098;
    case 0x003180A8U:
        goto block_003180A8;
    case 0x003180BCU:
        goto block_003180BC;
    case 0x003180CCU:
        goto block_003180CC;
    case 0x00318108U:
        goto block_00318108;
    case 0x00318128U:
        goto block_00318128;
    case 0x00318138U:
        goto block_00318138;
    case 0x00318140U:
        goto block_00318140;
    case 0x0031814CU:
        goto block_0031814C;
    case 0x00318158U:
        goto block_00318158;
    case 0x00318160U:
        goto block_00318160;
    case 0x00318170U:
        goto block_00318170;
    case 0x00318198U:
        goto block_00318198;
    case 0x003181ACU:
        goto block_003181AC;
    case 0x003181C0U:
        goto block_003181C0;
    case 0x003181D0U:
        goto block_003181D0;
    case 0x003181F8U:
        goto block_003181F8;
    case 0x0031820CU:
        goto block_0031820C;
    case 0x0031821CU:
        goto block_0031821C;
    case 0x00318244U:
        goto block_00318244;
    case 0x00318250U:
        goto block_00318250;
    case 0x00318258U:
        goto block_00318258;
    case 0x00318268U:
        goto block_00318268;
    case 0x00318290U:
        goto block_00318290;
    case 0x003182A0U:
        goto block_003182A0;
    case 0x003182B0U:
        goto block_003182B0;
    case 0x003182B4U:
        goto block_003182B4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0031800C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031800CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031800CU);
        }
        {
            r0 = r0;
        }
        goto block_00318010;
    }
block_00318010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318010U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r0 = r1;
        }
        {
            r9 = r1;
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r11 = r11 + operand;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318034;
    }
block_00318034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318034U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318038U, address);
            }
            r0 = value;
        }
        {
            r8 = 0x00000000U;
        }
        if (flags.Z()) {
            r0 = r8;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r10 = 0x00000001U;
        }
        if (flags.Z()) { goto block_003182B4; }
        goto block_00318050;
    }
block_00318050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318050U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318050U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318054U, address);
            }
            r0 = value;
        }
        {
            r6 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003182B4; }
        goto block_00318064;
    }
block_00318064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318064U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x00318070U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318068U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00318074U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0031806CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r7 = 0x000000FFU;
        }
        if (flags.Z()) { goto block_003181C0; }
        goto block_00318078;
    }
block_00318078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318078U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00318140; }
        goto block_00318080;
    }
block_00318080:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318080U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318080U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003181AC; }
        goto block_00318088;
    }
block_00318088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318088U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003182A0; }
        goto block_00318090;
    }
block_00318090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318090U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003182B0; }
        goto block_00318098;
    }
block_00318098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318098U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003180A0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003180A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003180A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003180A8;
    }
block_003180A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003180A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003180A8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r10 = r4 + operand;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180B4U, 0xEEF88AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003180BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003180BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003180BC;
    }
block_003180BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003180BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003180BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180C0U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00318108; }
        goto block_003180CC;
    }
block_003180CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003180CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003180CCU);
        }
        {
            const uint32_t updatedAddress = r8 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180CCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180D4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003180D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180DCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180E4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003180E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180ECU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180F4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003180F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00318100U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00318104U, address);
            }
        }
        goto block_00318108;
    }
block_00318108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318108U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318114U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318128U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318128U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318128;
    }
block_00318128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318128U);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0031812CU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318134U, address);
            }
        }
        goto block_00318138;
    }
block_00318138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318138U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00318138U, address);
            }
        }
        goto block_003182B0;
    }
block_00318140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318140U);
        }
        {
            const uint32_t address = 0x00318148U + 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318140U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0031820C; }
        goto block_0031814C;
    }
block_0031814C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031814CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031814CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r8 = 0x00000004U;
        }
        if (flags.Z()) { goto block_00318258; }
        goto block_00318158;
    }
block_00318158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318158U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003182B0; }
        goto block_00318160;
    }
block_00318160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318160U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r9 = r4 + operand;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318170;
    }
block_00318170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318170U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r10 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00318188U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318198U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318198U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318198;
    }
block_00318198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318198U);
        }
        {
            r0 = 0x00000012U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0031819CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003181A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x003181A4U, address);
            }
        }
        goto block_003182B0;
    }
block_003181AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181ACU);
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003181B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003181B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003181B8U, address);
            }
        }
        goto block_003182B0;
    }
block_003181C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181C0U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003181D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003181D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003181D0;
    }
block_003181D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181D0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r9 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003181E8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003181F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003181F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003181F8;
    }
block_003181F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181F8U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003181FCU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318204U, address);
            }
        }
        goto block_00318250;
    }
block_0031820C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031820CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031820CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000006U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0031821CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0031821CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0031821C;
    }
block_0031821C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031821CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031821CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r9 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000006U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00318234U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318244;
    }
block_00318244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318244U);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0031824CU, address);
            }
        }
        goto block_00318250;
    }
block_00318250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318250U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00318250U, address);
            }
        }
        goto block_003182B0;
    }
block_00318258:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318258U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318258U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r9 = r4 + operand;
        }
        {
            r1 = 0x00000004U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318268U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318268U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318268;
    }
block_00318268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318268U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r10 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000004U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00318280U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318290U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318290U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318290;
    }
block_00318290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318290U);
        }
        {
            r0 = 0x00000011U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318294U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00318298U, address);
            }
        }
        goto block_00318138;
    }
block_003182A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003182A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003182A0U);
        }
        {
            r1 = 0x00000013U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003182A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003182A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003182ACU, address);
            }
        }
        goto block_003182B0;
    }
block_003182B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003182B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003182B0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xCFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003182B0U, address);
            }
        }
        goto block_003182B4;
    }
block_003182B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003182B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003182B4U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00318010_00318010(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00318010U:
        goto block_00318010;
    case 0x00318034U:
        goto block_00318034;
    case 0x00318050U:
        goto block_00318050;
    case 0x00318064U:
        goto block_00318064;
    case 0x00318078U:
        goto block_00318078;
    case 0x00318080U:
        goto block_00318080;
    case 0x00318088U:
        goto block_00318088;
    case 0x00318090U:
        goto block_00318090;
    case 0x00318098U:
        goto block_00318098;
    case 0x003180A8U:
        goto block_003180A8;
    case 0x003180BCU:
        goto block_003180BC;
    case 0x003180CCU:
        goto block_003180CC;
    case 0x00318108U:
        goto block_00318108;
    case 0x00318128U:
        goto block_00318128;
    case 0x00318138U:
        goto block_00318138;
    case 0x00318140U:
        goto block_00318140;
    case 0x0031814CU:
        goto block_0031814C;
    case 0x00318158U:
        goto block_00318158;
    case 0x00318160U:
        goto block_00318160;
    case 0x00318170U:
        goto block_00318170;
    case 0x00318198U:
        goto block_00318198;
    case 0x003181ACU:
        goto block_003181AC;
    case 0x003181C0U:
        goto block_003181C0;
    case 0x003181D0U:
        goto block_003181D0;
    case 0x003181F8U:
        goto block_003181F8;
    case 0x0031820CU:
        goto block_0031820C;
    case 0x0031821CU:
        goto block_0031821C;
    case 0x00318244U:
        goto block_00318244;
    case 0x00318250U:
        goto block_00318250;
    case 0x00318258U:
        goto block_00318258;
    case 0x00318268U:
        goto block_00318268;
    case 0x00318290U:
        goto block_00318290;
    case 0x003182A0U:
        goto block_003182A0;
    case 0x003182B0U:
        goto block_003182B0;
    case 0x003182B4U:
        goto block_003182B4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00318010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318010U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00318010U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r0 = r1;
        }
        {
            r9 = r1;
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r11 = r11 + operand;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00318028U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318034;
    }
block_00318034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318034U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318038U, address);
            }
            r0 = value;
        }
        {
            r8 = 0x00000000U;
        }
        if (flags.Z()) {
            r0 = r8;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r10 = 0x00000001U;
        }
        if (flags.Z()) { goto block_003182B4; }
        goto block_00318050;
    }
block_00318050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318050U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318050U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318054U, address);
            }
            r0 = value;
        }
        {
            r6 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003182B4; }
        goto block_00318064;
    }
block_00318064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318064U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x00318070U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318068U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00318074U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0031806CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r7 = 0x000000FFU;
        }
        if (flags.Z()) { goto block_003181C0; }
        goto block_00318078;
    }
block_00318078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318078U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00318140; }
        goto block_00318080;
    }
block_00318080:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318080U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318080U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003181AC; }
        goto block_00318088;
    }
block_00318088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318088U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003182A0; }
        goto block_00318090;
    }
block_00318090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318090U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003182B0; }
        goto block_00318098;
    }
block_00318098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318098U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003180A0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003180A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003180A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003180A8;
    }
block_003180A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003180A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003180A8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r10 = r4 + operand;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180B4U, 0xEEF88AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003180BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003180BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003180BC;
    }
block_003180BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003180BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003180BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180C0U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00318108; }
        goto block_003180CC;
    }
block_003180CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003180CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003180CCU);
        }
        {
            const uint32_t updatedAddress = r8 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180CCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180D4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003180D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180DCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180E4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003180E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180ECU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003180F4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003180F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003180FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00318100U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00318104U, address);
            }
        }
        goto block_00318108;
    }
block_00318108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318108U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318114U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318128U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318128U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318128;
    }
block_00318128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318128U);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0031812CU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318134U, address);
            }
        }
        goto block_00318138;
    }
block_00318138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318138U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00318138U, address);
            }
        }
        goto block_003182B0;
    }
block_00318140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318140U);
        }
        {
            const uint32_t address = 0x00318148U + 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00318140U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0031820C; }
        goto block_0031814C;
    }
block_0031814C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031814CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031814CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r8 = 0x00000004U;
        }
        if (flags.Z()) { goto block_00318258; }
        goto block_00318158;
    }
block_00318158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318158U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003182B0; }
        goto block_00318160;
    }
block_00318160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318160U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r9 = r4 + operand;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318170;
    }
block_00318170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318170U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r10 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00318188U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318198U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318198U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318198;
    }
block_00318198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318198U);
        }
        {
            r0 = 0x00000012U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0031819CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003181A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x003181A4U, address);
            }
        }
        goto block_003182B0;
    }
block_003181AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181ACU);
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003181B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003181B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003181B8U, address);
            }
        }
        goto block_003182B0;
    }
block_003181C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181C0U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003181D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003181D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003181D0;
    }
block_003181D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181D0U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r9 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003181E8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003181F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003181F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003181F8;
    }
block_003181F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003181F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003181F8U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003181FCU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318204U, address);
            }
        }
        goto block_00318250;
    }
block_0031820C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031820CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031820CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000006U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0031821CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0031821CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0031821C;
    }
block_0031821C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0031821CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0031821CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r9 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000006U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00318234U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318244;
    }
block_00318244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318244U);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0031824CU, address);
            }
        }
        goto block_00318250;
    }
block_00318250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318250U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00318250U, address);
            }
        }
        goto block_003182B0;
    }
block_00318258:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318258U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318258U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r9 = r4 + operand;
        }
        {
            r1 = 0x00000004U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318268U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318268U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318268;
    }
block_00318268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318268U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000000BCU;
            r10 = r4 + operand;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000004U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00318280U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00318290U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00318290U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00318290;
    }
block_00318290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00318290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00318290U);
        }
        {
            r0 = 0x00000011U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00318294U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00318298U, address);
            }
        }
        goto block_00318138;
    }
block_003182A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003182A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003182A0U);
        }
        {
            r1 = 0x00000013U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003182A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003182A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x003182ACU, address);
            }
        }
        goto block_003182B0;
    }
block_003182B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003182B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003182B0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xCFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003182B0U, address);
            }
        }
        goto block_003182B4;
    }
block_003182B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003182B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003182B4U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003182B8U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003182BCU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003239a4_003239A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003239A4U:
        goto block_003239A4;
    case 0x003239C4U:
        goto block_003239C4;
    case 0x003239D8U:
        goto block_003239D8;
    case 0x00323A34U:
        goto block_00323A34;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003239A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003239A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003239A4U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003239A4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003239A4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003239A4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003239A4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003239A4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003239A4U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t operand = 0x00002000U;
            r6 = r1 + operand;
        }
        {
            r0 = r1;
        }
        {
            r7 = r2;
        }
        {
            const uint32_t operand = 0x00000298U;
            r6 = r6 + operand;
        }
        {
            r4 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003239C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003239C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003239C4;
    }
block_003239C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003239C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003239C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r6 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003239CCU, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00323A34; }
        goto block_003239D8;
    }
block_003239D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003239D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003239D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003239D8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r5 + operand;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003239E8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003239ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003239F0U, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003239F8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003239FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00323A00U, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00323A08U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00323A0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00323A10U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00323A14U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00323A18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00323A1CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00323A20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00323A24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00323A28U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00323A2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00323A30U, address);
            }
        }
        goto block_00323A34;
    }
block_00323A34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00323A34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00323A34U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00323A34U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00323A34U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00323A34U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00323A34U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00323A34U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00323A34U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_00326524_00326524(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00326524U:
        goto block_00326524;
    case 0x00326528U:
        goto block_00326528;
    case 0x0032654CU:
        goto block_0032654C;
    case 0x0032655CU:
        goto block_0032655C;
    case 0x00326570U:
        goto block_00326570;
    case 0x00326588U:
        goto block_00326588;
    case 0x00326590U:
        goto block_00326590;
    case 0x00326598U:
        goto block_00326598;
    case 0x003265A0U:
        goto block_003265A0;
    case 0x003265A8U:
        goto block_003265A8;
    case 0x003265B0U:
        goto block_003265B0;
    case 0x003265C4U:
        goto block_003265C4;
    case 0x003265E8U:
        goto block_003265E8;
    case 0x00326608U:
        goto block_00326608;
    case 0x00326620U:
        goto block_00326620;
    case 0x00326628U:
        goto block_00326628;
    case 0x00326630U:
        goto block_00326630;
    case 0x00326640U:
        goto block_00326640;
    case 0x00326664U:
        goto block_00326664;
    case 0x00326684U:
        goto block_00326684;
    case 0x00326694U:
        goto block_00326694;
    case 0x0032669CU:
        goto block_0032669C;
    case 0x003266A4U:
        goto block_003266A4;
    case 0x003266ACU:
        goto block_003266AC;
    case 0x003266B4U:
        goto block_003266B4;
    case 0x003266C4U:
        goto block_003266C4;
    case 0x003266E8U:
        goto block_003266E8;
    case 0x003266F8U:
        goto block_003266F8;
    case 0x00326710U:
        goto block_00326710;
    case 0x00326728U:
        goto block_00326728;
    case 0x003267B8U:
        goto block_003267B8;
    case 0x003267C4U:
        goto block_003267C4;
    case 0x003267E8U:
        goto block_003267E8;
    case 0x003267FCU:
        goto block_003267FC;
    case 0x0032680CU:
        goto block_0032680C;
    case 0x00326830U:
        goto block_00326830;
    case 0x00326840U:
        goto block_00326840;
    case 0x003268D0U:
        goto block_003268D0;
    case 0x003268DCU:
        goto block_003268DC;
    case 0x00326900U:
        goto block_00326900;
    case 0x0032691CU:
        goto block_0032691C;
    case 0x0032692CU:
        goto block_0032692C;
    case 0x00326950U:
        goto block_00326950;
    case 0x00326970U:
        goto block_00326970;
    case 0x00326980U:
        goto block_00326980;
    case 0x00326990U:
        goto block_00326990;
    case 0x003269B4U:
        goto block_003269B4;
    case 0x003269D4U:
        goto block_003269D4;
    case 0x003269E4U:
        goto block_003269E4;
    case 0x003269F4U:
        goto block_003269F4;
    case 0x00326A18U:
        goto block_00326A18;
    case 0x00326A38U:
        goto block_00326A38;
    case 0x00326A48U:
        goto block_00326A48;
    case 0x00326A50U:
        goto block_00326A50;
    case 0x00326A60U:
        goto block_00326A60;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00326524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326524U);
        }
        {
            r0 = r0;
        }
        goto block_00326528;
    }
block_00326528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326528U);
        }
        {
            const uint32_t firstAddress = r13 - 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 36U);
            }
            r13 = r13 - 40U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00002000U;
            r6 = r1 + operand;
        }
        {
            r7 = r1;
        }
        {
            r0 = r1;
        }
        {
            const uint32_t operand = 0x00000298U;
            r6 = r6 + operand;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 12U);
            }
        }
        {
            r5 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0032654CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0032654CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0032654C;
    }
block_0032654C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032654CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032654CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326550U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326A60; }
        goto block_0032655C;
    }
block_0032655C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032655CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032655CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032655CU, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326560U, address);
            }
            r0 = value;
        }
        {
            r10 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326A60; }
        goto block_00326570;
    }
block_00326570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326570U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x0032657CU + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326574U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00326580U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326578U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r9 = 0x000000FFU;
        }
        {
            r6 = 0x00000001U;
        }
        if (flags.Z()) { goto block_00326980; }
        goto block_00326588;
    }
block_00326588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326588U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00326694; }
        goto block_00326590;
    }
block_00326590:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326590U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326590U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326A48; }
        goto block_00326598;
    }
block_00326598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326598U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00326620; }
        goto block_003265A0;
    }
block_003265A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003266F8; }
        goto block_003265A8;
    }
block_003265A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265A8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00326A50; }
        goto block_003265B0;
    }
block_003265B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265B0U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r6 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003265C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003265C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003265C4;
    }
block_003265C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265C4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003265C8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003265D4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003265D8U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003265E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003265E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003265E8;
    }
block_003265E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265E8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326608U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326608U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326608;
    }
block_00326608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326608U);
        }
        {
            r0 = 0x0000003AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0032660CU, address);
            }
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326614U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00326618U, address);
            }
        }
        goto block_00326A50;
    }
block_00326620:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326620U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326620U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003267FC; }
        goto block_00326628;
    }
block_00326628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326628U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00326A50; }
        goto block_00326630;
    }
block_00326630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326630U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326640U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326640U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326640;
    }
block_00326640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326640U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326644U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326650U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326654U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326664;
    }
block_00326664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326664U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326684U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326684U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326684;
    }
block_00326684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326684U);
        }
        {
            r0 = 0x0000003FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326688U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0032668CU, address);
            }
        }
        goto block_00326A50;
    }
block_00326694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326694U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000011U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003269E4; }
        goto block_0032669C;
    }
block_0032669C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032669CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032669CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000012U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326710; }
        goto block_003266A4;
    }
block_003266A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0032691C; }
        goto block_003266AC;
    }
block_003266AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00326A50; }
        goto block_003266B4;
    }
block_003266B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266B4U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r7 = r4 + operand;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003266C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003266C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003266C4;
    }
block_003266C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266C4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x003266D4U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003266CCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003266DCU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003266E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003266E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003266E8;
    }
block_003266E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266E8U);
        }
        {
            r0 = 0x0000003BU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003266ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003266F0U, address);
            }
        }
        goto block_00326A50;
    }
block_003266F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266F8U);
        }
        {
            r1 = 0x00000039U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003266FCU, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326704U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326708U, address);
            }
        }
        goto block_00326A50;
    }
block_00326710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326710U);
        }
        {
            const uint32_t operand = 0x000000BCU;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r11 = r4 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326728U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326728U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326728;
    }
block_00326728:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326728U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326728U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x219U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326728U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032672CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r12 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r2 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326744U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326748U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032674CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326754U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326758U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032675CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326764U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 528U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326768U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032676CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326774U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326778U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032677CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326784U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326788U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032678CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r3 + operand;
        }
        {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326794U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326798U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032679CU, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = r2 | 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003267A8U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003267B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationContext_SetMoveActor_003FD1B8(frame, context, state, 0x003FD1B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003267B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003267B8;
    }
block_003267B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267B8U);
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003267C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003267C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003267C4;
    }
block_003267C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267C4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003267D8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003267E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003267E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003267E8;
    }
block_003267E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267E8U);
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003267ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003267F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x003267F4U, address);
            }
        }
        goto block_00326A50;
    }
block_003267FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267FCU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0032680CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0032680CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0032680C;
    }
block_0032680C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032680CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032680CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326824U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326830U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326830U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326830;
    }
block_00326830:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326830U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326830U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326840U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326840U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326840;
    }
block_00326840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326840U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x219U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326840U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326844U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r12 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r2 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032685CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326860U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326864U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032686CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326870U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326874U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032687CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 528U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326880U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326884U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032688CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326890U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326894U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032689CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003268A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003268A4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r3 + operand;
        }
        {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003268ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003268B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003268B4U, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = r2 | 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003268C0U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003268D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationContext_SetMoveActor_003FD1B8(frame, context, state, 0x003FD1B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003268D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003268D0;
    }
block_003268D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003268D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003268D0U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003268DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003268DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003268DC;
    }
block_003268DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003268DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003268DCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000FU;
        }
        {
            r0 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003268F4U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326900U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326900U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326900;
    }
block_00326900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326900U);
        }
        {
            r0 = 0x0000003DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326904U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00326908U, address);
            }
        }
        goto block_00326A50;
    }
block_0032691C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032691CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032691CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0032692CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0032692CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0032692C;
    }
block_0032692C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032692CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032692CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326930U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0032693CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326940U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326950U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326950U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326950;
    }
block_00326950:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326950U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326950U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326970U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326970U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326970;
    }
block_00326970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326970U);
        }
        {
            r0 = 0x0000003EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326974U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00326978U, address);
            }
        }
        goto block_00326A50;
    }
block_00326980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326980U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326990;
    }
block_00326990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326990U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326994U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003269A0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003269A4U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003269B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003269B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003269B4;
    }
block_003269B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269B4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003269D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003269D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003269D4;
    }
block_003269D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269D4U);
        }
        {
            r0 = 0x00000040U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003269D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003269DCU, address);
            }
        }
        goto block_00326A50;
    }
block_003269E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269E4U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003269F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003269F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003269F4;
    }
block_003269F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269F4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003269F8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326A04U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326A08U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326A18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326A18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326A18;
    }
block_00326A18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A18U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326A38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326A38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326A38;
    }
block_00326A38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A38U);
        }
        {
            r0 = 0x00000041U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326A3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00326A40U, address);
            }
        }
        goto block_00326A50;
    }
block_00326A48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A48U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326A50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326A50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326A50;
    }
block_00326A50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A50U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xBC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00326A50U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
block_00326A60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A60U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00326528_00326528(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00326528U:
        goto block_00326528;
    case 0x0032654CU:
        goto block_0032654C;
    case 0x0032655CU:
        goto block_0032655C;
    case 0x00326570U:
        goto block_00326570;
    case 0x00326588U:
        goto block_00326588;
    case 0x00326590U:
        goto block_00326590;
    case 0x00326598U:
        goto block_00326598;
    case 0x003265A0U:
        goto block_003265A0;
    case 0x003265A8U:
        goto block_003265A8;
    case 0x003265B0U:
        goto block_003265B0;
    case 0x003265C4U:
        goto block_003265C4;
    case 0x003265E8U:
        goto block_003265E8;
    case 0x00326608U:
        goto block_00326608;
    case 0x00326620U:
        goto block_00326620;
    case 0x00326628U:
        goto block_00326628;
    case 0x00326630U:
        goto block_00326630;
    case 0x00326640U:
        goto block_00326640;
    case 0x00326664U:
        goto block_00326664;
    case 0x00326684U:
        goto block_00326684;
    case 0x00326694U:
        goto block_00326694;
    case 0x0032669CU:
        goto block_0032669C;
    case 0x003266A4U:
        goto block_003266A4;
    case 0x003266ACU:
        goto block_003266AC;
    case 0x003266B4U:
        goto block_003266B4;
    case 0x003266C4U:
        goto block_003266C4;
    case 0x003266E8U:
        goto block_003266E8;
    case 0x003266F8U:
        goto block_003266F8;
    case 0x00326710U:
        goto block_00326710;
    case 0x00326728U:
        goto block_00326728;
    case 0x003267B8U:
        goto block_003267B8;
    case 0x003267C4U:
        goto block_003267C4;
    case 0x003267E8U:
        goto block_003267E8;
    case 0x003267FCU:
        goto block_003267FC;
    case 0x0032680CU:
        goto block_0032680C;
    case 0x00326830U:
        goto block_00326830;
    case 0x00326840U:
        goto block_00326840;
    case 0x003268D0U:
        goto block_003268D0;
    case 0x003268DCU:
        goto block_003268DC;
    case 0x00326900U:
        goto block_00326900;
    case 0x0032691CU:
        goto block_0032691C;
    case 0x0032692CU:
        goto block_0032692C;
    case 0x00326950U:
        goto block_00326950;
    case 0x00326970U:
        goto block_00326970;
    case 0x00326980U:
        goto block_00326980;
    case 0x00326990U:
        goto block_00326990;
    case 0x003269B4U:
        goto block_003269B4;
    case 0x003269D4U:
        goto block_003269D4;
    case 0x003269E4U:
        goto block_003269E4;
    case 0x003269F4U:
        goto block_003269F4;
    case 0x00326A18U:
        goto block_00326A18;
    case 0x00326A38U:
        goto block_00326A38;
    case 0x00326A48U:
        goto block_00326A48;
    case 0x00326A50U:
        goto block_00326A50;
    case 0x00326A60U:
        goto block_00326A60;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00326528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326528U);
        }
        {
            const uint32_t firstAddress = r13 - 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00326528U,
                                           firstAddress + 36U);
            }
            r13 = r13 - 40U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00002000U;
            r6 = r1 + operand;
        }
        {
            r7 = r1;
        }
        {
            r0 = r1;
        }
        {
            const uint32_t operand = 0x00000298U;
            r6 = r6 + operand;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00326540U,
                                           firstAddress + 12U);
            }
        }
        {
            r5 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0032654CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0032654CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0032654C;
    }
block_0032654C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032654CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032654CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326550U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326A60; }
        goto block_0032655C;
    }
block_0032655C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032655CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032655CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032655CU, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326560U, address);
            }
            r0 = value;
        }
        {
            r10 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326A60; }
        goto block_00326570;
    }
block_00326570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326570U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x0032657CU + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326574U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00326580U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326578U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r9 = 0x000000FFU;
        }
        {
            r6 = 0x00000001U;
        }
        if (flags.Z()) { goto block_00326980; }
        goto block_00326588;
    }
block_00326588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326588U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00326694; }
        goto block_00326590;
    }
block_00326590:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326590U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326590U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326A48; }
        goto block_00326598;
    }
block_00326598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326598U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00326620; }
        goto block_003265A0;
    }
block_003265A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003266F8; }
        goto block_003265A8;
    }
block_003265A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265A8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00326A50; }
        goto block_003265B0;
    }
block_003265B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265B0U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r6 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003265C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003265C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003265C4;
    }
block_003265C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265C4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003265C8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003265D4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003265D8U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003265E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003265E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003265E8;
    }
block_003265E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003265E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003265E8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326608U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326608U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326608;
    }
block_00326608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326608U);
        }
        {
            r0 = 0x0000003AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0032660CU, address);
            }
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326614U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00326618U, address);
            }
        }
        goto block_00326A50;
    }
block_00326620:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326620U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326620U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003267FC; }
        goto block_00326628;
    }
block_00326628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326628U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00326A50; }
        goto block_00326630;
    }
block_00326630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326630U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326640U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326640U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326640;
    }
block_00326640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326640U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326644U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326650U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326654U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326664;
    }
block_00326664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326664U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326684U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326684U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326684;
    }
block_00326684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326684U);
        }
        {
            r0 = 0x0000003FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326688U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0032668CU, address);
            }
        }
        goto block_00326A50;
    }
block_00326694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326694U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000011U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003269E4; }
        goto block_0032669C;
    }
block_0032669C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032669CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032669CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000012U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00326710; }
        goto block_003266A4;
    }
block_003266A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0032691C; }
        goto block_003266AC;
    }
block_003266AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00326A50; }
        goto block_003266B4;
    }
block_003266B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266B4U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r7 = r4 + operand;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003266C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003266C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003266C4;
    }
block_003266C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266C4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x003266D4U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003266CCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003266DCU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003266E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003266E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003266E8;
    }
block_003266E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266E8U);
        }
        {
            r0 = 0x0000003BU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003266ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003266F0U, address);
            }
        }
        goto block_00326A50;
    }
block_003266F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003266F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003266F8U);
        }
        {
            r1 = 0x00000039U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003266FCU, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326704U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326708U, address);
            }
        }
        goto block_00326A50;
    }
block_00326710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326710U);
        }
        {
            const uint32_t operand = 0x000000BCU;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r11 = r4 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326728U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326728U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326728;
    }
block_00326728:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326728U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326728U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x219U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326728U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032672CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r12 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r2 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326744U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326748U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032674CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326754U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326758U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032675CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326764U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 528U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326768U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032676CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326774U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326778U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032677CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326784U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326788U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032678CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r3 + operand;
        }
        {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326794U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326798U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032679CU, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = r2 | 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003267A8U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003267B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationContext_SetMoveActor_003FD1B8(frame, context, state, 0x003FD1B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003267B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003267B8;
    }
block_003267B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267B8U);
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003267C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003267C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003267C4;
    }
block_003267C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267C4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003267D8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003267E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003267E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003267E8;
    }
block_003267E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267E8U);
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003267ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003267F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x003267F4U, address);
            }
        }
        goto block_00326A50;
    }
block_003267FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003267FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003267FCU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0032680CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0032680CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0032680C;
    }
block_0032680C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032680CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032680CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326824U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326830U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326830U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326830;
    }
block_00326830:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326830U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326830U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326840U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326840U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326840;
    }
block_00326840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326840U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x219U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326840U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326844U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r12 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r2 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032685CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326860U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326864U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032686CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326870U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326874U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032687CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 528U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326880U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326884U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032688CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00326890U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326894U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t address = r3 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0032689CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003268A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003268A4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r3 + operand;
        }
        {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003268ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003268B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003268B4U, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = r2 | 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003268C0U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003268D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationContext_SetMoveActor_003FD1B8(frame, context, state, 0x003FD1B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003268D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003268D0;
    }
block_003268D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003268D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003268D0U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003268DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003268DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003268DC;
    }
block_003268DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003268DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003268DCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x0000000FU;
        }
        {
            r0 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003268F4U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326900U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326900U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326900;
    }
block_00326900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326900U);
        }
        {
            r0 = 0x0000003DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326904U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00326908U, address);
            }
        }
        goto block_00326A50;
    }
block_0032691C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032691CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032691CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0032692CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0032692CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0032692C;
    }
block_0032692C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0032692CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0032692CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326930U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0032693CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326940U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326950U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326950U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326950;
    }
block_00326950:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326950U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326950U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326970U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326970U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326970;
    }
block_00326970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326970U);
        }
        {
            r0 = 0x0000003EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326974U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00326978U, address);
            }
        }
        goto block_00326A50;
    }
block_00326980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326980U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326990;
    }
block_00326990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326990U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00326994U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003269A0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003269A4U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003269B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003269B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003269B4;
    }
block_003269B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269B4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003269D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003269D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003269D4;
    }
block_003269D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269D4U);
        }
        {
            r0 = 0x00000040U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003269D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003269DCU, address);
            }
        }
        goto block_00326A50;
    }
block_003269E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269E4U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r8 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003269F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003269F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003269F4;
    }
block_003269F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003269F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003269F4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003269F8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r0 & ~(0x00000003U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00326A04U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00326A08U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326A18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003239a4_003239A4(frame, context, state, 0x003239A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326A18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326A18;
    }
block_00326A18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A18U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r8;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326A38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326A38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326A38;
    }
block_00326A38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A38U);
        }
        {
            r0 = 0x00000041U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00326A3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00326A40U, address);
            }
        }
        goto block_00326A50;
    }
block_00326A48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A48U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00326A50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00326A50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00326A50;
    }
block_00326A50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A50U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xBC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00326A50U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00326A58U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00326A5CU,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
block_00326A60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00326A60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00326A60U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00326A60U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00326A68U,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r4 = state.R[4];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0036AE14U:
        goto block_0036AE14;
    case 0x0036AE18U:
        goto block_0036AE18;
    case 0x0036AE24U:
        goto block_0036AE24;
    case 0x0036AE30U:
        goto block_0036AE30;
    case 0x0036AE40U:
        goto block_0036AE40;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0036AE14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036AE14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036AE14U);
        }
        {
            r0 = r0;
        }
        goto block_0036AE18;
    }
block_0036AE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036AE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036AE18U);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0036AE18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0036AE18U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036AE1CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0036AE24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCSABByIndex_0034807C(frame, context, state, 0x0034807CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0036AE24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0036AE24;
    }
block_0036AE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036AE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036AE24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = ~(0x00000000U);
        }
        if (flags.Z()) { goto block_0036AE40; }
        goto block_0036AE30;
    }
block_0036AE30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036AE30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036AE30U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036AE30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036AE34U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036AE3CU, address);
            }
            r0 = value;
        }
        goto block_0036AE40;
    }
block_0036AE40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036AE40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036AE40U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0036AE44U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0036AE44U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_get_flag_22a0_0037571C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r8 = state.R[8];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0037571CU:
        goto block_0037571C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0037571C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037571CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037571CU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375724U, address);
            }
            r0 = value;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r3 = state.R[3];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00375C08U:
        goto block_00375C08;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00375C08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375C08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375C08U);
        }
        {
            r3 = 0x00000000U;
        }
        return Oot3dAotBranch(0x0035302CU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
